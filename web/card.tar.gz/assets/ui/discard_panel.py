from __future__ import annotations

import pygame

from game.card import Card
from game.constants import COLORS, SCREEN_H, SCREEN_W, SUIT_COLORS
from game.score import discard_chip_half
from ui.suits import draw_suit


def draw_discard_panel(
  surface: pygame.Surface,
  discard: list[Card],
  banned: list[Card],
  font: pygame.font.Font,
  font_sm: pygame.font.Font,
  *,
  scroll: int = 0,
) -> pygame.Rect:
  panel = pygame.Rect(20, SCREEN_H - 116, SCREEN_W - 40, 104)
  pygame.draw.rect(surface, (22, 26, 34), panel, border_radius=10)
  pygame.draw.rect(surface, COLORS["accent"], panel, 1, border_radius=10)

  chip_sum = discard_chip_half(discard) * 2
  title = font.render(
    f"묘지 {len(discard)}장 · 칩 합 {chip_sum}  |  밴 {len(banned)}장 (이 적 전투 중 유지)",
    True,
    COLORS["text"],
  )
  surface.blit(title, (panel.x + 12, panel.y + 8))

  if not discard:
    empty = font_sm.render("묘지가 비어 있습니다 — 턴이 지날수록 카드가 쌓입니다", True, COLORS["text_dim"])
    surface.blit(empty, (panel.x + 12, panel.y + 38))
    return panel

  mini_w, mini_h, gap = 34, 48, 4
  inner_x = panel.x + 10
  inner_y = panel.y + 34
  inner_w = panel.w - 20
  visible = inner_w // (mini_w + gap)
  max_scroll = max(0, len(discard) - visible)
  scroll = max(0, min(scroll, max_scroll))
  start = scroll

  if scroll > 0:
    pygame.draw.polygon(surface, COLORS["text_dim"], [
      (panel.x + 4, inner_y + mini_h // 2),
      (panel.x + 12, inner_y + 8),
      (panel.x + 12, inner_y + mini_h - 8),
    ])
  if scroll < max_scroll:
    rx = panel.right - 12
    pygame.draw.polygon(surface, COLORS["text_dim"], [
      (rx + 8, inner_y + mini_h // 2),
      (rx, inner_y + 8),
      (rx, inner_y + mini_h - 8),
    ])

  for i, card in enumerate(discard[start : start + visible]):
    x = inner_x + i * (mini_w + gap)
    rect = pygame.Rect(x, inner_y, mini_w, mini_h)
    _draw_mini_card(surface, rect, card, font_sm)

  if len(discard) > visible:
    more = font_sm.render(f"+{len(discard) - visible - scroll}장", True, COLORS["text_dim"])
    surface.blit(more, (panel.right - 56, panel.y + 38))

  return panel


def _draw_mini_card(
  surface: pygame.Surface,
  rect: pygame.Rect,
  card: Card,
  font_sm: pygame.font.Font,
) -> None:
  pygame.draw.rect(surface, COLORS["card_bg"], rect, border_radius=4)
  pygame.draw.rect(surface, COLORS["card_border"], rect, 1, border_radius=4)
  color = SUIT_COLORS.get(card.suit, COLORS["text"])
  rank = font_sm.render(card.label, True, color)
  surface.blit(rank, (rect.x + 4, rect.y + 3))
  if not card.is_joker_card:
    draw_suit(surface, card.suit, (rect.centerx, rect.centery + 6), 10, color)
