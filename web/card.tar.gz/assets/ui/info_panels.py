"""정보 패널 — 유물·타로·덱 확인 (키로 토글)."""

from __future__ import annotations

import pygame

from game.artifact_effects import card_visual_mods
from game.artifacts import RARITY_COLORS, RARITY_LABELS, get_artifact
from game.constants import COLORS, SCREEN_H, SCREEN_W, SUIT_COLORS
from game.jaws import get_jaw
from game.state import GameState
from game.tarot_data import get_tarot_def
from ui.fonts import get_font
from ui.suits import draw_suit


PANEL_W = 540
PANEL_H = 580


class InfoPanelManager:
  """I=유물, T=타로, L=덱, B=밴 목록 패널."""

  def __init__(self) -> None:
    self.show_artifacts = False
    self.show_tarots = False
    self.show_deck = False
    self.show_banned = False
    self.show_inventory_menu = False
    self.deck_scroll = 0
    self.banned_scroll = 0
    self.font = get_font(22)
    self.font_sm = get_font(16)
    self.font_lg = get_font(28, bold=True)

  def any_open(self) -> bool:
    return (
      self.show_artifacts or self.show_tarots or self.show_deck
      or self.show_banned or self.show_inventory_menu
    )

  def close_all(self) -> None:
    self.show_artifacts = False
    self.show_tarots = False
    self.show_deck = False
    self.show_banned = False
    self.show_inventory_menu = False
    self.deck_scroll = 0
    self.banned_scroll = 0

  def open_inventory_menu(self) -> None:
    self.show_inventory_menu = not self.show_inventory_menu
    if not self.show_inventory_menu:
      return
    self.show_artifacts = False
    self.show_tarots = False
    self.show_deck = False
    self.show_banned = False

  def toggle(self, which: str) -> None:
    attr = f"show_{which}"
    if not hasattr(self, attr):
      return
    opening = not getattr(self, attr)
    self.close_all()
    if opening:
      setattr(self, attr, True)
      if which == "deck":
        self.deck_scroll = 0
      if which == "banned":
        self.banned_scroll = 0

  def handle_key(self, key: int) -> bool:
    if key == pygame.K_i:
      self.toggle("artifacts")
      return True
    if key == pygame.K_t:
      self.toggle("tarots")
      return True
    if key == pygame.K_l:
      self.toggle("deck")
      return True
    if key == pygame.K_b:
      self.toggle("banned")
      return True
    if key == pygame.K_ESCAPE and self.any_open():
      self.close_all()
      return True
    return False

  def scroll_deck(self, delta: int) -> None:
    if self.show_deck:
      self.deck_scroll = max(0, self.deck_scroll - delta * 36)
    if self.show_banned:
      self.banned_scroll = max(0, self.banned_scroll - delta * 36)

  def inventory_menu_rect(self) -> pygame.Rect:
    return pygame.Rect(SCREEN_W - 52, 8, 44, 36)

  def handle_click(self, pos: tuple[int, int]) -> str | None:
    if self.show_inventory_menu:
      menu = pygame.Rect(SCREEN_W - 160, 48, 148, 168)
      if not menu.collidepoint(pos):
        if not self.inventory_menu_rect().collidepoint(pos):
          self.show_inventory_menu = False
        return None
      items = [
        ("유물", "inv_artifacts", 0),
        ("타로", "inv_tarots", 1),
        ("덱", "inv_deck", 2),
        ("밴", "inv_banned", 3),
      ]
      for _, action, row in items:
        r = pygame.Rect(menu.x + 8, menu.y + 10 + row * 38, menu.w - 16, 32)
        if r.collidepoint(pos):
          self.show_inventory_menu = False
          return action
      return None
    if self.inventory_menu_rect().collidepoint(pos):
      self.open_inventory_menu()
      return None
    return None

  def apply_inventory_action(self, action: str) -> None:
    mapping = {
      "inv_artifacts": "artifacts",
      "inv_tarots": "tarots",
      "inv_deck": "deck",
      "inv_banned": "banned",
    }
    which = mapping.get(action)
    if which:
      self.toggle(which)

  def draw_inventory_button(self, surf: pygame.Surface, font_sm) -> None:
    r = self.inventory_menu_rect()
    pygame.draw.rect(surf, (36, 40, 52), r, border_radius=8)
    pygame.draw.rect(surf, (100, 110, 140), r, 2, border_radius=8)
    t = font_sm.render("가방", True, (200, 205, 220))
    surf.blit(t, t.get_rect(center=r.center))
    if self.show_inventory_menu:
      menu = pygame.Rect(SCREEN_W - 160, 48, 148, 168)
      pygame.draw.rect(surf, (28, 32, 42), menu, border_radius=10)
      pygame.draw.rect(surf, (120, 130, 160), menu, 2, border_radius=10)
      for label, _, row in [
        ("유물", "inv_artifacts", 0),
        ("타로", "inv_tarots", 1),
        ("덱", "inv_deck", 2),
        ("밴 카드", "inv_banned", 3),
      ]:
        br = pygame.Rect(menu.x + 8, menu.y + 10 + row * 38, menu.w - 16, 32)
        pygame.draw.rect(surf, (44, 48, 60), br, border_radius=6)
        txt = font_sm.render(label, True, (220, 225, 235))
        surf.blit(txt, txt.get_rect(center=br.center))

  def draw(self, surf: pygame.Surface, state: GameState) -> None:
    if not self.any_open():
      return
    dim = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
    dim.fill((0, 0, 0, 140))
    surf.blit(dim, (0, 0))
    if self.show_artifacts:
      self._draw_artifacts(surf, state)
    elif self.show_tarots:
      self._draw_tarots(surf, state)
    elif self.show_banned:
      self._draw_banned(surf, state)
    elif self.show_deck:
      self._draw_deck(surf, state)

  def _panel_rect(self) -> pygame.Rect:
    return pygame.Rect(
      (SCREEN_W - PANEL_W) // 2,
      (SCREEN_H - PANEL_H) // 2,
      PANEL_W,
      PANEL_H,
    )

  def _draw_frame(self, surf: pygame.Surface, title: str, hint: str) -> pygame.Rect:
    panel = self._panel_rect()
    pygame.draw.rect(surf, COLORS["panel"], panel, border_radius=14)
    pygame.draw.rect(surf, COLORS["accent"], panel, 2, border_radius=14)
    t = self.font_lg.render(title, True, COLORS["text"])
    surf.blit(t, (panel.x + 20, panel.y + 16))
    h = self.font_sm.render(hint, True, COLORS["text_dim"])
    surf.blit(h, (panel.right - h.get_width() - 16, panel.y + 22))
    return panel

  def _blit_wrapped(
    self,
    surf: pygame.Surface,
    text: str,
    rect: pygame.Rect,
    color: tuple[int, int, int],
  ) -> None:
    words = text.replace("\n", " ").split()
    line = ""
    y = rect.y
    for word in words:
      trial = f"{line} {word}".strip()
      if self.font_sm.size(trial)[0] > rect.w and line:
        surf.blit(self.font_sm.render(line, True, color), (rect.x, y))
        y += self.font_sm.get_height() + 2
        line = word
      else:
        line = trial
      if y > rect.bottom:
        return
    if line and y <= rect.bottom:
      surf.blit(self.font_sm.render(line, True, color), (rect.x, y))

  def _draw_artifacts(self, surf: pygame.Surface, state: GameState) -> None:
    panel = self._draw_frame(surf, "유물 인벤토리", "I 닫기 · ESC 전체 닫기")
    y = panel.y + 58
    if not state.artifact_stacks:
      surf.blit(self.font.render("보유 유물 없음", True, COLORS["text_dim"]), (panel.x + 24, y + 40))
      self._blit_wrapped(
        surf,
        "런 시작 시 유물을 하나 선택할 수 있습니다.",
        pygame.Rect(panel.x + 24, y + 80, panel.w - 48, 40),
        COLORS["text_dim"],
      )
      return
    for aid, n in sorted(state.artifact_stacks.items()):
      if n <= 0:
        continue
      art = get_artifact(aid)
      rarity_col = RARITY_COLORS[art.rarity]
      box = pygame.Rect(panel.x + 20, y, panel.w - 40, 96)
      pygame.draw.rect(surf, (32, 36, 48), box, border_radius=10)
      pygame.draw.rect(surf, rarity_col, box, 2, border_radius=10)
      name = self.font.render(f"{art.name}  ×{n}" if n > 1 else art.name, True, COLORS["text"])
      surf.blit(name, (box.x + 14, box.y + 10))
      rar = self.font_sm.render(RARITY_LABELS[art.rarity], True, rarity_col)
      surf.blit(rar, (box.right - rar.get_width() - 12, box.y + 12))
      self._blit_wrapped(
        surf, art.effect_summary,
        pygame.Rect(box.x + 14, box.y + 38, box.w - 28, 50),
        COLORS["text_dim"],
      )
      y += 108

  def _draw_tarots(self, surf: pygame.Surface, state: GameState) -> None:
    panel = self._draw_frame(surf, "타로 카드", "T 닫기 · ESC 전체 닫기")
    y = panel.y + 58
    if not state.tarots:
      surf.blit(self.font.render("보유 타로 없음", True, COLORS["text_dim"]), (panel.x + 24, y + 20))
      return
    for tarot in state.tarots:
      defn = get_tarot_def(tarot.number)
      sealed = tarot.uid in state.sealed_tarot_uids
      used = tarot.uid in state.used_tarot_uids
      box = pygame.Rect(panel.x + 20, y, panel.w - 40, 78)
      pygame.draw.rect(surf, (32, 36, 48), box, border_radius=8)
      border = COLORS["danger"] if sealed else COLORS["accent2"] if used else COLORS["accent"]
      pygame.draw.rect(surf, border, box, 2, border_radius=8)
      title = f"{tarot.number}. {tarot.name}  Lv.{tarot.upgrade_level}"
      if sealed:
        title += "  [봉인]"
      elif used:
        title += "  [사용됨]"
      surf.blit(self.font.render(title, True, COLORS["text"]), (box.x + 12, box.y + 8))
      eff = defn.effect_enhance if tarot.upgrade_level > 0 else defn.effect_play
      self._blit_wrapped(
        surf, eff or "",
        pygame.Rect(box.x + 12, box.y + 34, box.w - 24, 36),
        COLORS["text_dim"],
      )
      y += 86
      if y > panel.bottom - 40:
        break

  def _draw_banned(self, surf: pygame.Surface, state: GameState) -> None:
    panel = self._draw_frame(surf, "밴 카드", "B 닫기 · 휠 스크롤 · ESC")
    banned = state.deck.banned
    surf.blit(
      self.font_sm.render(f"영구 밴 {len(banned)}장", True, COLORS["accent2"]),
      (panel.x + 20, panel.y + 54),
    )
    if not banned:
      surf.blit(self.font.render("밴한 카드 없음", True, COLORS["text_dim"]), (panel.x + 24, panel.y + 100))
      return
    clip = pygame.Rect(panel.x + 16, panel.y + 82, panel.w - 32, panel.h - 100)
    y0 = clip.y - self.banned_scroll
    cols = 6
    cw, ch, gap = 72, 96, 8
    for i, card in enumerate(banned):
      col = i % cols
      row = i // cols
      cx = clip.x + col * (cw + gap)
      cy = y0 + row * (ch + gap)
      if cy + ch < clip.y or cy > clip.bottom:
        continue
      rect = pygame.Rect(cx, cy, cw, ch)
      pygame.draw.rect(surf, COLORS["card_bg"], rect, border_radius=6)
      suit_col = SUIT_COLORS.get(card.suit, COLORS["text"])
      pygame.draw.rect(surf, suit_col, rect, 2, border_radius=6)
      label = self.font.render(card.label, True, COLORS["text"])
      surf.blit(label, label.get_rect(center=(rect.centerx, rect.centery - 10)))
      if not card.is_joker_card:
        draw_suit(surf, card.suit, (rect.centerx, rect.centery + 16), 14, suit_col)

  def _draw_deck(self, surf: pygame.Surface, state: GameState) -> None:
    panel = self._draw_frame(surf, "덱 구성", "L 닫기 · 휠 스크롤 · ESC")
    deck = state.deck
    summary = (
      f"런 덱 {len(deck.run_deck)}장 · 작업 덱 {len(deck.deck)}장 · "
      f"묘지 {len(deck.discard)}장 · 밴 {len(deck.banned)}장"
    )
    surf.blit(self.font_sm.render(summary, True, COLORS["accent2"]), (panel.x + 20, panel.y + 54))

    hand_cards = [c for c in state.hand if c]
    cards = list(deck.run_deck) if deck.run_deck else list(deck.deck) + list(deck.discard)

    clip = pygame.Rect(panel.x + 16, panel.y + 82, panel.w - 32, panel.h - 100)
    y0 = clip.y - self.deck_scroll
    cols = 6
    cw, ch, gap = 72, 96, 8
    for i, card in enumerate(cards):
      col = i % cols
      row = i // cols
      cx = clip.x + col * (cw + gap)
      cy = y0 + row * (ch + gap)
      if cy + ch < clip.y or cy > clip.bottom:
        continue
      rect = pygame.Rect(cx, cy, cw, ch)
      pygame.draw.rect(surf, COLORS["card_bg"], rect, border_radius=6)
      suit_col = SUIT_COLORS.get(card.suit, COLORS["text"])
      pygame.draw.rect(surf, suit_col, rect, 2, border_radius=6)
      mod = card_visual_mods(card, state.artifact_stacks)
      if mod and mod.new_rank_label:
        orig = self.font_sm.render(mod.orig_rank_label, True, (110, 115, 125))
        surf.blit(orig, (rect.x + 6, rect.y + 6))
        ow = orig.get_width()
        pygame.draw.line(surf, (170, 90, 90), (rect.x + 6, rect.y + 14), (rect.x + 6 + ow, rect.y + 14), 1)
        new = self.font.render(mod.new_rank_label, True, (130, 220, 255))
        surf.blit(new, (rect.x + 6, rect.y + 20))
      elif mod and mod.chip_override is not None:
        label = self.font.render(card.label, True, COLORS["text"])
        surf.blit(label, label.get_rect(center=(rect.centerx, rect.centery - 14)))
        chip = self.font_sm.render(f"칩{mod.chip_override}", True, (240, 200, 90))
        surf.blit(chip, chip.get_rect(center=(rect.centerx, rect.centery + 8)))
      else:
        label = self.font.render(card.label, True, COLORS["text"])
        surf.blit(label, label.get_rect(center=(rect.centerx, rect.centery - 10)))
      if not card.is_joker_card:
        draw_suit(surf, card.suit, (rect.centerx, rect.centery + 28 if mod and mod.new_rank_label else rect.centery + 16), 14, suit_col)
      if card.jaw_id:
        jaw = get_jaw(card.jaw_id)
        jt = self.font_sm.render(jaw.name[:8], True, (255, 200, 120))
        surf.blit(jt, (rect.x + 4, rect.bottom - 16))
      key = card.card_key()
      loc = ""
      if any(c and c.card_key() == key for c in hand_cards):
        loc = "패"
      elif any(c.card_key() == key for c in deck.deck):
        loc = "덱"
      elif any(c.card_key() == key for c in deck.discard):
        loc = "묘"
      elif any(c.card_key() == key for c in deck.banned):
        loc = "밴"
      if loc:
        lt = self.font_sm.render(loc, True, COLORS["text_dim"])
        surf.blit(lt, (rect.right - lt.get_width() - 4, rect.y + 4))
