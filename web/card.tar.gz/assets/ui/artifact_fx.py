"""유물별 고유 연출 — 획득·효과 발동."""

from __future__ import annotations

import math
import random

from game.constants import SCREEN_W
from ui.effects import Beam, EffectManager, Particle, Ring


def spawn_artifact_acquire(fx: EffectManager, aid: str, center: tuple[int, int]) -> None:
  """유물 획득 시 — 유물마다 짧고 다른 연출."""
  _ACQUIRE.get(aid, _acquire_default)(fx, center)


def spawn_artifact_activate(
  fx: EffectManager,
  aid: str,
  center: tuple[int, int],
  *,
  slot_center: tuple[int, int] | None = None,
) -> None:
  """유물 효과 발동 시."""
  fn = _ACTIVATE.get(aid)
  if fn:
    fn(fx, center, slot_center=slot_center)
  else:
    _activate_default(fx, center)


# ---- 획득 ----

def _acquire_default(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  fx.rings.append(Ring(cx, cy, 44, (180, 170, 150), life=0.45, width=4))
  fx.burst(cx, cy, (200, 190, 170), count=18, speed=220, size=4, gravity=100, shape="circle")
  fx.add_shake(3.0, 0.15)


def _acquire_pale_note(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  for i in range(5):
    x = cx - 40 + i * 20
    fx.particles.append(Particle(
      x, cy + 20, 0, -120, 0.55, (200, 190, 230), 3,
      gravity=-20, shape="circle",
    ))
  fx.rings.append(Ring(cx, cy, 36, (210, 200, 255), life=0.4, width=3))
  fx.add_shake(2.0, 0.1)


def _acquire_red_bowl(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  fx.rings.append(Ring(cx, cy, 28, (200, 50, 50), life=0.5, width=4))
  for _ in range(6):
    a = random.uniform(0, math.tau)
    fx.particles.append(Particle(
      cx, cy, math.cos(a) * 80, math.sin(a) * 80 - 40,
      0.5, (220, 60, 60), 4, gravity=140, shape="circle",
    ))
  fx.add_flash((180, 40, 40), 35, life=0.2)


def _acquire_future_shackle(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  fx.rings.append(Ring(cx - 14, cy, 22, (140, 130, 160), life=0.45, width=4))
  fx.rings.append(Ring(cx + 14, cy, 22, (140, 130, 160), life=0.45, width=4))
  fx.beams.append(Beam(cx - 30, cy, cx + 30, cy, (120, 110, 150), speed=400, size=3))
  fx.add_shake(2.5, 0.12)


def _acquire_silver_feather(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  fx.burst(cx, cy, (210, 220, 235), count=10, speed=160, size=3, gravity=-60, shape="streak")
  fx.rings.append(Ring(cx, cy, 40, (230, 235, 250), life=0.42, width=3))
  for side in (-1, 1):
    fx.beams.append(Beam(cx, cy + 30, cx + side * 50, cy - 50, (200, 210, 230), speed=300, size=4))


def _acquire_rusty_pelican(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  rust = (160, 90, 50)
  fx.burst(cx, cy, rust, count=14, speed=200, size=5, gravity=160, shape="square")
  fx.rings.append(Ring(cx, cy, 34, (120, 70, 40), life=0.4, width=4))


def _acquire_indulgence(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  for i in range(4):
    fx.particles.append(Particle(
      cx + random.randint(-30, 30), cy + 20, random.uniform(-30, 30), -90,
      0.7, (235, 225, 200), 4, gravity=40, shape="square", spin=2.0,
    ))
  fx.rings.append(Ring(cx, cy, 32, (220, 210, 180), life=0.4, width=3))


def _acquire_blood_horn(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  fx.beams.append(Beam(cx, cy - 50, cx, cy + 30, (160, 30, 40), speed=500, size=6))
  fx.burst(cx, cy, (180, 40, 50), count=16, speed=240, size=4, gravity=120, shape="streak")
  fx.add_flash((120, 20, 30), 40, life=0.22)


def _acquire_resting_acolyte(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  fx.rings.append(Ring(cx, cy, 30, (120, 160, 220), life=0.5, width=3))
  fx.burst(cx, cy - 10, (180, 200, 255), count=8, speed=100, size=3, gravity=-40, shape="circle")


def _acquire_ether(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  for c in ((180, 140, 255), (140, 200, 255), (200, 160, 240)):
    fx.burst(cx, cy, c, count=6, speed=140, size=4, gravity=-30, shape="circle")


def _acquire_white_glove(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  fx.rings.append(Ring(cx, cy, 38, (245, 245, 250), life=0.45, width=3))
  fx.burst(cx, cy, (255, 255, 255), count=10, speed=150, size=3, gravity=50, shape="circle")


def _acquire_severed_fingertip(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  fx.burst(cx, cy, (200, 60, 70), count=12, speed=200, size=4, gravity=100, shape="streak")
  fx.rings.append(Ring(cx, cy, 26, (220, 80, 90), life=0.35, width=4))
  fx.add_shake(3.5, 0.14)


def _acquire_locust_necklace(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  green = (100, 160, 70)
  for k in range(8):
    a = k * math.tau / 8
    fx.particles.append(Particle(
      cx + math.cos(a) * 20, cy + math.sin(a) * 20,
      math.cos(a) * 100, math.sin(a) * 100,
      0.45, green, 3, gravity=60, shape="square",
    ))


def _acquire_iceberg_tip(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  ice = (160, 210, 255)
  for k in range(6):
    a = k * math.tau / 6 + 0.2
    fx.particles.append(Particle(
      cx, cy, math.cos(a) * 180, math.sin(a) * 180,
      0.5, ice, 4, gravity=20, shape="square", spin=4.0,
    ))
  fx.rings.append(Ring(cx, cy, 36, (200, 230, 255), life=0.4, width=3))


def _acquire_traitor_tongue(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  pink = (220, 120, 140)
  fx.beams.append(Beam(cx - 20, cy, cx, cy - 30, pink, speed=350, size=4))
  fx.beams.append(Beam(cx + 20, cy, cx, cy - 30, pink, speed=350, size=4))
  fx.burst(cx, cy, pink, count=10, speed=160, size=3, gravity=80, shape="circle")


def _acquire_compressed_head(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  for i in range(3):
    fx.rings.append(Ring(cx, cy, 50 - i * 14, (150, 140, 170), life=0.35 + i * 0.05, width=4))
  fx.add_shake(4.0, 0.18)


def _acquire_infi_bible(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  gold = (220, 190, 100)
  fx.rings.append(Ring(cx, cy, 40, gold, life=0.5, width=4))
  fx.burst(cx, cy, gold, count=12, speed=180, size=3, gravity=60, shape="star")
  fx.add_flash(gold, 50, life=0.25)


def _acquire_whale_ribs(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  bone = (220, 215, 200)
  for k in range(5):
    a = -0.8 + k * 0.4
    x2 = cx + math.cos(a) * 50
    y2 = cy + math.sin(a) * 30 - 10
    fx.beams.append(Beam(cx, cy + 20, x2, y2, bone, speed=280, size=4))


def _acquire_star_clock(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  for k in range(5):
    a = k * math.tau / 5
    fx.particles.append(Particle(
      cx + math.cos(a) * 24, cy + math.sin(a) * 24, 0, 0,
      0.6, (255, 240, 160), 3, gravity=0, shape="star",
    ))
  fx.rings.append(Ring(cx, cy, 34, (255, 220, 120), life=0.45, width=3))


def _acquire_kingslayer_sword(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  fx.beams.append(Beam(cx - 60, cy + 40, cx + 60, cy - 50, (220, 60, 70), speed=600, size=5))
  fx.rings.append(Ring(cx, cy, 38, (180, 50, 60), life=0.4, width=4))
  fx.add_shake(4.0, 0.2)


def _acquire_joy_blade(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  colors = ((255, 200, 100), (255, 150, 180), (150, 200, 255))
  for c in colors:
    fx.burst(cx, cy, c, count=5, speed=180, size=3, gravity=80, shape="star")


_ACQUIRE: dict[str, object] = {
  "pale_note": _acquire_pale_note,
  "red_bowl": _acquire_red_bowl,
  "future_shackle": _acquire_future_shackle,
  "silver_feather": _acquire_silver_feather,
  "rusty_pelican": _acquire_rusty_pelican,
  "indulgence": _acquire_indulgence,
  "blood_horn": _acquire_blood_horn,
  "resting_acolyte": _acquire_resting_acolyte,
  "ether": _acquire_ether,
  "white_glove": _acquire_white_glove,
  "severed_fingertip": _acquire_severed_fingertip,
  "locust_necklace": _acquire_locust_necklace,
  "iceberg_tip": _acquire_iceberg_tip,
  "traitor_tongue": _acquire_traitor_tongue,
  "compressed_head": _acquire_compressed_head,
  "infi_bible": _acquire_infi_bible,
  "whale_ribs": _acquire_whale_ribs,
  "star_clock": _acquire_star_clock,
  "kingslayer_sword": _acquire_kingslayer_sword,
  "joy_blade": _acquire_joy_blade,
}


# ---- 발동 ----

def _activate_default(fx: EffectManager, center: tuple[int, int]) -> None:
  cx, cy = center
  fx.rings.append(Ring(cx, cy, 24, (180, 170, 150), life=0.28, width=3))
  fx.burst(cx, cy, (190, 185, 170), count=8, speed=160, size=3, gravity=70, shape="circle")


def _activate_joy_blade(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  fx.beams.append(Beam(cx - 40, cy + 20, cx + 50, cy - 30, (255, 200, 120), speed=420, size=4))
  fx.burst(cx, cy, (255, 180, 100), count=10, speed=200, size=3, gravity=90, shape="star")
  fx.add_shake(2.5, 0.12)


def _activate_severed_fingertip(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  fx.rings.append(Ring(cx, cy, 28, (220, 70, 80), life=0.35, width=4))
  fx.rings.append(Ring(cx, cy, 42, (220, 70, 80), life=0.3, width=2))
  fx.add_flash((200, 50, 60), 30, life=0.15)
  fx.add_shake(3.0, 0.14)


def _activate_resting_acolyte(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  fx.burst(cx, cy - 8, (160, 190, 255), count=8, speed=90, size=3, gravity=-50, shape="circle")
  fx.rings.append(Ring(cx, cy, 26, (140, 170, 230), life=0.35, width=3))


def _activate_iceberg_tip(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  ice = (170, 220, 255)
  for side in (-1, 1):
    fx.beams.append(Beam(cx, cy, cx + side * 55, cy - 35, ice, speed=320, size=4))
  fx.burst(cx, cy, ice, count=8, speed=180, size=3, gravity=30, shape="square")


def _activate_locust_necklace(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  green = (90, 150, 60)
  for _ in range(6):
    fx.particles.append(Particle(
      cx + random.randint(-20, 20), cy,
      random.uniform(-80, 80), random.uniform(-120, -60),
      0.4, green, 3, gravity=100, shape="square",
    ))


def _activate_kingslayer_sword(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  fx.beams.append(Beam(cx - 50, cy + 30, cx + 55, cy - 40, (210, 50, 60), speed=500, size=5))
  fx.add_shake(3.0, 0.15)


def _activate_pale_note(fx: EffectManager, center: tuple[int, int], *, slot_center=None, **_) -> None:
  pos = slot_center or center
  fx.rings.append(Ring(pos[0], pos[1], 22, (210, 200, 255), life=0.3, width=2))
  fx.burst(pos[0], pos[1], (200, 190, 240), count=6, speed=120, size=2, gravity=50, shape="circle")


def _activate_silver_feather(fx: EffectManager, center: tuple[int, int], *, slot_center=None, **_) -> None:
  pos = slot_center or center
  fx.burst(pos[0], pos[1], (220, 225, 240), count=6, speed=100, size=2, gravity=-40, shape="streak")


def _activate_blood_horn(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  fx.beams.append(Beam(cx, cy - 20, cx, cy + 25, (170, 35, 45), speed=380, size=4))
  fx.burst(cx, cy, (160, 40, 50), count=8, speed=200, size=3, gravity=110, shape="streak")


def _activate_indulgence(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  for _ in range(4):
    fx.particles.append(Particle(
      cx, cy, random.uniform(-60, 60), random.uniform(-140, -80),
      0.55, (230, 220, 190), 3, gravity=50, shape="square", spin=1.5,
    ))


def _activate_ether(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  fx.burst(cx, cy, (170, 150, 255), count=10, speed=150, size=3, gravity=-20, shape="circle")
  fx.burst(cx, cy, (140, 200, 255), count=6, speed=120, size=2, gravity=-10, shape="circle")


def _activate_white_glove(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  fx.rings.append(Ring(cx, cy, 32, (250, 250, 255), life=0.35, width=2))


def _activate_red_bowl(fx: EffectManager, center: tuple[int, int], *, slot_center=None, **_) -> None:
  pos = slot_center or center
  fx.rings.append(Ring(pos[0], pos[1], 20, (200, 50, 50), life=0.3, width=3))
  fx.burst(pos[0], pos[1], (220, 60, 60), count=5, speed=100, size=3, gravity=80, shape="circle")


def _activate_future_shackle(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  fx.rings.append(Ring(cx - 10, cy, 16, (130, 120, 150), life=0.35, width=3))
  fx.rings.append(Ring(cx + 10, cy, 16, (130, 120, 150), life=0.35, width=3))


def _activate_rusty_pelican(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  fx.burst(cx, cy, (150, 85, 45), count=10, speed=180, size=4, gravity=120, shape="square")
  fx.add_shake(2.0, 0.1)


def _activate_traitor_tongue(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  pink = (210, 110, 130)
  fx.beams.append(Beam(cx - 15, cy, cx, cy - 25, pink, speed=300, size=3))
  fx.beams.append(Beam(cx + 15, cy, cx, cy - 25, pink, speed=300, size=3))


def _activate_compressed_head(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  for i in range(2):
    fx.rings.append(Ring(cx, cy, 40 - i * 16, (140, 130, 160), life=0.4, width=4))
  fx.add_shake(5.0, 0.2)
  fx.add_flash((100, 90, 130), 50, life=0.25, vignette=True)


def _activate_infi_bible(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  fx.burst(cx, cy, (220, 190, 100), count=8, speed=140, size=3, gravity=50, shape="star")


def _activate_whale_ribs(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  bone = (210, 205, 190)
  for k in range(3):
    a = -0.5 + k * 0.5
    fx.beams.append(Beam(cx - 30, cy, cx + int(math.cos(a) * 40), cy + int(math.sin(a) * 20), bone, speed=250, size=3))


def _activate_star_clock(fx: EffectManager, center: tuple[int, int], **_) -> None:
  cx, cy = center
  fx.rings.append(Ring(cx, cy, 30, (255, 230, 140), life=0.35, width=3))
  fx.add_flash((255, 220, 120), 60, life=0.2, vignette=True)
  fx.add_shake(4.0, 0.2)


_ACTIVATE: dict[str, object] = {
  "joy_blade": _activate_joy_blade,
  "severed_fingertip": _activate_severed_fingertip,
  "resting_acolyte": _activate_resting_acolyte,
  "iceberg_tip": _activate_iceberg_tip,
  "locust_necklace": _activate_locust_necklace,
  "kingslayer_sword": _activate_kingslayer_sword,
  "pale_note": _activate_pale_note,
  "silver_feather": _activate_silver_feather,
  "blood_horn": _activate_blood_horn,
  "indulgence": _activate_indulgence,
  "ether": _activate_ether,
  "white_glove": _activate_white_glove,
  "red_bowl": _activate_red_bowl,
  "future_shackle": _activate_future_shackle,
  "rusty_pelican": _activate_rusty_pelican,
  "traitor_tongue": _activate_traitor_tongue,
  "compressed_head": _activate_compressed_head,
  "infi_bible": _activate_infi_bible,
  "whale_ribs": _activate_whale_ribs,
  "star_clock": _activate_star_clock,
}
