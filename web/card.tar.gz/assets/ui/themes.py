"""타로 카드별 색 테마와 족보 등급별 연출 강도를 정의합니다."""

from __future__ import annotations

Color = tuple[int, int, int]


# 각 타로의 분위기에 맞춘 그라데이션/강조 색과 파티클 스타일
TAROT_THEME: dict[int, dict] = {
  0:  {"c1": (200, 180, 40),  "c2": (255, 245, 120), "accent": (255, 255, 200), "style": "swirl"},
  1:  {"c1": (180, 40, 200),  "c2": (255, 120, 255), "accent": (255, 200, 255), "style": "spark"},
  2:  {"c1": (40, 40, 120),  "c2": (120, 120, 220), "accent": (200, 200, 255), "style": "swirl"},
  21: {"c1": (20, 80, 140),  "c2": (80, 200, 255),  "accent": (180, 255, 255), "style": "star"},
  3:  {"c1": (24, 110, 60),  "c2": (90, 220, 130),  "accent": (180, 255, 200), "style": "leaf"},
  4:  {"c1": (130, 30, 30),  "c2": (220, 90, 60),   "accent": (255, 200, 120), "style": "ember"},
  5:  {"c1": (120, 90, 20),  "c2": (235, 200, 90),  "accent": (255, 240, 170), "style": "holy"},
  6:  {"c1": (150, 40, 110), "c2": (255, 130, 190), "accent": (255, 200, 230), "style": "heart"},
  7:  {"c1": (40, 70, 110),  "c2": (120, 170, 230), "accent": (190, 220, 255), "style": "spark"},
  8:  {"c1": (150, 60, 20),  "c2": (255, 140, 50),  "accent": (255, 210, 140), "style": "ember"},
  9:  {"c1": (40, 80, 80),   "c2": (120, 200, 200), "accent": (200, 255, 255), "style": "dust"},
  10: {"c1": (80, 30, 130),  "c2": (180, 110, 255), "accent": (225, 190, 255), "style": "swirl"},
  11: {"c1": (60, 70, 120),  "c2": (180, 200, 255), "accent": (235, 240, 255), "style": "holy"},
  12: {"c1": (20, 90, 100),  "c2": (90, 200, 215),  "accent": (190, 250, 255), "style": "dust"},
  13: {"c1": (30, 30, 45),   "c2": (110, 70, 140),  "accent": (180, 140, 210), "style": "skull"},
  14: {"c1": (30, 110, 120), "c2": (110, 220, 230), "accent": (200, 255, 255), "style": "spark"},
  15: {"c1": (110, 16, 30),  "c2": (210, 50, 60),   "accent": (255, 120, 110), "style": "ember"},
  16: {"c1": (130, 50, 16),  "c2": (255, 120, 40),  "accent": (255, 200, 120), "style": "ember"},
  17: {"c1": (30, 90, 150),  "c2": (130, 220, 255), "accent": (255, 250, 180), "style": "star"},
  18: {"c1": (40, 30, 110),  "c2": (110, 100, 220), "accent": (190, 190, 255), "style": "swirl"},
  19: {"c1": (160, 110, 10), "c2": (255, 220, 60),  "accent": (255, 250, 190), "style": "sun"},
  20: {"c1": (120, 110, 40), "c2": (240, 230, 150), "accent": (255, 255, 220), "style": "holy"},
}

_DEFAULT_THEME = {"c1": (60, 40, 90), "c2": (130, 90, 190), "accent": (220, 190, 255), "style": "spark"}


def tarot_theme(number: int) -> dict:
  return TAROT_THEME.get(number, _DEFAULT_THEME)


# 족보 → 등급(0~5). 희귀할수록 높음
HAND_TIER: dict[str, int] = {
  "high_card": 0,
  "pair": 0,
  "two_pair": 1,
  "three_kind": 1,
  "straight": 2,
  "flush": 2,
  "full_house": 2,
  "three_pair": 3,
  "four_pair": 3,
  "straight_plus": 3,
  "flush_plus": 3,
  "four_kind": 3,
  "double_triple": 4,
  "octa_triple": 4,
  "quad_double": 4,
  "straight_flush": 4,
  "dragon": 5,
  "leviathan": 5,
  "rainbow": 5,
  "spectrum": 5,
  "royal_flush": 5,
}


# 등급별 연출 강도
TIER_STYLE: dict[int, dict] = {
  0: {"color": (170, 180, 200), "shake": 2.0,  "flash": 25,  "particles": 16,  "rings": 1, "label": ""},
  1: {"color": (120, 200, 255), "shake": 4.0,  "flash": 45,  "particles": 30,  "rings": 1, "label": "NICE"},
  2: {"color": (90, 220, 140),  "shake": 7.0,  "flash": 70,  "particles": 55,  "rings": 2, "label": "GREAT"},
  3: {"color": (200, 140, 255), "shake": 11.0, "flash": 100, "particles": 90,  "rings": 2, "label": "EXCELLENT"},
  4: {"color": (255, 170, 60),  "shake": 16.0, "flash": 140, "particles": 140, "rings": 3, "label": "AMAZING!"},
  5: {"color": (255, 90, 90),   "shake": 24.0, "flash": 190, "particles": 220, "rings": 4, "label": "LEGENDARY!!"},
}


def hand_tier(hand_name: str) -> int:
  return HAND_TIER.get(hand_name, 0)


def tier_style(tier: int) -> dict:
  return TIER_STYLE.get(max(0, min(5, tier)), TIER_STYLE[0])


# 등급 5는 무지개색 순환에 사용
RAINBOW = [
  (255, 80, 80), (255, 170, 60), (255, 240, 80),
  (90, 220, 130), (90, 190, 255), (180, 120, 255),
]
