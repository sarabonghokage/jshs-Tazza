"""파티클, 플래시, 화면 흔들림, 플로팅 텍스트 등 시각 효과 관리."""

from __future__ import annotations

import math
import random

import pygame

from game.constants import SCREEN_H, SCREEN_W
from ui.fonts import get_font
from ui.themes import RAINBOW, tarot_theme, tier_style
from ui.suits import draw_suit

Color = tuple[int, int, int]


class Particle:
  __slots__ = ("x", "y", "vx", "vy", "life", "max_life", "color", "size", "gravity", "shape", "angle", "spin", "fade")

  def __init__(self, x, y, vx, vy, life, color, size, gravity=0.0, shape="circle", spin=0.0, fade=True):
    self.x = x
    self.y = y
    self.vx = vx
    self.vy = vy
    self.life = life
    self.max_life = life
    self.color = color
    self.size = size
    self.gravity = gravity
    self.shape = shape
    self.angle = random.uniform(0, math.tau)
    self.spin = spin
    self.fade = fade

  def update(self, dt: float) -> None:
    self.x += self.vx * dt
    self.y += self.vy * dt
    self.vy += self.gravity * dt
    self.vx *= 0.99
    self.angle += self.spin * dt
    self.life -= dt

  def draw(self, surf: pygame.Surface) -> None:
    t = max(0.0, self.life / self.max_life)
    alpha = int(255 * t) if self.fade else 255
    size = max(1, int(self.size * (0.4 + 0.6 * t)))
    col = (*self.color, alpha)
    if self.shape == "circle":
      s = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
      pygame.draw.circle(s, col, (size, size), size)
      surf.blit(s, (self.x - size, self.y - size), special_flags=pygame.BLEND_PREMULTIPLIED if False else 0)
    elif self.shape == "star":
      _blit_star(surf, self.x, self.y, size, self.angle, col)
    elif self.shape == "square":
      s = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
      r = pygame.Surface((size * 2, size * 2), pygame.SRCALPHA)
      pygame.draw.rect(r, col, (0, 0, size * 2, size * 2), border_radius=max(1, size // 3))
      rot = pygame.transform.rotate(r, math.degrees(self.angle))
      surf.blit(rot, (self.x - rot.get_width() / 2, self.y - rot.get_height() / 2))
    elif self.shape == "streak":
      s = pygame.Surface((size * 6, size), pygame.SRCALPHA)
      pygame.draw.rect(s, col, (0, 0, size * 6, size), border_radius=size // 2)
      rot = pygame.transform.rotate(s, math.degrees(math.atan2(-self.vy, self.vx)))
      surf.blit(rot, (self.x - rot.get_width() / 2, self.y - rot.get_height() / 2))


def _blit_star(surf, cx, cy, size, angle, col) -> None:
  pts = []
  for i in range(10):
    r = size if i % 2 == 0 else size * 0.45
    a = angle + i * math.pi / 5
    pts.append((cx + math.cos(a) * r, cy + math.sin(a) * r))
  s = pygame.Surface((size * 2 + 4, size * 2 + 4), pygame.SRCALPHA)
  local = [(px - cx + size + 2, py - cy + size + 2) for px, py in pts]
  pygame.draw.polygon(s, col, local)
  surf.blit(s, (cx - size - 2, cy - size - 2))


class FloatingText:
  def __init__(self, text, x, y, color, font, life=1.2, vy=-46, scale_from=1.0, scale_to=1.0, shadow=True):
    self.text = text
    self.x = x
    self.y = y
    self.color = color
    self.font = font
    self.life = life
    self.max_life = life
    self.vy = vy
    self.scale_from = scale_from
    self.scale_to = scale_to
    self.shadow = shadow

  def update(self, dt: float) -> None:
    self.y += self.vy * dt
    self.vy *= 0.92
    self.life -= dt

  def draw(self, surf: pygame.Surface) -> None:
    t = max(0.0, self.life / self.max_life)
    alpha = int(255 * min(1.0, t * 2.5))
    scale = self.scale_to + (self.scale_from - self.scale_to) * t
    base = self.font.render(self.text, True, self.color)
    if scale != 1.0:
      base = pygame.transform.rotozoom(base, 0, scale)
    base.set_alpha(alpha)
    rect = base.get_rect(center=(self.x, self.y))
    if self.shadow:
      sh = self.font.render(self.text, True, (0, 0, 0))
      if scale != 1.0:
        sh = pygame.transform.rotozoom(sh, 0, scale)
      sh.set_alpha(int(alpha * 0.6))
      surf.blit(sh, sh.get_rect(center=(self.x + 2, self.y + 2)))
    surf.blit(base, rect)


class Ring:
  def __init__(self, x, y, max_r, color, life=0.5, width=6):
    self.x = x
    self.y = y
    self.max_r = max_r
    self.color = color
    self.life = life
    self.max_life = life
    self.width = width

  def update(self, dt: float) -> None:
    self.life -= dt

  def draw(self, surf: pygame.Surface) -> None:
    t = 1.0 - max(0.0, self.life / self.max_life)
    r = int(self.max_r * (0.2 + 0.8 * t))
    alpha = int(200 * (1.0 - t))
    if r <= 0 or alpha <= 0:
      return
    s = pygame.Surface((r * 2 + 4, r * 2 + 4), pygame.SRCALPHA)
    w = max(1, int(self.width * (1.0 - t) + 1))
    pygame.draw.circle(s, (*self.color, alpha), (r + 2, r + 2), r, w)
    surf.blit(s, (self.x - r - 2, self.y - r - 2))


class Beam:
  """발사체 — 시작점에서 목표(적)로 날아가며 도착 시 콜백 효과."""

  def __init__(self, x, y, tx, ty, color, speed=1400, size=10, on_hit=None):
    self.x = x
    self.y = y
    self.tx = tx
    self.ty = ty
    self.color = color
    self.size = size
    self.on_hit = on_hit
    d = math.hypot(tx - x, ty - y) or 1
    self.vx = (tx - x) / d * speed
    self.vy = (ty - y) / d * speed
    self.alive = True
    self.trail: list[tuple[float, float]] = []

  def update(self, dt: float) -> None:
    self.trail.append((self.x, self.y))
    if len(self.trail) > 8:
      self.trail.pop(0)
    self.x += self.vx * dt
    self.y += self.vy * dt
    if math.hypot(self.tx - self.x, self.ty - self.y) < 28:
      self.alive = False
      if self.on_hit:
        self.on_hit()

  def draw(self, surf: pygame.Surface) -> None:
    for i, (px, py) in enumerate(self.trail):
      a = int(120 * (i / max(1, len(self.trail))))
      r = int(self.size * (i / max(1, len(self.trail))))
      if r <= 0:
        continue
      s = pygame.Surface((r * 2, r * 2), pygame.SRCALPHA)
      pygame.draw.circle(s, (*self.color, a), (r, r), r)
      surf.blit(s, (px - r, py - r))
    s = pygame.Surface((self.size * 2, self.size * 2), pygame.SRCALPHA)
    pygame.draw.circle(s, (255, 255, 255, 230), (self.size, self.size), self.size)
    pygame.draw.circle(s, (*self.color, 255), (self.size, self.size), max(1, self.size - 3))
    surf.blit(s, (self.x - self.size, self.y - self.size))


class EffectManager:
  def __init__(self) -> None:
    self.particles: list[Particle] = []
    self.floaters: list[FloatingText] = []
    self.rings: list[Ring] = []
    self.beams: list[Beam] = []
    self.flashes: list[dict] = []
    self.screen_cracks: list[dict] = []
    self.shake_time = 0.0
    self.shake_mag = 0.0
    self.time = 0.0
    self.font_sm = get_font(18, bold=True)
    self.font_md = get_font(30, bold=True)
    self.font_lg = get_font(56, bold=True)
    self.font_xl = get_font(84, bold=True)
    self.ambient_tier = 0
    self.ambient_time = 0.0

  # ---- 업데이트 / 그리기 ----
  def update(self, dt: float) -> None:
    self.time += dt
    for p in self.particles:
      p.update(dt)
    for f in self.floaters:
      f.update(dt)
    for r in self.rings:
      r.update(dt)
    for b in self.beams:
      b.update(dt)
    for fl in self.flashes:
      fl["life"] -= dt
    for sc in self.screen_cracks:
      sc["life"] -= dt
      sc["progress"] = min(1.0, sc["progress"] + dt * 2.2)
    self.particles = [p for p in self.particles if p.life > 0 and -50 < p.x < SCREEN_W + 50 and p.y < SCREEN_H + 60]
    self.floaters = [f for f in self.floaters if f.life > 0]
    self.rings = [r for r in self.rings if r.life > 0]
    self.beams = [b for b in self.beams if b.alive]
    self.flashes = [f for f in self.flashes if f["life"] > 0]
    self.screen_cracks = [s for s in self.screen_cracks if s["life"] > 0]
    if self.shake_time > 0:
      self.shake_time -= dt

  def get_shake(self) -> tuple[int, int]:
    if self.shake_time <= 0:
      return 0, 0
    mag = self.shake_mag * (self.shake_time / 0.4 if self.shake_time < 0.4 else 1)
    return int(random.uniform(-mag, mag)), int(random.uniform(-mag, mag))

  def draw_world(self, surf: pygame.Surface) -> None:
    """화면 흔들림 오프셋과 함께 게임 위에 올라가는 파티클(월드 좌표)."""
    for r in self.rings:
      r.draw(surf)
    for p in self.particles:
      p.draw(surf)
    for b in self.beams:
      b.draw(surf)

  def set_ambient_tier(self, tier: int) -> None:
    if tier != self.ambient_tier:
      self.ambient_tier = tier
      self.ambient_time = 0.0

  def spawn_hand_preview(self, center: tuple[int, int], hand_label: str, tier: int) -> None:
    style = tier_style(tier)
    cx, cy = center
    color = style["color"]
    self.set_ambient_tier(tier)
    self.rings.append(Ring(cx, cy, 80 + tier * 12, color, life=0.35, width=4))
    self.burst(cx, cy, color, count=8 + tier * 4, speed=180 + tier * 30, size=4, gravity=100)
    if tier >= 2:
      self.add_flash(color, style["flash"] // 3, life=0.15, vignette=tier >= 3)
    if hand_label:
      self.floaters.append(FloatingText(
        hand_label, cx, cy - 50, color, self.font_md,
        life=0.9, vy=-12, scale_from=1.2, scale_to=0.95,
      ))

  def spawn_saint_devil_mark(self, center: tuple[int, int], name: str, is_devil: bool) -> None:
    """성인·악마 유해 — 추가 연출."""
    cx, cy = center
    self.add_shake(10.0, 0.4)
    if is_devil:
      core = (180, 30, 50)
      glow = (90, 10, 30)
      accent = (255, 70, 60)
      self.add_flash(glow, 100, life=0.4, vignette=True)
      for x in range(cx - 80, cx + 81, 40):
        self.beams.append(Beam(x, cy + 60, x, cy - 20, accent, speed=700, size=5))
      for i in range(3):
        self.rings.append(Ring(cx, cy, 30 + i * 24, accent, life=0.5 + i * 0.05, width=5))
      self.burst(cx, cy, core, count=30, speed=300, size=5, gravity=-80, shape="streak")
    else:
      glow = (255, 220, 120)
      core = (255, 240, 180)
      self.add_flash(glow, 80, life=0.35, vignette=True)
      for x in range(cx - 80, cx + 81, 40):
        self.beams.append(Beam(x, cy - 40, x, cy + 30, glow, speed=700, size=5))
      for i in range(3):
        self.rings.append(Ring(cx, cy, 28 + i * 22, glow, life=0.5 + i * 0.05, width=4))
      for k in range(8):
        a = k * math.tau / 8
        self.particles.append(Particle(
          cx, cy, math.cos(a) * 200, math.sin(a) * 200,
          0.45, core, 3, gravity=30, shape="star",
        ))

  def spawn_jaw_mark(self, center: tuple[int, int], jaw_name: str, tier_color: tuple[int, int, int]) -> None:
    cx, cy = center
    bite_color = (200, 50, 55)
    for i in range(4):
      self.rings.append(Ring(cx, cy, 34 + i * 26, bite_color, life=0.42 + i * 0.06, width=5))
    # 물린 자국처럼 좌우에서 안쪽으로 파고드는 붉은 파편
    for side in (-1, 1):
      for k in range(7):
        y = cy - 34 + k * 12
        self.beams.append(Beam(cx + side * 120, y, cx + side * 22, cy - 34 + k * 12, bite_color, speed=780, size=6))
        self.burst(cx + side * 24, y, bite_color, count=5, speed=180, size=4, gravity=90, shape="streak")
    self.burst(cx, cy, bite_color, count=70, speed=360, size=6, gravity=180, shape="square")
    self.burst(cx, cy, tier_color, count=36, speed=260, size=5, gravity=120, shape="star")
    self.beams.append(Beam(cx - 70, cy + 28, cx + 70, cy - 28, tier_color, speed=700, size=8))
    self.beams.append(Beam(cx + 70, cy + 28, cx - 70, cy - 28, tier_color, speed=700, size=8))
    self.add_flash(bite_color, 110, life=0.35, vignette=True)
    self.add_shake(8.0, 0.35)

  def spawn_joker_flip(self, center: tuple[int, int], face: int) -> None:
    cx, cy = center
    if face == 21:
      theme = tarot_theme(21)
      self.spawn_tarot(pygame.Rect(cx - 70, cy - 90, 140, 180), 21, big=True)
      for _ in range(3):
        self.rings.append(Ring(cx, cy, 200 + _ * 100, theme["accent"], life=0.7, width=10))
      self.add_flash(theme["c2"], 120, life=0.5, vignette=True)
      self.floaters.append(FloatingText("세계!", cx, cy - 80, theme["accent"], self.font_lg, life=1.4, vy=-20))
    else:
      theme = tarot_theme(0)
      self.spawn_tarot(pygame.Rect(cx - 70, cy - 90, 140, 180), 0, big=True)
      self.burst(cx, cy, theme["accent"], count=80, speed=400, size=7, gravity=50, shape="swirl")
      self.add_flash(theme["c2"], 90, life=0.45, vignette=True)
      self.floaters.append(FloatingText("바보!", cx, cy - 80, theme["accent"], self.font_lg, life=1.4, vy=-20))

  def spawn_world_swap(self) -> None:
    theme = tarot_theme(21)
    self.add_flash(theme["c2"], 100, life=0.55, vignette=True)
    self.add_shake(14.0, 0.5)
    for x in range(0, SCREEN_W, 120):
      self.burst(x, SCREEN_H // 2, theme["accent"], count=12, speed=300, size=5, gravity=0, shape="streak")

  def draw_overlay(self, surf: pygame.Surface) -> None:
    """흔들림과 무관하게 화면 전체에 올라가는 플래시/텍스트."""
    if self.ambient_tier > 0:
      style = tier_style(self.ambient_tier)
      pulse = 0.5 + 0.5 * math.sin(self.time * 2.5)
      alpha = int((10 + self.ambient_tier * 5) * pulse)
      s = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
      self._vignette(s, style["color"], alpha)
      surf.blit(s, (0, 0))
    for fl in self.flashes:
      t = max(0.0, fl["life"] / fl["max_life"])
      alpha = int(fl["max_alpha"] * t)
      if alpha <= 0:
        continue
      s = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
      if fl.get("vignette"):
        self._vignette(s, fl["color"], alpha)
      else:
        s.fill((*fl["color"], alpha))
      surf.blit(s, (0, 0))
    for f in self.floaters:
      f.draw(surf)
    for sc in self.screen_cracks:
      self._draw_screen_crack(surf, sc)

  def _draw_screen_crack(self, surf: pygame.Surface, sc: dict) -> None:
    t = max(0.0, sc["life"] / sc["max_life"])
    progress = sc["progress"]
    cx = SCREEN_W // 2
    gap = int(18 * progress * (1.0 + 0.3 * (1 - t)))
    overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
    alpha = int(200 * progress * t)
    # 좌우 패널이 벌어지며 중앙에 어두운 틈
    if gap > 0:
      pygame.draw.rect(overlay, (8, 4, 12, alpha), (cx - gap // 2, 0, gap, SCREEN_H))
    # 지그재그 균열선
    crack_alpha = int(255 * min(1.0, progress * 1.4) * t)
    if crack_alpha > 0:
      pts_l = []
      pts_r = []
      y = 0
      wobble = 0
      while y <= SCREEN_H:
        wobble = int(14 * math.sin(y * 0.04 + self.time * 8))
        pts_l.append((cx - 4 + wobble, y))
        pts_r.append((cx + 4 + wobble, y))
        y += 28
      col = (255, 220, 200, crack_alpha)
      if len(pts_l) >= 2:
        pygame.draw.lines(overlay, col, False, pts_l, 4)
        pygame.draw.lines(overlay, col, False, pts_r, 4)
      glow = (220, 60, 70, crack_alpha // 2)
      pygame.draw.lines(overlay, glow, False, pts_l, 8)
      pygame.draw.lines(overlay, glow, False, pts_r, 8)
    surf.blit(overlay, (0, 0))

  def _vignette(self, surf: pygame.Surface, color: Color, alpha: int) -> None:
    edge = 220
    for i in range(6):
      a = int(alpha * (i + 1) / 6)
      w = edge * (6 - i) // 6
      pygame.draw.rect(surf, (*color, a), (0, 0, SCREEN_W, w))
      pygame.draw.rect(surf, (*color, a), (0, SCREEN_H - w, SCREEN_W, w))
      pygame.draw.rect(surf, (*color, a), (0, 0, w, SCREEN_H))
      pygame.draw.rect(surf, (*color, a), (SCREEN_W - w, 0, w, SCREEN_H))

  # ---- 트리거 ----
  def add_shake(self, mag: float, dur: float = 0.4) -> None:
    self.shake_mag = max(self.shake_mag, mag)
    self.shake_time = max(self.shake_time, dur)

  def add_flash(self, color: Color, max_alpha: int, life: float = 0.35, vignette: bool = False) -> None:
    self.flashes.append({"color": color, "max_alpha": max_alpha, "life": life, "max_life": life, "vignette": vignette})

  def burst(self, x, y, color, count=20, speed=320, size=5, gravity=300, shape="circle", spread=math.tau, base_angle=0.0):
    for _ in range(count):
      a = base_angle + random.uniform(-spread / 2, spread / 2)
      spd = random.uniform(speed * 0.3, speed)
      self.particles.append(Particle(
        x, y, math.cos(a) * spd, math.sin(a) * spd,
        random.uniform(0.4, 0.9), color, random.uniform(size * 0.6, size * 1.4),
        gravity=gravity, shape=shape, spin=random.uniform(-8, 8),
      ))

  def spawn_draw(self, rect: pygame.Rect) -> None:
    cx, cy = rect.center
    self.rings.append(Ring(cx, cy, rect.w * 0.9, (120, 200, 255), life=0.4, width=5))
    self.burst(cx, cy, (150, 215, 255), count=14, speed=240, size=4, gravity=200, shape="circle")
    self.burst(cx, rect.top, (255, 255, 255), count=6, speed=160, size=3, gravity=-40, shape="streak")
    self.add_shake(2.0, 0.12)

  def spawn_tarot(self, rect: pygame.Rect, number: int, big: bool = False) -> None:
    theme = tarot_theme(number)
    cx, cy = rect.center
    accent = theme["accent"]
    c2 = theme["c2"]
    style = theme["style"]
    shape = {
      "star": "star", "sun": "star", "heart": "circle", "leaf": "circle",
      "ember": "circle", "holy": "star", "swirl": "square", "skull": "square",
      "dust": "circle", "spark": "streak",
    }.get(style, "circle")
    n = 60 if big else 36
    self.rings.append(Ring(cx, cy, rect.w * (2.2 if big else 1.4), accent, life=0.55, width=7))
    self.rings.append(Ring(cx, cy, rect.w * (1.4 if big else 0.9), c2, life=0.45, width=5))
    self.burst(cx, cy, accent, count=n, speed=380 if big else 300, size=6, gravity=120, shape=shape)
    self.burst(cx, cy, c2, count=n // 2, speed=240, size=8, gravity=80, shape="circle")
    # 위로 솟구치는 빛줄기
    for _ in range(10 if big else 6):
      self.particles.append(Particle(
        cx + random.uniform(-rect.w / 2, rect.w / 2), cy,
        random.uniform(-30, 30), random.uniform(-260, -160),
        random.uniform(0.5, 1.0), accent, random.uniform(3, 6),
        gravity=120, shape="streak",
      ))
    self.add_flash(c2, 45 if big else 28, life=0.3)
    self.add_shake(6.0 if big else 3.5, 0.25)

  def spawn_score(self, rect_center, hand_label: str, tier: int, total: int,
                  enemy_pos, fonts_label: str = "") -> None:
    style = tier_style(tier)
    cx, cy = rect_center
    color = style["color"]

    # 화면 플래시 + 비네팅
    self.add_flash(color, style["flash"], life=0.4, vignette=tier >= 3)
    self.add_shake(style["shake"], 0.45 + 0.05 * tier)

    # 다중 충격파 링
    for i in range(style["rings"]):
      delay_r = 120 + i * 90
      col = RAINBOW[i % len(RAINBOW)] if tier >= 5 else color
      self.rings.append(Ring(cx, cy, delay_r + 260, col, life=0.5 + 0.1 * i, width=8))

    # 파티클 대폭발
    count = style["particles"]
    if tier >= 5:
      for i in range(count):
        col = RAINBOW[i % len(RAINBOW)]
        a = random.uniform(0, math.tau)
        spd = random.uniform(160, 620)
        self.particles.append(Particle(
          cx, cy, math.cos(a) * spd, math.sin(a) * spd,
          random.uniform(0.6, 1.3), col, random.uniform(4, 9),
          gravity=260, shape=random.choice(["star", "circle", "square"]), spin=random.uniform(-10, 10),
        ))
    else:
      self.burst(cx, cy, color, count=count, speed=460, size=7, gravity=320,
                 shape="star" if tier >= 2 else "circle")
      self.burst(cx, cy, (255, 255, 255), count=count // 3, speed=300, size=4, gravity=200)

    # 족보 이름 텍스트 (펑 하고 커졌다 사라짐)
    label_font = self.font_xl if tier >= 4 else self.font_lg
    self.floaters.append(FloatingText(
      hand_label, cx, cy - 30, color, label_font,
      life=1.1, vy=-18, scale_from=1.8, scale_to=1.0,
    ))
    if style["label"]:
      self.floaters.append(FloatingText(
        style["label"], cx, cy + 36, (255, 255, 255), self.font_md,
        life=1.0, vy=-26, scale_from=1.4, scale_to=0.9,
      ))

  def spawn_damage_beam(self, start, enemy_pos, total: int, tier: int, on_hit) -> None:
    style = tier_style(tier)
    color = style["color"]
    self.beams.append(Beam(start[0], start[1], enemy_pos[0], enemy_pos[1], color,
                           speed=1500 + tier * 120, size=8 + tier * 2, on_hit=on_hit))

  def spawn_hit(self, pos, total: int, tier: int) -> None:
    style = tier_style(tier)
    color = style["color"]
    cx, cy = pos
    self.add_shake(style["shake"] * 0.8, 0.3)
    self.add_flash((255, 120, 120), 60, life=0.2)
    self.rings.append(Ring(cx, cy, 200, color, life=0.4, width=8))
    self.burst(cx, cy, color, count=40 + tier * 14, speed=520, size=7, gravity=420, shape="circle")
    self.burst(cx, cy, (255, 230, 200), count=18, speed=360, size=4, gravity=300, shape="streak")
    self.floaters.append(FloatingText(
      f"-{total:,}", cx, cy - 20, (255, 90, 90), self.font_lg,
      life=1.1, vy=-70, scale_from=1.6, scale_to=1.0,
    ))

  def spawn_kingslayer_crack(self) -> None:
    self.screen_cracks.append({"life": 0.9, "max_life": 0.9, "progress": 0.0})
    self.add_flash((40, 10, 20), 160, life=0.35, vignette=True)
    self.add_flash((220, 50, 60), 90, life=0.5, vignette=False)
    self.add_shake(14.0, 0.55)
    cx, cy = SCREEN_W // 2, SCREEN_H // 2
    self.burst(cx, cy, (255, 100, 90), count=50, speed=420, size=6, gravity=200, shape="streak")
    self.burst(cx, cy, (180, 30, 40), count=30, speed=300, size=5, gravity=150, shape="square")

  def spawn_enemy_defeat(self, pos) -> None:
    cx, cy = pos
    self.add_flash((255, 255, 255), 200, life=0.5, vignette=True)
    self.add_shake(26, 0.6)
    for i in range(160):
      col = RAINBOW[i % len(RAINBOW)]
      a = random.uniform(0, math.tau)
      spd = random.uniform(200, 700)
      self.particles.append(Particle(
        cx, cy, math.cos(a) * spd, math.sin(a) * spd,
        random.uniform(0.8, 1.6), col, random.uniform(5, 11),
        gravity=300, shape=random.choice(["star", "circle", "square"]), spin=random.uniform(-12, 12),
      ))
    self.floaters.append(FloatingText("처치!", cx, cy, (255, 240, 120), self.font_xl,
                                      life=1.4, vy=-30, scale_from=2.0, scale_to=1.1))
