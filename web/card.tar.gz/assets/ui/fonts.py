"""폰트 로더 — 번들된 Pretendard 를 사용해 두껍고 세련된 한글 렌더링.

데스크톱에는 시스템 한글 폰트가 있지만 pygbag(웹/WASM) 환경에는 없으므로
assets/fonts 에 번들한 Pretendard 정적 TTF 를 직접 로드한다.

- 본문(기본): SemiBold  → 가독성 높은 두께
- 강조(bold) : ExtraBold → 제목·연출용 굵은 두께
"""

from __future__ import annotations

import os

import pygame

_FONT_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "assets", "fonts")

# 두께별 후보 (앞쪽 우선). 없으면 다음 후보, 최종적으로 시스템 폰트로 폴백.
_REGULAR_CANDIDATES = (
  "Pretendard-SemiBold.ttf",
  "Pretendard-Bold.ttf",
  "NotoSansKR-Regular.ttf",
)
_BOLD_CANDIDATES = (
  "Pretendard-ExtraBold.ttf",
  "Pretendard-Bold.ttf",
  "NotoSansKR-Regular.ttf",
)
_SYSTEM_FALLBACK = "malgungothic,applegothic,notosanscjkkr,nanumgothic,sans"

_path_cache: dict[str, str | None] = {}


def _resolve(candidates: tuple[str, ...]) -> str | None:
  key = candidates[0]
  if key in _path_cache:
    return _path_cache[key]
  found: str | None = None
  for name in candidates:
    candidate = os.path.join(_FONT_DIR, name)
    if os.path.exists(candidate):
      found = candidate
      break
  _path_cache[key] = found
  return found


def get_font(size: int, *, bold: bool = False) -> pygame.font.Font:
  path = _resolve(_BOLD_CANDIDATES if bold else _REGULAR_CANDIDATES)
  if path:
    return pygame.font.Font(path, size)
  return pygame.font.SysFont(_SYSTEM_FALLBACK, size, bold=bold)
