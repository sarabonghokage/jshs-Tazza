"""연금술 UI — 원소 보유, 연성 슬롯, 아이템 목록."""

from __future__ import annotations

import pygame

from game.alchemy import (
  ALCHEMY_ITEMS,
  ESSENCE_COLORS,
  ESSENCE_LABELS,
  Essence,
  aggregate_item_stacks,
  get_item,
)
from game.constants import COLORS, SCREEN_W
from game.state import GameState, Phase


def _show_alchemy(state: GameState) -> bool:
  return state.phase in (
    Phase.BAN_SELECT, Phase.DRAW_PICK, Phase.FILL_HAND,
    Phase.SCORE, Phase.BATTLE_RESULT,
    Phase.TAROT_REWARD, Phase.UPGRADE_SELECT,
  )


def layout_alchemy(state: GameState, *, collapsed: bool = False) -> dict[str, pygame.Rect]:
  rects: dict[str, pygame.Rect] = {}
  if not _show_alchemy(state):
    return rects

  if collapsed:
    panel = pygame.Rect(12, 120, 276, 36)
    rects["panel"] = panel
    rects["toggle"] = pygame.Rect(panel.right - 34, panel.y + 4, 28, 28)
    return rects

  panel = pygame.Rect(12, 120, 276, 300)
  rects["panel"] = panel

  ess_y = panel.y + 40
  for i, ess in enumerate(Essence):
    rects[f"ess_{ess.value}"] = pygame.Rect(panel.x + 10 + i * 86, ess_y, 82, 34)

  slot_y = panel.y + 96
  for i in range(3):
    rects[f"slot_{i}"] = pygame.Rect(panel.x + 14 + i * 86, slot_y, 80, 48)

  btn_y = panel.y + 158
  rects["transmute"] = pygame.Rect(panel.x + 14, btn_y, 168, 40)
  rects["clear_slots"] = pygame.Rect(panel.x + 190, btn_y, 72, 40)
  rects["toggle"] = pygame.Rect(panel.right - 34, panel.y + 4, 28, 28)
  return rects


def draw_alchemy_panel(
  surface: pygame.Surface,
  state: GameState,
  rects: dict[str, pygame.Rect],
  font,
  font_sm,
  mouse_pos: tuple[int, int],
  *,
  collapsed: bool = False,
) -> None:
  if "panel" not in rects:
    return

  panel = rects["panel"]
  pygame.draw.rect(surface, COLORS["panel"], panel, border_radius=10)
  pygame.draw.rect(surface, (90, 75, 120), panel, 2, border_radius=10)

  title = font_sm.render("연금술", True, (200, 180, 230))
  surface.blit(title, (panel.x + 12, panel.y + 8))

  toggle = rects.get("toggle")
  if toggle:
    hover = toggle.collidepoint(mouse_pos)
    pygame.draw.rect(surface, COLORS["btn_hover"] if hover else (40, 44, 54), toggle, border_radius=4)
    sym = font_sm.render("▼" if collapsed else "▲", True, COLORS["text_dim"])
    surface.blit(sym, sym.get_rect(center=toggle.center))

  if collapsed:
    n = sum(state.item_stacks.values()) if state.item_stacks else 0
    hint = font_sm.render(f"원소 · 연성물 {n}종", True, COLORS["text_dim"])
    surface.blit(hint, (panel.x + 88, panel.y + 10))
    return

  inv = {
    Essence.SALT: state.essence_salt,
    Essence.SULFUR: state.essence_sulfur,
    Essence.MERCURY: state.essence_mercury,
  }
  for ess, count in inv.items():
    key = f"ess_{ess.value}"
    if key not in rects:
      continue
    r = rects[key]
    hover = r.collidepoint(mouse_pos) and count > 0
    col = ESSENCE_COLORS[ess]
    bg = tuple(min(255, c + 30) for c in col) if hover else (45, 48, 58)
    pygame.draw.rect(surface, bg, r, border_radius=6)
    pygame.draw.rect(surface, col, r, 2, border_radius=6)
    label = font_sm.render(f"{ESSENCE_LABELS[ess]} {count}", True, COLORS["text"])
    surface.blit(label, label.get_rect(center=r.center))

  for i in range(3):
    key = f"slot_{i}"
    if key not in rects:
      continue
    r = rects[key]
    hover = r.collidepoint(mouse_pos)
    pygame.draw.rect(surface, COLORS["slot_empty"] if not hover else COLORS["btn_hover"], r, border_radius=6)
    pygame.draw.rect(surface, COLORS["accent2"], r, 2, border_radius=6)
    slot_val = state.alchemy_slots[i] if i < len(state.alchemy_slots) else None
    if slot_val:
      try:
        ess = Essence(slot_val)
        t = font_sm.render(ESSENCE_LABELS[ess][:2], True, ESSENCE_COLORS[ess])
      except ValueError:
        t = font_sm.render("?", True, COLORS["text_dim"])
    else:
      t = font_sm.render("—", True, COLORS["text_dim"])
    surface.blit(t, t.get_rect(center=r.center))

  btn = rects.get("transmute")
  if btn:
    hover = btn.collidepoint(mouse_pos)
    filled = all(s is not None for s in state.alchemy_slots)
    color = COLORS["btn_hover"] if hover and filled else COLORS["btn"]
    pygame.draw.rect(surface, color, btn, border_radius=6)
    pygame.draw.rect(surface, COLORS["accent2"], btn, 2, border_radius=6)
    t = font_sm.render("연성", True, COLORS["text"] if filled else COLORS["text_dim"])
    surface.blit(t, t.get_rect(center=btn.center))

  clr = rects.get("clear_slots")
  if clr:
    hover = clr.collidepoint(mouse_pos)
    pygame.draw.rect(surface, COLORS["btn_hover"] if hover else (40, 44, 54), clr, border_radius=4)
    t = font_sm.render("비우기", True, COLORS["text_dim"])
    surface.blit(t, t.get_rect(center=clr.center))

  agg = aggregate_item_stacks(state.item_stacks)
  stats_y = panel.y + 214
  if state.item_stacks:
    parts: list[str] = []
    if agg.mult_flat:
      parts.append(f"배+{agg.mult_flat}")
    if agg.chip_flat:
      parts.append(f"칩+{agg.chip_flat}")
    if agg.damage_pct > 0:
      parts.append(f"합산피해+{int(agg.damage_pct * 100)}%")
    if agg.turn_limit:
      parts.append(f"턴+{agg.turn_limit}")
    if agg.tarot_uses:
      parts.append(f"타로+{agg.tarot_uses}")
    if agg.hand_mult_all:
      parts.append(f"족보+{agg.hand_mult_all}")
    if agg.chip_mult > 0:
      parts.append(f"칩×{1 + agg.chip_mult:.2f}")
    if agg.flush_mult:
      parts.append(f"플러시배+{agg.flush_mult}")
    if agg.straight_mult:
      parts.append(f"스트배+{agg.straight_mult}")
    if agg.set_mult:
      parts.append(f"페어배+{agg.set_mult}")
    if agg.face_chip:
      parts.append(f"그림칩+{agg.face_chip}")
    if agg.low_chip:
      parts.append(f"저끗칩+{agg.low_chip}")
    _blit_wrapped(surface, font_sm, " · ".join(parts), panel.x + 10, stats_y, panel.w - 20, COLORS["success"], max_lines=3)
  else:
    hint = font_sm.render("적 처치 시 원소 드랍", True, COLORS["text_dim"])
    surface.blit(hint, (panel.x + 10, stats_y))

  if len(state.item_stacks) > 0:
    items_line = ", ".join(
      f"{get_item(iid).name[:10]}×{n}"
      for iid, n in sorted(state.item_stacks.items())
      if n > 0
    )
    _blit_wrapped(surface, font_sm, items_line, panel.x + 10, panel.y + 256, panel.w - 20, COLORS["accent"], max_lines=4)


def _blit_wrapped(
  surface: pygame.Surface,
  font,
  text: str,
  x: int,
  y: int,
  max_w: int,
  color: tuple[int, int, int],
  *,
  max_lines: int = 2,
) -> None:
  words = text.split(" ")
  lines: list[str] = []
  cur = ""
  for w in words:
    trial = f"{cur} {w}".strip()
    if font.size(trial)[0] <= max_w or not cur:
      cur = trial
    else:
      lines.append(cur)
      cur = w
  if cur:
    lines.append(cur)
  for i, line in enumerate(lines[:max_lines]):
    if i == max_lines - 1 and len(lines) > max_lines:
      while font.size(line + "…")[0] > max_w and line:
        line = line[:-1]
      line += "…"
    surface.blit(font.render(line, True, color), (x, y + i * 18))


def alchemy_click_action(state: GameState, pos: tuple[int, int], rects: dict[str, pygame.Rect]) -> str | None:
  if not _show_alchemy(state):
    return None
  if "toggle" in rects and rects["toggle"].collidepoint(pos):
    return "alchemy_toggle"
  for ess in Essence:
    key = f"ess_{ess.value}"
    if key in rects and rects[key].collidepoint(pos):
      return f"alchemy_add_{ess.value}"
  for i in range(3):
    key = f"slot_{i}"
    if key in rects and rects[key].collidepoint(pos):
      return f"alchemy_slot_{i}"
  if "transmute" in rects and rects["transmute"].collidepoint(pos):
    return "alchemy_transmute"
  if "clear_slots" in rects and rects["clear_slots"].collidepoint(pos):
    return "alchemy_clear"
  return None
