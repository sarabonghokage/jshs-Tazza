"""유니코드 대신 pygame 도형으로 카드 문양을 그립니다."""

from __future__ import annotations

import pygame

from game.constants import SUIT_COLORS


def draw_suit(
  surface: pygame.Surface,
  suit: str,
  center: tuple[int, int],
  size: int,
  color: tuple[int, int, int] | None = None,
) -> None:
  color = color or SUIT_COLORS[suit]
  cx, cy = center
  if suit == "hearts":
    _draw_heart(surface, cx, cy, size, color)
  elif suit == "diamonds":
    _draw_diamond(surface, cx, cy, size, color)
  elif suit == "clubs":
    _draw_club(surface, cx, cy, size, color)
  elif suit == "spades":
    _draw_spade(surface, cx, cy, size, color)


def _draw_heart(surface: pygame.Surface, cx: int, cy: int, size: int, color: tuple[int, int, int]) -> None:
  r = size // 4
  pygame.draw.circle(surface, color, (cx - r, cy - r // 2), r)
  pygame.draw.circle(surface, color, (cx + r, cy - r // 2), r)
  points = [(cx - size // 2, cy - r // 2), (cx + size // 2, cy - r // 2), (cx, cy + size // 2)]
  pygame.draw.polygon(surface, color, points)


def _draw_diamond(surface: pygame.Surface, cx: int, cy: int, size: int, color: tuple[int, int, int]) -> None:
  h = size // 2
  w = size // 3
  points = [(cx, cy - h), (cx + w, cy), (cx, cy + h), (cx - w, cy)]
  pygame.draw.polygon(surface, color, points)


def _draw_club(surface: pygame.Surface, cx: int, cy: int, size: int, color: tuple[int, int, int]) -> None:
  r = size // 5
  pygame.draw.circle(surface, color, (cx, cy - r), r)
  pygame.draw.circle(surface, color, (cx - r, cy + r // 2), r)
  pygame.draw.circle(surface, color, (cx + r, cy + r // 2), r)
  stem_h = size // 3
  pygame.draw.rect(surface, color, pygame.Rect(cx - r // 3, cy + r, r * 2 // 3, stem_h))


def _draw_spade(surface: pygame.Surface, cx: int, cy: int, size: int, color: tuple[int, int, int]) -> None:
  h = size // 2
  w = size // 3
  points = [(cx, cy - h), (cx + w, cy), (cx, cy + h // 3), (cx - w, cy)]
  pygame.draw.polygon(surface, color, points)
  r = size // 6
  pygame.draw.circle(surface, color, (cx - r * 2, cy + r), r)
  pygame.draw.circle(surface, color, (cx + r * 2, cy + r), r)
  stem_h = size // 4
  pygame.draw.rect(surface, color, pygame.Rect(cx - r // 2, cy + h // 3, r, stem_h))


SUIT_LABELS_KO = {
  "hearts": "하트",
  "diamonds": "다이아",
  "clubs": "클럽",
  "spades": "스페이드",
}
