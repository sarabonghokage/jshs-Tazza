from __future__ import annotations

import pygame

from game.card import TarotCard
from game.constants import COLORS, HAND_LABELS_KO, HAND_MULTIPLIERS, SCREEN_H, SCREEN_W
from game.tarot_data import get_tarot_def, ranks_to_text, tarot_match_text


def _wrap_lines(text: str, font: pygame.font.Font, max_w: int) -> list[str]:
  if font.size(text)[0] <= max_w:
    return [text]

  def flush_word(word: str, lines: list[str], buf: str) -> str:
    # 한 단어가 줄 너비보다 길면 글자 단위로 쪼갬
    for ch in word:
      trial = buf + ch
      if buf and font.size(trial)[0] > max_w:
        lines.append(buf)
        buf = ch
      else:
        buf = trial
    return buf

  lines: list[str] = []
  buf = ""
  for word in text.split(" "):
    candidate = word if not buf else buf + " " + word
    if font.size(candidate)[0] <= max_w:
      buf = candidate
      continue
    if buf:
      lines.append(buf)
      buf = ""
    if font.size(word)[0] <= max_w:
      buf = word
    else:
      buf = flush_word(word, lines, "")
  if buf:
    lines.append(buf)
  return lines


def draw_tarot_detail(
  surface: pygame.Surface,
  tarot: TarotCard,
  font: pygame.font.Font,
  font_sm: pygame.font.Font,
  font_lg: pygame.font.Font,
  *,
  x: int = 0,
  y: int = 0,
  width: int = 340,
  compact: bool = False,
) -> pygame.Rect:
  defn = get_tarot_def(tarot.number)
  pad = 16
  inner_w = width - pad * 2

  # 제목은 작은 제목 폰트로(긴 이름은 줄바꿈)
  title_font = font
  title_lines = _wrap_lines(f"{tarot.number}. {defn.name}", title_font, inner_w)
  match_lines = _wrap_lines(tarot_match_text(tarot.number), font_sm, inner_w)

  sections = [
    ("카드로 낼 때", defn.effect_play),
    ("강화 시", defn.effect_enhance),
  ]
  title_h = title_font.get_height() + 2
  line_h = 18 if compact else 20

  panel_h = pad
  panel_h += len(title_lines) * title_h + 4
  panel_h += len(match_lines) * line_h + 6
  for _, text in sections:
    panel_h += line_h  # 라벨
    panel_h += len(_wrap_lines(text, font_sm, inner_w)) * line_h
    panel_h += 4
  panel_h += pad - 4

  if x == 0:
    x = SCREEN_W // 2 - width // 2
  # 화면 밖으로 나가지 않게 보정
  x = max(8, min(x, SCREEN_W - width - 8))
  y = max(8, min(y, SCREEN_H - panel_h - 8))

  rect = pygame.Rect(x, y, width, panel_h)
  pygame.draw.rect(surface, (28, 32, 48), rect, border_radius=12)
  pygame.draw.rect(surface, COLORS["accent2"], rect, 2, border_radius=12)

  ly = rect.y + pad
  for line in title_lines:
    t = title_font.render(line, True, COLORS["accent2"])
    surface.blit(t, (rect.x + pad, ly))
    ly += title_h
  ly += 4
  for line in match_lines:
    t = font_sm.render(line, True, COLORS["text_dim"])
    surface.blit(t, (rect.x + pad, ly))
    ly += line_h
  ly += 6

  for label, text in sections:
    lbl = font_sm.render(f"[{label}]", True, COLORS["accent"])
    surface.blit(lbl, (rect.x + pad, ly))
    ly += line_h
    for line in _wrap_lines(text, font_sm, inner_w):
      val = font_sm.render(line, True, COLORS["text"])
      surface.blit(val, (rect.x + pad, ly))
      ly += line_h
    ly += 4

  return rect


def draw_tarot_tooltip(
  surface: pygame.Surface,
  tarot: TarotCard,
  font_sm: pygame.font.Font,
  pos: tuple[int, int],
) -> None:
  defn = get_tarot_def(tarot.number)
  lines = [
    f"{tarot.number}. {defn.name}",
    f"대응: {ranks_to_text(defn.matching_ranks)}",
    f"강화: {defn.effect_enhance[:42]}{'…' if len(defn.effect_enhance) > 42 else ''}",
  ]
  w = max(font_sm.size(line)[0] for line in lines) + 24
  h = len(lines) * 20 + 14
  x = min(pos[0] + 16, SCREEN_W - w - 8)
  y = max(8, pos[1] - h - 8)
  rect = pygame.Rect(x, y, w, h)
  pygame.draw.rect(surface, (20, 24, 32), rect, border_radius=8)
  pygame.draw.rect(surface, COLORS["accent2"], rect, 1, border_radius=8)
  hint = font_sm.render("클릭하여 사용", True, COLORS["text_dim"])
  for i, line in enumerate(lines):
    t = font_sm.render(line, True, COLORS["text"])
    surface.blit(t, (rect.x + 10, rect.y + 8 + i * 20))
  surface.blit(hint, (rect.x + 10, rect.bottom - 20))


def draw_hand_reference(
  surface: pygame.Surface,
  font_sm: pygame.font.Font,
  rect: pygame.Rect,
) -> None:
  pygame.draw.rect(surface, COLORS["panel"], rect, border_radius=10)
  title = font_sm.render("족보 배수 (희귀↑)", True, COLORS["accent"])
  surface.blit(title, (rect.x + 10, rect.y + 8))
  ordered = sorted(HAND_MULTIPLIERS.items(), key=lambda x: x[1])
  col_w = rect.w // 2 - 8
  for i, (key, mult) in enumerate(ordered):
    col = i // 8
    row = i % 8
    x = rect.x + 10 + col * col_w
    y = rect.y + 28 + row * 16
    label = HAND_LABELS_KO.get(key, key)
    txt = font_sm.render(f"{label} ×{mult}", True, COLORS["text_dim"])
    surface.blit(txt, (x, y))
