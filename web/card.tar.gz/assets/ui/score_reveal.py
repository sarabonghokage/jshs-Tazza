"""점수 합산 단계별 연출."""

from __future__ import annotations

import math

import pygame

from game.constants import COLORS
from game.score_steps import ScoreRevealStep
from ui.effects import Beam, FloatingText, Ring
from ui.fonts import get_font
from ui.themes import tier_style


class ScoreRevealPlayer:
  STAGE_MAIN = "main"
  STAGE_CRACK = "crack"
  STAGE_FINALE = "finale"

  def __init__(self) -> None:
    self.font = get_font(22)
    self.font_lg = get_font(28, bold=True)
    self.font_xl = get_font(36, bold=True)
    self.font_sm = get_font(16)
    self.steps: list[ScoreRevealStep] = []
    self.finale_steps: list[ScoreRevealStep] = []
    self.index = -1
    self.timer = 0.0
    self.step_duration = 0.42
    self.crack_duration = 0.75
    self.crack_timer = 0.0
    self.stage = self.STAGE_MAIN
    self.done = False
    self.active = False
    self.hand_tier = 0
    self._total_fired = False
    self.pending_total_fx = False

  def reset(self) -> None:
    self.steps = []
    self.finale_steps = []
    self.index = -1
    self.timer = 0.0
    self.crack_timer = 0.0
    self.stage = self.STAGE_MAIN
    self.done = False
    self.active = False
    self.hand_tier = 0
    self._total_fired = False
    self.pending_total_fx = False

  def start(
    self,
    steps: list[ScoreRevealStep],
    hand_tier: int,
    *,
    finale_steps: list[ScoreRevealStep] | None = None,
  ) -> None:
    self.reset()
    self.steps = steps
    self.finale_steps = finale_steps or []
    self.hand_tier = hand_tier
    self.active = bool(steps)
    if self.active:
      self.index = 0
      self.timer = 0.0

  @property
  def ready_for_damage(self) -> bool:
    if not self.done:
      return False
    if self.stage == self.STAGE_MAIN and self.finale_steps:
      return False
    return True

  @property
  def in_crack(self) -> bool:
    return self.stage == self.STAGE_CRACK

  def skip_crack(self) -> None:
    if self.stage != self.STAGE_CRACK:
      return
    self._begin_finale()

  def skip_to_end(self) -> None:
    if not self.active:
      return
    if self.stage == self.STAGE_CRACK:
      self._begin_finale()
      self.index = len(self.steps) - 1
      self.timer = self.step_duration
      self.done = True
      if self.steps and self.steps[-1].kind in ("total", "bonus", "kingslayer"):
        self.pending_total_fx = not self._total_fired
      return
    if self.stage == self.STAGE_MAIN and self.finale_steps:
      self.stage = self.STAGE_CRACK
      self.crack_timer = 0.0
      self.done = False
      return
    self.index = len(self.steps) - 1
    self.timer = self.step_duration
    self.done = True
    if self.steps and self.steps[-1].kind in ("total", "bonus", "kingslayer"):
      self.pending_total_fx = not self._total_fired

  def update(self, dt: float) -> str | None:
    if not self.active:
      return None
    if self.stage == self.STAGE_CRACK:
      self.crack_timer -= dt
      if self.crack_timer <= 0:
        self._begin_finale()
      return None
    if self.done:
      return None
    self.timer += dt
    while self.timer >= self.step_duration and self.index < len(self.steps) - 1:
      self.timer -= self.step_duration
      self.index += 1
      step = self.steps[self.index]
      if step.kind in ("total", "kingslayer"):
        self.pending_total_fx = True
    if self.index >= len(self.steps) - 1 and self.timer >= self.step_duration:
      self.done = True
      last = self.steps[-1] if self.steps else None
      if last and last.kind == "bonus":
        self.pending_total_fx = not self._total_fired
      elif last and last.kind in ("total", "kingslayer"):
        self.pending_total_fx = not self._total_fired
      if self.stage == self.STAGE_MAIN and self.finale_steps:
        self.stage = self.STAGE_CRACK
        self.crack_timer = self.crack_duration
        self.done = False
        return "crack_start"
    return None

  def _begin_finale(self) -> None:
    self.stage = self.STAGE_FINALE
    self.steps = self.finale_steps
    self.finale_steps = []
    self.index = 0
    self.timer = 0.0
    self.done = False
    self.active = bool(self.steps)
    self._total_fired = False
    self.pending_total_fx = False

  def consume_total_fx(self) -> ScoreRevealStep | None:
    if not self.pending_total_fx:
      return None
    self.pending_total_fx = False
    self._total_fired = True
    for step in reversed(self.steps):
      if step.kind in ("total", "bonus", "kingslayer"):
        return step
    return self.steps[-1] if self.steps else None

  @property
  def current(self) -> ScoreRevealStep | None:
    if not self.active or self.in_crack or self.index < 0 or self.index >= len(self.steps):
      return None
    return self.steps[self.index]

  @property
  def display_chips(self) -> int:
    cur = self.current
    return cur.chips if cur else 0

  @property
  def display_mult(self) -> int:
    cur = self.current
    return cur.mult if cur and cur.mult else 1

  @property
  def highlight_slots(self) -> tuple[int, ...]:
    cur = self.current
    if not cur:
      return ()
    if cur.kind == "card_chip" and cur.slot is not None:
      return (cur.slot,)
    if cur.kind == "jaw_chip" and cur.slot is not None:
      slots = [cur.slot]
      slots.extend(s for s in cur.highlight_slots if s != cur.slot)
      return tuple(dict.fromkeys(slots))
    return cur.highlight_slots

  def draw_panel(self, surf: pygame.Surface, center_x: int, y: int) -> None:
    if self.in_crack:
      panel = pygame.Rect(center_x - 220, y, 440, 118)
      pygame.draw.rect(surf, COLORS["panel"], panel, border_radius=12)
      pygame.draw.rect(surf, (200, 50, 60), panel, 3, border_radius=12)
      t0 = self.font_sm.render("왕을 죽이는 검", True, COLORS["text_dim"])
      surf.blit(t0, (panel.x + 14, panel.y + 10))
      t1 = self.font_xl.render("화면이 갈라진다...", True, (255, 120, 120))
      surf.blit(t1, t1.get_rect(center=(panel.centerx, panel.y + 58)))
      return
    if not self.active or not self.current:
      return
    step = self.current
    style = tier_style(self.hand_tier)
    pulse = 0.5 + 0.5 * math.sin(pygame.time.get_ticks() * 0.008)
    panel = pygame.Rect(center_x - 220, y, 440, 118)
    pygame.draw.rect(surf, COLORS["panel"], panel, border_radius=12)
    border_col = style["color"] if step.kind in ("hand", "total", "bonus") else COLORS["accent"]
    if step.kind in ("kingslayer", "kingslayer_crack"):
      border_col = (220, 60, 70)
    bw = 3 if step.kind in ("total", "bonus", "kingslayer") else 2
    pygame.draw.rect(surf, border_col, panel, bw, border_radius=12)

    title = {
      "card_chip": "칩 합산",
      "jaw_chip": "턱 효과",
      "chip_bonus": "칩 보너스",
      "chip_mult": "칩 배율",
      "hand": "족보",
      "mult": "배수",
      "devil": "악마",
      "total": "합산",
      "bonus": "추가 피해",
      "kingslayer": "왕을 죽이는 검",
      "kingslayer_crack": "검격",
    }.get(step.kind, "합산")
    t0 = self.font_sm.render(title, True, COLORS["text_dim"])
    surf.blit(t0, (panel.x + 14, panel.y + 10))

    font = self.font_xl if step.kind in ("total", "bonus", "hand", "kingslayer") else self.font_lg
    color = style["color"] if step.kind in ("hand", "total", "bonus") else COLORS["text"]
    if step.kind in ("kingslayer", "kingslayer_crack"):
      color = (255, 140, 130)
    t1 = font.render(step.text, True, color)
    surf.blit(t1, t1.get_rect(center=(panel.centerx, panel.y + 52)))

    if step.kind not in ("card_chip", "jaw_chip", "kingslayer_crack"):
      chip_txt = self.font_sm.render(f"칩 {step.chips}", True, COLORS["accent2"])
      mult_txt = self.font_sm.render(f"배수 {step.mult}x", True, COLORS["accent"])
      surf.blit(chip_txt, (panel.x + 14, panel.y + 86))
      surf.blit(mult_txt, (panel.right - mult_txt.get_width() - 14, panel.y + 86))
    elif step.kind != "kingslayer_crack":
      chip_txt = self.font.render(f"누적 {step.chips}", True, COLORS["accent2"])
      surf.blit(chip_txt, chip_txt.get_rect(center=(panel.centerx, panel.y + 88)))

    if step.kind in ("total", "kingslayer"):
      glow = pygame.Surface((panel.w, panel.h), pygame.SRCALPHA)
      glow_col = style["color"] if step.kind == "total" else (220, 70, 70)
      a = int(40 + 35 * pulse)
      pygame.draw.rect(glow, (*glow_col, a), (0, 0, panel.w, panel.h), border_radius=12)
      surf.blit(glow, panel.topleft)

  def spawn_step_fx(self, fx, slot_center: tuple[int, int] | None, step: ScoreRevealStep, renderer=None) -> None:
    if step.artifact_id:
      from ui.artifact_fx import spawn_artifact_activate
      anchor = renderer.artifact_strip_anchor() if renderer else (120, 64)
      use_slot = step.artifact_id in ("pale_note", "silver_feather", "red_bowl")
      spawn_artifact_activate(
        fx, step.artifact_id, anchor,
        slot_center=slot_center if use_slot else None,
      )
    if step.kind == "card_chip" and slot_center:
      self._spawn_chip_fx(fx, slot_center, step.chip_value, (120, 220, 255), (120, 200, 255))
    elif step.kind == "jaw_chip":
      jaw_color = (255, 200, 120)
      ring_color = (255, 170, 80)
      centers: list[tuple[int, int]] = []
      if renderer is not None:
        for slot in self.highlight_slots:
          center = renderer.slot_center(slot)
          if center:
            centers.append(center)
      elif slot_center:
        centers.append(slot_center)
      for i, center in enumerate(centers):
        if i == 0:
          self._spawn_chip_fx(fx, center, step.chip_value, jaw_color, ring_color, scale_from=1.4)
        else:
          self._spawn_chip_fx(fx, center, step.chip_value, jaw_color, ring_color, show_text=False)
    elif step.kind == "hand":
      fx.add_flash(tier_style(self.hand_tier)["color"], 50, life=0.2)
      fx.add_shake(3.0, 0.15)
    elif step.kind in ("total", "bonus"):
      fx.add_shake(4.0, 0.2)
    elif step.kind == "kingslayer":
      fx.add_shake(10.0, 0.45)
      fx.add_flash((220, 50, 60), 140, life=0.45, vignette=True)
      cx = slot_center[0] if slot_center else 640
      cy = slot_center[1] if slot_center else 360
      fx.beams.append(Beam(
        cx - 200, cy - 120, cx + 200, cy + 120, (255, 80, 80), speed=900, size=10,
      ))

  def _spawn_chip_fx(
    self,
    fx,
    center: tuple[int, int],
    value: int,
    text_color: tuple[int, int, int],
    ring_color: tuple[int, int, int],
    *,
    scale_from: float = 1.3,
    show_text: bool = True,
  ) -> None:
    if show_text:
      fx.floaters.append(FloatingText(
        f"+{value}",
        center[0], center[1] - 20,
        text_color, fx.font_md,
        life=0.7, vy=-40, scale_from=scale_from, scale_to=1.0,
      ))
    fx.rings.append(Ring(
      center[0], center[1], 36, ring_color, life=0.35, width=3,
    ))
