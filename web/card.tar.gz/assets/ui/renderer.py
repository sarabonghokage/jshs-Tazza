from __future__ import annotations

import math
from typing import TYPE_CHECKING

import pygame

if TYPE_CHECKING:
  from ui.score_reveal import ScoreRevealPlayer

from game.artifact_runtime import has_artifact
from game.artifacts import RARITY_COLORS, RARITY_LABELS, get_artifact
from game.artifact_effects import KINGSLAYER_CHIP_PCT, card_visual_mods
from game.constants import (
  CARD_GAP,
  CARD_H,
  CARD_W,
  COLORS,
  HAND_SIZE,
  SCREEN_H,
  SCREEN_W,
  SUIT_COLORS,
  SUITS,
)
from game.state import GameState, Phase, SubPhase
from ui.alchemy_panel import alchemy_click_action, draw_alchemy_panel, layout_alchemy
from ui.discard_panel import draw_discard_panel
from ui.fonts import get_font
from ui.suits import SUIT_LABELS_KO, draw_suit
from ui.tarot_panel import draw_hand_reference, draw_tarot_detail, draw_tarot_tooltip
from ui.themes import tarot_theme

# 손패를 가릴 수 있어 접기/펼치기를 지원하는 선택 단계들
COLLAPSIBLE_POOL_SUBPHASES = (
  SubPhase.PICK_FIVE,
  SubPhase.DEATH_PICK_THREE,
  SubPhase.MOON_PICK_DRAW,
  SubPhase.PRIESTESS_PICK,
  SubPhase.ACOLYTE_PICK,
  SubPhase.JOKER_TRANSFORM,
  SubPhase.JIRI_DECK_PICK,
)

# 확정 버튼과 접기 토글이 동시에 뜨는 선택 단계 — 가로로 나란히 배치한다
CONFIRM_WITH_TOGGLE_SUBPHASES = (
  SubPhase.DEATH_PICK_THREE,
  SubPhase.MOON_PICK_DRAW,
)


# 번들 폰트에 없는 화살표 글리프 — 도형으로 직접 그린다
_ARROW_DIRS = {"◀": "left", "▶": "right", "▲": "up", "▼": "down"}


def draw_triangle(
  surface: pygame.Surface,
  center: tuple[int, int],
  size: int,
  direction: str,
  color: tuple[int, int, int],
) -> None:
  cx, cy = center
  h = size
  if direction == "left":
    pts = [(cx + h // 2, cy - h), (cx + h // 2, cy + h), (cx - h, cy)]
  elif direction == "right":
    pts = [(cx - h // 2, cy - h), (cx - h // 2, cy + h), (cx + h, cy)]
  elif direction == "up":
    pts = [(cx - h, cy + h // 2), (cx + h, cy + h // 2), (cx, cy - h)]
  else:  # down
    pts = [(cx - h, cy - h // 2), (cx + h, cy - h // 2), (cx, cy + h)]
  pygame.draw.polygon(surface, color, pts)


class Button:
  def __init__(self, rect: pygame.Rect, label: str, action: str, enabled: bool = True) -> None:
    self.rect = rect
    self.label = label
    self.action = action
    self.enabled = enabled

  def draw(self, surface: pygame.Surface, font: pygame.font.Font, hover: bool, suit: str | None = None) -> None:
    color = COLORS["btn_hover"] if hover and self.enabled else COLORS["btn"]
    if not self.enabled:
      color = (40, 45, 55)
    pygame.draw.rect(surface, color, self.rect, border_radius=8)
    pygame.draw.rect(surface, COLORS["accent"], self.rect, 2, border_radius=8)
    fg = COLORS["text"] if self.enabled else COLORS["text_dim"]
    if self.label in _ARROW_DIRS:
      draw_triangle(surface, self.rect.center, 9, _ARROW_DIRS[self.label], fg)
      return
    text = font.render(self.label, True, fg)
    text_y = self.rect.centery - 6 if suit else self.rect.centery
    surface.blit(text, text.get_rect(center=(self.rect.centerx, text_y)))
    if suit and self.enabled:
      draw_suit(surface, suit, (self.rect.centerx, self.rect.centery + 14), 14, SUIT_COLORS[suit])

  def hit(self, pos: tuple[int, int]) -> bool:
    return self.enabled and self.rect.collidepoint(pos)


class Renderer:
  def __init__(self, screen: pygame.Surface) -> None:
    self.screen = screen
    self.font = get_font(22)
    self.font_sm = get_font(16)
    self.font_lg = get_font(30)
    self.font_title = get_font(36, bold=True)
    self.card_rects: list[pygame.Rect] = []
    self.hand_slot_rects: list[pygame.Rect] = []
    self.tarot_rects: list[tuple[pygame.Rect, TarotCard]] = []
    self.kingslayer_rect: pygame.Rect | None = None
    self.starter_tarot_rects: list[pygame.Rect] = []
    self.reward_tarot_rects: list[pygame.Rect] = []
    self.artifact_reward_rects: list[pygame.Rect] = []
    self.upgrade_tarot_rects: list[tuple[pygame.Rect, TarotCard]] = []
    self.upgrade_hand_rects: list[tuple[pygame.Rect, str]] = []
    self.jaw_card_rects: list[pygame.Rect] = []
    self.jaw_offer_rects: list[pygame.Rect] = []
    self.well_deck_rects: list[pygame.Rect] = []
    self._well_deck_indices: list[int] = []
    self.buttons: list[Button] = []
    self._suit_btn_map: dict[str, str] = {}
    self._pool_rects: list[pygame.Rect] = []
    self._rank_btn_rects: list[tuple[pygame.Rect, int]] = []
    self._layout_card_w = CARD_W
    self._layout_card_h = CARD_H
    self._hovered_tarot: TarotCard | None = None
    self.alchemy_rects: dict[str, pygame.Rect] = {}
    self._artifact_stacks: dict[str, int] = {}
    self.time = 0.0
    self.selection_collapsed = False
    self._last_pool_subphase: SubPhase | None = None
    self._preview_rects: list[pygame.Rect] = []
    self.alchemy_collapsed = False
    self.banned_collapsed = True

  def layout(self, state: GameState) -> None:
    self.buttons.clear()
    self._pool_rects.clear()
    self._rank_btn_rects.clear()
    self.card_rects.clear()
    self.hand_slot_rects.clear()
    self.tarot_rects.clear()
    self.kingslayer_rect = None
    self.starter_tarot_rects.clear()
    self.reward_tarot_rects.clear()
    self.artifact_reward_rects.clear()
    self.upgrade_tarot_rects.clear()
    self.upgrade_hand_rects.clear()
    self.jaw_card_rects.clear()
    self.jaw_offer_rects.clear()
    self.well_deck_rects.clear()
    self._well_deck_indices.clear()
    self.alchemy_rects = layout_alchemy(state, collapsed=self.alchemy_collapsed)

    btn_y = 548
    if state.phase == Phase.MAIN_MENU:
      from game.persistence import has_saved_game
      if has_saved_game():
        self.buttons.append(Button(
          pygame.Rect(SCREEN_W // 2 - 120, SCREEN_H // 2 + 24, 240, 46),
          "이어하기", "continue_run",
        ))
        self.buttons.append(Button(
          pygame.Rect(SCREEN_W // 2 - 120, SCREEN_H // 2 + 78, 240, 46),
          "새 게임", "begin_run",
        ))
        self.buttons.append(Button(
          pygame.Rect(SCREEN_W // 2 - 120, SCREEN_H // 2 + 132, 240, 46),
          "랭킹 보기", "show_records",
        ))
      else:
        self.buttons.append(Button(
          pygame.Rect(SCREEN_W // 2 - 120, SCREEN_H // 2 + 36, 240, 50),
          "게임 시작", "begin_run",
        ))
        self.buttons.append(Button(
          pygame.Rect(SCREEN_W // 2 - 120, SCREEN_H // 2 + 96, 240, 46),
          "랭킹 보기", "show_records",
        ))
      return

    if state.phase == Phase.RECORDS:
      self.buttons.append(Button(
        pygame.Rect(80, 88, 150, 40), "내 기록", "records_tab_local",
        enabled=state.records_tab != "local",
      ))
      self.buttons.append(Button(
        pygame.Rect(240, 88, 150, 40), "전체 랭킹", "records_tab_global",
        enabled=state.records_tab != "global",
      ))
      self.buttons.append(Button(
        pygame.Rect(SCREEN_W - 280, 88, 120, 40),
        "이름 저장" if state.name_editing else "이름 변경",
        "toggle_name_edit",
      ))
      if state.records_tab == "global":
        self.buttons.append(Button(
          pygame.Rect(420, 88, 130, 40), "스테이지순", "records_sort_stage",
          enabled=state.records_global_sort != "stage",
        ))
        self.buttons.append(Button(
          pygame.Rect(560, 88, 130, 40), "데미지순", "records_sort_damage",
          enabled=state.records_global_sort != "damage",
        ))
      self.buttons.append(Button(
        pygame.Rect(SCREEN_W // 2 - 120, SCREEN_H - 120, 240, 50),
        "뒤로", "back_main",
      ))
      return

    if state.phase == Phase.TAROT_PICK:
      tw = 140
      gap = 24
      total = 3 * tw + 2 * gap
      sx = (SCREEN_W - total) // 2
      for i in range(len(state.starter_tarot_choices)):
        self.starter_tarot_rects.append(pygame.Rect(sx + i * (tw + gap), 200, tw, 180))
      can = state.starter_pick_pending is not None
      self.buttons.append(Button(
        pygame.Rect(SCREEN_W // 2 - 170, 400, 140, 44), "확정", "confirm_starter", enabled=can,
      ))
      self.buttons.append(Button(
        pygame.Rect(SCREEN_W // 2 + 30, 400, 140, 44), "선택 취소", "cancel_starter",
      ))

    elif state.phase == Phase.TAROT_REWARD:
      tw = 140
      gap = 24
      count = max(1, len(state.reward_tarot_choices))
      total = count * tw + max(0, count - 1) * gap
      sx = (SCREEN_W - total) // 2
      for i in range(len(state.reward_tarot_choices)):
        self.reward_tarot_rects.append(pygame.Rect(sx + i * (tw + gap), 200, tw, 180))
      can = state.reward_pick_pending is not None
      self.buttons.append(Button(
        pygame.Rect(SCREEN_W // 2 - 170, 400, 140, 44), "확정", "confirm_reward", enabled=can,
      ))
      self.buttons.append(Button(
        pygame.Rect(SCREEN_W // 2 + 30, 400, 140, 44), "선택 취소", "cancel_reward",
      ))

    elif state.phase == Phase.ARTIFACT_REWARD:
      tw = 220
      gap = 20
      count = max(1, len(state.artifact_reward_choices))
      total = count * tw + max(0, count - 1) * gap
      sx = (SCREEN_W - total) // 2
      for i in range(len(state.artifact_reward_choices)):
        self.artifact_reward_rects.append(pygame.Rect(sx + i * (tw + gap), 190, tw, 220))
      can = state.artifact_pick_pending is not None
      self.buttons.append(Button(
        pygame.Rect(SCREEN_W // 2 - 170, 430, 140, 44), "확정", "confirm_artifact", enabled=can,
      ))
      self.buttons.append(Button(
        pygame.Rect(SCREEN_W // 2 + 30, 430, 140, 44), "선택 취소", "cancel_artifact",
      ))

    elif state.phase == Phase.UPGRADE_SELECT:
      from game.progression import UPGRADEABLE_HANDS

      tab_w = 148
      self.buttons.append(Button(
        pygame.Rect(SCREEN_W // 2 - tab_w - 6, 88, tab_w, 36),
        "타로 강화", "upgrade_tab_tarot",
      ))
      self.buttons.append(Button(
        pygame.Rect(SCREEN_W // 2 + 6, 88, tab_w, 36),
        "족보 강화", "upgrade_tab_hand",
      ))

      if state.upgrade_tab == "tarot":
        tw, gap = CARD_W, 14
        n = max(1, len(state.tarots))
        cols = min(5, n)
        rows = (n + cols - 1) // cols
        grid_w = cols * tw + (cols - 1) * gap
        sx = (SCREEN_W - grid_w) // 2
        for i, tarot in enumerate(state.tarots):
          col, row = i % cols, i // cols
          rect = pygame.Rect(sx + col * (tw + gap), 148 + row * (CARD_H + 22), tw, CARD_H)
          self.upgrade_tarot_rects.append((rect, tarot))
      else:
        cols = 3
        bw, bh = 220, 48
        gap_x, gap_y = 14, 10
        grid_w = cols * bw + (cols - 1) * gap_x
        sx = (SCREEN_W - grid_w) // 2
        for i, hand_name in enumerate(UPGRADEABLE_HANDS):
          col = i % cols
          row = i // cols
          rect = pygame.Rect(sx + col * (bw + gap_x), 148 + row * (bh + gap_y), bw, bh)
          self.upgrade_hand_rects.append((rect, hand_name))

      can = state.upgrade_tarot_pending is not None or state.upgrade_hand_pending is not None
      self.buttons.append(Button(
        pygame.Rect(SCREEN_W // 2 - 170, 500, 140, 44), "확정", "confirm_upgrade", enabled=can,
      ))
      self.buttons.append(Button(
        pygame.Rect(SCREEN_W // 2 + 30, 500, 140, 44), "선택 취소", "cancel_upgrade",
      ))

    joker_transform = (
      state.phase == Phase.FILL_HAND and state.sub_phase == SubPhase.JOKER_TRANSFORM
    )
    slots = state.max_hand_slots
    two_row_hand = slots > 7 and not joker_transform
    if joker_transform:
      slot_y = 72
    elif two_row_hand:
      slot_y = 170
    else:
      slot_y = 238
    if joker_transform:
      card_w, card_h, gap = 70, 98, 6
    elif slots > 7:
      card_w, card_h, gap = 78, 112, 8
    else:
      card_w, card_h, gap = CARD_W, CARD_H, CARD_GAP
    self._layout_card_w = card_w
    self._layout_card_h = card_h
    self.hand_slot_rects.clear()
    if slots <= 7 or joker_transform:
      total_w = slots * card_w + max(0, slots - 1) * gap
      start_x = (SCREEN_W - total_w) // 2
      for i in range(slots):
        self.hand_slot_rects.append(pygame.Rect(start_x + i * (card_w + gap), slot_y, card_w, card_h))
    else:
      row1 = (slots + 1) // 2
      row2 = slots - row1
      row_gap_y = 10
      for row, count, start_idx in ((0, row1, 0), (1, row2, row1)):
        total_w = count * card_w + max(0, count - 1) * gap
        start_x = (SCREEN_W - total_w) // 2
        y = slot_y + row * (card_h + row_gap_y)
        for i in range(count):
          self.hand_slot_rects.append(pygame.Rect(
            start_x + i * (card_w + gap), y, card_w, card_h,
          ))

    btn_y = 604 if two_row_hand else 560
    if state.phase == Phase.WELL_STAGE:
      btn_y = 560
      if state.sub_phase == SubPhase.WELL_GAIN_PICK:
        for i, _ in enumerate(state.pick_pool):
          x = SCREEN_W // 2 - (len(state.pick_pool) * (CARD_W + CARD_GAP)) // 2 + i * (CARD_W + CARD_GAP)
          self._pool_rects.append(pygame.Rect(x, 200, CARD_W, CARD_H))
      elif state.sub_phase == SubPhase.NONE:
        cards = state.deck.deck
        cols = 13
        gap = 3
        panel_x, panel_y = 80, 148
        panel_w, panel_h = SCREEN_W - 160, 330
        rows = max(1, (len(cards) + cols - 1) // cols)
        ch = max(24, min(52, (panel_h - 16 - max(0, rows - 1) * gap) // rows))
        cw = min(46, max(28, (panel_w - (cols - 1) * gap) // cols))
        grid_w = cols * cw + (cols - 1) * gap
        sx = panel_x + (panel_w - grid_w) // 2
        sy = panel_y + 8
        for i in range(len(cards)):
          row, col = i // cols, i % cols
          self.well_deck_rects.append(pygame.Rect(
            sx + col * (cw + gap), sy + row * (ch + gap), cw, ch,
          ))
          self._well_deck_indices.append(i)
      if state.well_gain_remaining > 0 and state.sub_phase == SubPhase.NONE:
        self.buttons.append(Button(
          pygame.Rect(SCREEN_W // 2 - 120, btn_y, 240, 44),
          f"카드 뽑기 ({state.well_gain_remaining}회)",
          "well_gain_pick",
        ))
      self.buttons.append(Button(pygame.Rect(SCREEN_W // 2 + 140, btn_y, 180, 44), "편집 완료", "well_finish"))

    elif state.phase == Phase.JAW_STAGE:
      if state.sub_phase == SubPhase.JAW_PICK_JAW:
        tw, gap = 280, 24
        total = len(state.jaw_offers) * tw + max(0, len(state.jaw_offers) - 1) * gap
        sx = (SCREEN_W - total) // 2
        for i in range(len(state.jaw_offers)):
          self.jaw_offer_rects.append(pygame.Rect(sx + i * (tw + gap), 175, tw, 210))
        if has_artifact(state.artifact_stacks, "rusty_pelican"):
          for i in range(len(state.jaw_offers)):
            self.buttons.append(Button(
              pygame.Rect(sx + i * (tw + gap) + tw // 2 - 40, 390, 80, 32),
              "리롤", f"jaw_reroll_{i}",
            ))
        if has_artifact(state.artifact_stacks, "traitor_tongue"):
          self.buttons.append(Button(
            pygame.Rect(SCREEN_W // 2 - 100, btn_y, 200, 40),
            "자국 포기→타로", "traitor_jaw_tarot",
          ))
      elif state.sub_phase == SubPhase.JAW_PICK_CARD:
        n = len(state.jaw_card_pool)
        gap = 10
        cw = min(CARD_W, max(72, (SCREEN_W - 120 - (n - 1) * gap) // max(1, n)))
        total = n * cw + max(0, n - 1) * gap
        sx = (SCREEN_W - total) // 2
        for i in range(n):
          self.jaw_card_rects.append(pygame.Rect(sx + i * (cw + gap), 300, cw, CARD_H))

    elif state.phase == Phase.BAN_SELECT:
      from game.artifact_runtime import indulgence_discard_count
      need = indulgence_discard_count(state.artifact_stacks) if has_artifact(
        state.artifact_stacks, "indulgence",
      ) else 2
      btn = Button(pygame.Rect(SCREEN_W // 2 - 80, btn_y, 160, 44), "확정", "confirm_ban")
      btn.enabled = len(state.ban_selection) == need
      self.buttons.append(btn)
      n = len(state.opening_five)
      if n <= 5:
        cols, rows, gap = n, 1, CARD_GAP
        cw, ch = CARD_W, CARD_H
      else:
        cols, rows, gap = 4, 2, 10
        cw = min(CARD_W, (SCREEN_W - 80 - (cols - 1) * gap) // cols)
        ch = CARD_H
      for i in range(n):
        row, col = i // cols, i % cols
        total_w = cols * cw + (cols - 1) * gap
        sx = (SCREEN_W - total_w) // 2
        sy = 110 + row * (ch + 16)
        self.card_rects.append(pygame.Rect(sx + col * (cw + gap), sy, cw, ch))

    elif state.phase == Phase.DRAW_PICK:
      for i, _ in enumerate(state.draw_three):
        x = SCREEN_W // 2 - (3 * (CARD_W + CARD_GAP)) // 2 + i * (CARD_W + CARD_GAP)
        self.card_rects.append(pygame.Rect(x, 120, CARD_W, CARD_H))

    elif state.phase == Phase.FILL_HAND:
      if state.sub_phase == SubPhase.JOKER_FOOL_PICK:
        self.buttons.append(Button(pygame.Rect(60, btn_y, 160, 44), "리롤 확정", "confirm_fool"))
      if state.sub_phase == SubPhase.JAW_FANG_PICK:
        self.buttons.append(Button(pygame.Rect(60, btn_y, 160, 44), "리롤 확정", "confirm_jaw_fang"))
      if state.sub_phase == SubPhase.DEATH_PICK_THREE:
        ok = len(state.death_picks) == 3
        self.buttons.append(Button(
          pygame.Rect(SCREEN_W // 2 - 210, btn_y, 160, 44), "확정", "confirm_death_pick", enabled=ok,
        ))
      if state.sub_phase == SubPhase.MOON_PICK_DRAW:
        ok = len(state.death_picks) == 2
        self.buttons.append(Button(
          pygame.Rect(SCREEN_W // 2 - 210, btn_y, 160, 44), "확정", "confirm_moon_pick", enabled=ok,
        ))
      elif state.sub_phase == SubPhase.NONE and not state.pending_tarot:
        self.buttons.append(Button(pygame.Rect(60, btn_y, 140, 44), "트럼프 드로우", "draw"))
      if (
        state.sub_phase == SubPhase.NONE
        and has_artifact(state.artifact_stacks, "jiri_blade")
        and not state.jiri_blade_spent
        and not state.is_hand_full()
      ):
        self.buttons.append(Button(
          pygame.Rect(210, btn_y, 150, 44), "작두 드로우", "jiri_pick",
        ))
      if (
        state.sub_phase == SubPhase.NONE
        and has_artifact(state.artifact_stacks, "super_coward_club")
        and not state.coward_club_spent
        and state.slots_remaining() == 2
        and state.hand_count() > 0
      ):
        self.buttons.append(Button(
          pygame.Rect(370, btn_y, 130, 44), "패 무효화", "coward_void",
        ))
      if state.sub_phase == SubPhase.WHEEL_REROLL:
        self.buttons.append(Button(pygame.Rect(60, btn_y, 120, 44), "리롤", "wheel_reroll"))
        self.buttons.append(Button(pygame.Rect(200, btn_y, 120, 44), "완료", "wheel_done"))
      if state.sub_phase == SubPhase.TEMPERANCE_OFFER:
        self.buttons.append(Button(pygame.Rect(60, btn_y, 120, 44), "받기", "temperance_accept"))
        self.buttons.append(Button(pygame.Rect(200, btn_y, 120, 44), "다시뽑기", "temperance_reroll"))
      if state.sub_phase in (SubPhase.HERMIT_SUIT, SubPhase.TEMPERANCE_SUIT):
        for i, suit in enumerate(SUITS):
          btn = Button(pygame.Rect(360 + i * 110, btn_y, 100, 44), SUIT_LABELS_KO[suit], f"suit_{i}")
          self.buttons.append(btn)
          self._suit_btn_map[btn.action] = suit
      if state.sub_phase == SubPhase.RANK_PICK_VALUE:
        cx = SCREEN_W // 2
        self.buttons.append(Button(pygame.Rect(cx - 150, 250, 50, 50), "◀", "str_rank_dec"))
        self.buttons.append(Button(pygame.Rect(cx - 90, 250, 50, 50), "▶", "str_rank_inc"))
        if state.strength_allow_suit:
          self.buttons.append(Button(pygame.Rect(cx + 40, 250, 50, 50), "◀", "str_suit_dec"))
          self.buttons.append(Button(pygame.Rect(cx + 100, 250, 50, 50), "▶", "str_suit_inc"))
        self.buttons.append(Button(pygame.Rect(cx - 70, 320, 140, 46), "변경 확정", "str_confirm"))
      if state.pending_tarot:
        self.buttons.append(Button(pygame.Rect(220, btn_y, 120, 44), "타로 취소", "cancel_tarot"))
        if state.tarot_mode == "choose":
          if has_artifact(state.artifact_stacks, "red_bowl"):
            self.buttons.append(Button(pygame.Rect(360, btn_y, 120, 44), "하트", "suit_0"))
            self.buttons.append(Button(pygame.Rect(490, btn_y, 120, 44), "다이아", "suit_1"))
          else:
            self.buttons.append(Button(
              pygame.Rect(360, btn_y, 172, 44), "빨강(하트/다이아)", "color_red"))
            self.buttons.append(Button(
              pygame.Rect(544, btn_y, 192, 44), "검정(클럽/스페이드)", "color_black"))
      elif state.slots_remaining() <= 0 and state.sub_phase == SubPhase.NONE:
        self.buttons.append(Button(pygame.Rect(SCREEN_W // 2 - 80, btn_y, 160, 44), "점수 확정", "score"))

      # 손패를 가리는 선택창(묘지·조커 등)은 접기/펼치기 토글 제공
      if state.sub_phase in COLLAPSIBLE_POOL_SUBPHASES:
        if self._last_pool_subphase != state.sub_phase:
          self.selection_collapsed = False
          self._last_pool_subphase = state.sub_phase
        toggle_label = "선택창 올리기" if self.selection_collapsed else "선택창 내리기"
        # 확정 버튼이 함께 뜨면 그 오른쪽에, 아니면 중앙에 배치해 겹침 방지
        if state.sub_phase in CONFIRM_WITH_TOGGLE_SUBPHASES:
          toggle_x = SCREEN_W // 2 + 30
        else:
          toggle_x = SCREEN_W // 2 - 95
        self.buttons.append(Button(
          pygame.Rect(toggle_x, btn_y, 190, 40), toggle_label, "toggle_pool",
        ))
      else:
        self._last_pool_subphase = None
        self.selection_collapsed = False

      collapsed = (
        self.selection_collapsed and state.sub_phase in COLLAPSIBLE_POOL_SUBPHASES
      )

      pool = []
      if state.sub_phase == SubPhase.PICK_FIVE:
        pool = state.pick_pool
      elif state.sub_phase == SubPhase.JOKER_TRANSFORM:
        pool = state.pick_pool
        if not collapsed:
          grid_y = slot_y + card_h + 28
          self._pool_rects = self._layout_compact_card_grid(len(pool), start_y=grid_y)
      elif state.sub_phase in (
        SubPhase.DEATH_PICK_THREE, SubPhase.MOON_PICK_DRAW,
        SubPhase.PRIESTESS_PICK, SubPhase.ACOLYTE_PICK, SubPhase.JIRI_DECK_PICK,
      ):
        pool = state.pick_pool
      if state.sub_phase != SubPhase.JOKER_TRANSFORM and not collapsed:
        for i, _ in enumerate(pool):
          x = SCREEN_W // 2 - (min(len(pool), 6) * (CARD_W + CARD_GAP)) // 2 + (i % 6) * (CARD_W + CARD_GAP)
          y = 100 + (i // 6) * (CARD_H + CARD_GAP)
          self._pool_rects.append(pygame.Rect(x, y, CARD_W, CARD_H))
          self.card_rects.append(self._pool_rects[-1])

      n_tarot = len(state.tarots)
      has_ks = has_artifact(state.artifact_stacks, "kingslayer_sword")
      if (n_tarot or has_ks) and state.sub_phase != SubPhase.JOKER_TRANSFORM:
        extra = (CARD_W + 8) if has_ks else 0
        total_tw = n_tarot * CARD_W + max(0, n_tarot - 1) * 8 + extra
        tx = SCREEN_W // 2 - total_tw // 2
        if self.hand_slot_rects:
          tarot_y = self.hand_slot_rects[-1].bottom + 18
        else:
          tarot_y = 392
        for i, tarot in enumerate(state.tarots):
          rect = pygame.Rect(tx + i * (CARD_W + 8), tarot_y, CARD_W, CARD_H)
          self.tarot_rects.append((rect, tarot))
        if has_ks:
          kx = tx + n_tarot * (CARD_W + 8) if n_tarot else tx
          self.kingslayer_rect = pygame.Rect(kx, tarot_y, CARD_W, CARD_H)

    elif state.phase == Phase.SCORE:
      if state.score_damage_applied:
        self.buttons.append(Button(pygame.Rect(SCREEN_W // 2 - 80, btn_y, 160, 44), "확인", "confirm_score"))

    elif state.phase == Phase.BATTLE_RESULT:
      if state.enemy.hp <= 0:
        label = "다음 스테이지"
      elif (
        state.enemy.max_turns > 0
        and state.enemy.kind == "normal"
        and max(0, state.enemy.max_turns - state.battle_turn) <= 0
      ):
        label = "턴 소진"
      else:
        label = "다음 턴"
      self.buttons.append(Button(pygame.Rect(SCREEN_W // 2 - 100, btn_y, 200, 44), label, "next_round"))

    elif state.phase == Phase.GAME_OVER:
      self.buttons.append(Button(pygame.Rect(SCREEN_W // 2 - 100, btn_y, 200, 44), "다시 시작", "restart_game"))

  def draw(
    self,
    state: GameState,
    mouse_pos: tuple[int, int],
    score_reveal: ScoreRevealPlayer | None = None,
  ) -> None:
    self.layout(state)
    self._artifact_stacks = state.artifact_stacks
    self._hovered_tarot = self._find_hovered_tarot(state, mouse_pos)
    self.screen.fill(COLORS["bg"])
    if state.phase == Phase.MAIN_MENU:
      self._draw_main_menu(state, mouse_pos)
      self._draw_buttons(mouse_pos)
      return
    if state.phase == Phase.RECORDS:
      self._draw_records(state, mouse_pos)
      self._draw_buttons(mouse_pos)
      return
    self._draw_header(state)
    self._draw_enemy(state)
    self._draw_hand_bonus_strip(state)
    self._draw_artifact_strip(state)
    if state.phase == Phase.TAROT_PICK:
      self._draw_tarot_pick(state, mouse_pos)
    elif state.phase == Phase.TAROT_REWARD:
      self._draw_tarot_reward(state, mouse_pos)
    elif state.phase == Phase.ARTIFACT_REWARD:
      self._draw_artifact_reward(state, mouse_pos)
    elif state.phase == Phase.UPGRADE_SELECT:
      self._draw_upgrade_select(state, mouse_pos)
    elif state.phase == Phase.WELL_STAGE:
      self._draw_well_stage(state, mouse_pos)
    elif state.phase == Phase.JAW_STAGE:
      self._draw_jaw_stage(state, mouse_pos)
    elif state.phase == Phase.GAME_OVER:
      self._draw_game_over(state)
    else:
      if state.sub_phase != SubPhase.JOKER_TRANSFORM:
        self._draw_hand_slots(state, score_reveal=score_reveal)
      self._draw_phase_cards(state)
      if state.sub_phase != SubPhase.JOKER_TRANSFORM:
        self._draw_tarots(state, mouse_pos)
        self._draw_kingslayer(state, mouse_pos)
      self._draw_sub_phase(state, mouse_pos)
      if state.sub_phase == SubPhase.JOKER_TRANSFORM:
        self._draw_hand_slots(state, score_reveal=score_reveal)
      self._draw_next_draw_preview(state)
    self._draw_tarot_detail(state)
    # 턱·우물은 전투 없는 전용 전체화면 — 좌측 사이드바/묘지바와 겹치지 않도록 생략
    if state.phase not in (Phase.JAW_STAGE, Phase.WELL_STAGE):
      self._draw_sidebar(state, score_reveal=score_reveal)
      self._draw_discard_bar(state)
      self._draw_banned_strip(state, mouse_pos)
    draw_alchemy_panel(
      self.screen, state, self.alchemy_rects, self.font, self.font_sm, mouse_pos,
      collapsed=self.alchemy_collapsed,
    )
    self._draw_buttons(mouse_pos)

  def _draw_main_menu(self, state: GameState, mouse_pos: tuple[int, int]) -> None:
    title = self.font_title.render("한라산 작두 강지후", True, (240, 210, 160))
    sub = self.font_lg.render("— 제곽의 타짜 —", True, COLORS["accent2"])
    self.screen.blit(title, title.get_rect(center=(SCREEN_W // 2, SCREEN_H // 2 - 110)))
    self.screen.blit(sub, sub.get_rect(center=(SCREEN_W // 2, SCREEN_H // 2 - 62)))
    hint = self.font_sm.render("트럼프 × 타로 로그라이크", True, COLORS["text_dim"])
    self.screen.blit(hint, hint.get_rect(center=(SCREEN_W // 2, SCREEN_H // 2 - 26)))

    from game.persistence import load_records
    rec = load_records()
    best = self.font.render(
      f"최고 스테이지 {rec['best_stage']}   ·   최고 데미지 {rec['best_damage']:,}",
      True,
      (235, 205, 120),
    )
    self.screen.blit(best, best.get_rect(center=(SCREEN_W // 2, SCREEN_H // 2 + 6)))

  def _draw_records(self, state: GameState, mouse_pos: tuple[int, int]) -> None:
    from game.leaderboard import (
      get_player_name,
      global_entries,
      is_enabled,
      status,
      status_message,
    )
    from game.persistence import load_records

    panel = pygame.Rect(SCREEN_W // 2 - 360, 140, 720, SCREEN_H - 280)
    pygame.draw.rect(self.screen, COLORS["panel"], panel, border_radius=14)
    pygame.draw.rect(self.screen, (235, 205, 120), panel, 2, border_radius=14)

    title = self.font_title.render("랭킹", True, (240, 210, 160))
    self.screen.blit(title, title.get_rect(center=(SCREEN_W // 2, 118)))

    # 이름 입력
    name_label = self.font_sm.render("플레이어 이름", True, COLORS["text_dim"])
    self.screen.blit(name_label, (SCREEN_W - 270, 136))
    name_rect = pygame.Rect(SCREEN_W - 270, 158, 200, 34)
    pygame.draw.rect(self.screen, (28, 30, 38), name_rect, border_radius=6)
    border_c = (235, 205, 120) if state.name_editing else COLORS["card_border"]
    pygame.draw.rect(self.screen, border_c, name_rect, 2, border_radius=6)
    shown = state.name_edit_buffer if state.name_editing else get_player_name()
    if state.name_editing:
      shown = shown + "|"
    name_surf = self.font.render(shown[:16] or "익명", True, COLORS["text"])
    self.screen.blit(name_surf, (name_rect.x + 10, name_rect.y + 6))

    # 동기화 상태
    if is_enabled():
      st = status()
      colors = {
        "online": (120, 220, 140),
        "syncing": (255, 210, 100),
        "offline": (160, 165, 175),
        "error": (255, 120, 120),
      }
      sync_txt = self.font_sm.render(
        f"● {status_message() or st}",
        True,
        colors.get(st, COLORS["text_dim"]),
      )
      self.screen.blit(sync_txt, (panel.x + 24, panel.y + 14))
    else:
      hint = self.font_sm.render("온라인 랭킹 서버 미설정", True, COLORS["text_dim"])
      self.screen.blit(hint, (panel.x + 24, panel.y + 14))

    if state.records_tab == "global":
      self._draw_global_records(state, panel)
      return

    rec = load_records()
    best = self.font_lg.render(
      f"최고 스테이지 {rec['best_stage']}   ·   최고 데미지 {rec['best_damage']:,}",
      True,
      (235, 205, 120),
    )
    self.screen.blit(best, best.get_rect(center=(SCREEN_W // 2, panel.y + 52)))

    col_x = (panel.x + 50, panel.x + 150, panel.x + 360, panel.x + 560)
    head_y = panel.y + 100
    for label, cx in zip(("순위", "스테이지", "최고 데미지", "클리어"), col_x):
      h = self.font.render(label, True, COLORS["accent2"])
      self.screen.blit(h, (cx, head_y))
    pygame.draw.line(
      self.screen, COLORS["card_border"],
      (panel.x + 30, head_y + 30), (panel.right - 30, head_y + 30), 1,
    )

    runs = rec.get("runs", [])
    if not runs:
      empty = self.font.render(
        "아직 기록이 없습니다. 게임을 플레이해 보세요!", True, COLORS["text_dim"],
      )
      self.screen.blit(empty, empty.get_rect(center=(SCREEN_W // 2, head_y + 110)))
      return

    medal = {0: (255, 215, 0), 1: (200, 200, 210), 2: (205, 150, 95)}
    row_y = head_y + 46
    for i, run in enumerate(runs):
      color = medal.get(i, COLORS["text"])
      sync_mark = "" if run.get("synced") else " ○"
      cells = (
        f"{i + 1}{sync_mark}",
        f"{run.get('stage', 0)}",
        f"{run.get('damage', 0):,}",
        f"{run.get('wins', 0)}",
      )
      for text, cx in zip(cells, col_x):
        t = self.font.render(text, True, color)
        self.screen.blit(t, (cx, row_y))
      row_y += 38
    if is_enabled():
      foot = self.font_sm.render("○ = 아직 서버에 안 올라간 기록", True, COLORS["text_dim"])
      self.screen.blit(foot, (panel.x + 24, panel.bottom - 28))

  def _draw_global_records(self, state: GameState, panel: pygame.Rect) -> None:
    from game.leaderboard import global_entries, is_enabled, status_message

    sort = state.records_global_sort
    entries = global_entries(sort)
    subtitle = self.font.render(
      f"전체 랭킹 — {'스테이지' if sort == 'stage' else '데미지'} 순",
      True,
      (235, 205, 120),
    )
    self.screen.blit(subtitle, subtitle.get_rect(center=(SCREEN_W // 2, panel.y + 52)))

    col_x = (panel.x + 40, panel.x + 120, panel.x + 300, panel.x + 460, panel.x + 600)
    head_y = panel.y + 100
    for label, cx in zip(("순위", "이름", "스테이지", "데미지", "클리어"), col_x):
      h = self.font.render(label, True, COLORS["accent2"])
      self.screen.blit(h, (cx, head_y))
    pygame.draw.line(
      self.screen, COLORS["card_border"],
      (panel.x + 30, head_y + 30), (panel.right - 30, head_y + 30), 1,
    )

    if not is_enabled():
      empty = self.font.render(
        "leaderboard_config.py 에 서버 주소를 설정하세요.", True, COLORS["text_dim"],
      )
      self.screen.blit(empty, empty.get_rect(center=(SCREEN_W // 2, head_y + 110)))
      return

    if not entries:
      msg = status_message() or "랭킹 불러오는 중..."
      empty = self.font.render(msg, True, COLORS["text_dim"])
      self.screen.blit(empty, empty.get_rect(center=(SCREEN_W // 2, head_y + 110)))
      return

    medal = {0: (255, 215, 0), 1: (200, 200, 210), 2: (205, 150, 95)}
    row_y = head_y + 46
    for entry in entries[:12]:
      rank = int(entry.get("rank", 0))
      color = medal.get(rank - 1, COLORS["text"])
      cells = (
        str(rank),
        str(entry.get("name", "익명"))[:10],
        str(entry.get("stage", 0)),
        f"{int(entry.get('damage', 0)):,}",
        str(entry.get("wins", 0)),
      )
      for text, cx in zip(cells, col_x):
        t = self.font.render(text, True, color)
        self.screen.blit(t, (cx, row_y))
      row_y += 34

  def _draw_banned_strip(self, state: GameState, mouse_pos: tuple[int, int]) -> None:
    n = len(state.deck.banned)
    if n <= 0 and self.banned_collapsed:
      return
    bar_h = 36 if self.banned_collapsed else min(180, 56 + (n + 5) // 6 * 28)
    bar = pygame.Rect(300, SCREEN_H - bar_h - 8, SCREEN_W - 320, bar_h)
    hover = bar.collidepoint(mouse_pos)
    pygame.draw.rect(self.screen, COLORS["panel"], bar, border_radius=8)
    pygame.draw.rect(self.screen, COLORS["accent2"] if hover else COLORS["card_border"], bar, 2, border_radius=8)
    label = "▼ 밴 카드" if self.banned_collapsed else "▲ 밴 카드 접기"
    head = self.font_sm.render(f"{label}  ({n}장)", True, COLORS["text"])
    self.screen.blit(head, (bar.x + 12, bar.y + 8))
    if self.banned_collapsed or n == 0:
      return
    cols = min(8, max(1, (bar.w - 24) // 58))
    gap = 6
    cw = (bar.w - 24 - (cols - 1) * gap) // cols
    for i, card in enumerate(state.deck.banned[:cols * 2]):
      col = i % cols
      row = i // cols
      cx = bar.x + 12 + col * (cw + gap)
      cy = bar.y + 34 + row * 26
      r = pygame.Rect(cx, cy, cw, 22)
      pygame.draw.rect(self.screen, COLORS["card_bg"], r, border_radius=4)
      t = self.font_sm.render(f"{card.label}{card.suit[0].upper()}", True, COLORS["ban"])
      self.screen.blit(t, t.get_rect(center=r.center))

  def _draw_game_over(self, state: GameState) -> None:
    overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
    overlay.fill((0, 0, 0, 160))
    self.screen.blit(overlay, (0, 0))

    title = self.font_title.render("게임 오버", True, COLORS["danger"])
    self.screen.blit(title, title.get_rect(center=(SCREEN_W // 2, 220)))

    reason = self.font_lg.render(state.message, True, COLORS["text"])
    self.screen.blit(reason, reason.get_rect(center=(SCREEN_W // 2, 280)))

    stats = self.font.render(
      f"스테이지 {state.enemy.stage} · 클리어 {state.wins} · 턴 {state.battle_turn}",
      True,
      COLORS["text_dim"],
    )
    self.screen.blit(stats, stats.get_rect(center=(SCREEN_W // 2, 330)))

    hint = self.font_sm.render("다시 시작 버튼 또는 Enter", True, COLORS["accent"])
    self.screen.blit(hint, hint.get_rect(center=(SCREEN_W // 2, 380)))

  def _draw_well_stage(self, state: GameState, mouse_pos: tuple[int, int]) -> None:
    from game.constants import DECK_MAX, DECK_MIN
    from ui.themes import tier_style

    tier = 2
    style = tier_style(tier)
    overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
    for i in range(5):
      a = int(30 * (i + 1) / 5)
      w = 180 * (5 - i) // 5
      pygame.draw.rect(overlay, (*style["color"], a), (0, 0, SCREEN_W, w))
      pygame.draw.rect(overlay, (*style["color"], a), (0, SCREEN_H - w, SCREEN_W, w))
    self.screen.blit(overlay, (0, 0))

    title = self.font_title.render("우물 스테이지", True, style["color"])
    self.screen.blit(title, title.get_rect(center=(SCREEN_W // 2, 72)))
    n = len(state.deck.deck)
    info = self.font.render(
      f"런 덱 {n}장 (한도 {DECK_MIN}~{DECK_MAX}) · "
      f"버리기 {state.well_discard_remaining}회 · 뽑기 {state.well_gain_remaining}회",
      True, COLORS["text"],
    )
    self.screen.blit(info, info.get_rect(center=(SCREEN_W // 2, 108)))

    if state.sub_phase == SubPhase.WELL_GAIN_PICK:
      sub = self.font.render("5장 중 1장을 선택하세요", True, COLORS["accent2"])
      self.screen.blit(sub, sub.get_rect(center=(SCREEN_W // 2, 160)))
      panel = pygame.Rect(
        self._pool_rects[0].x - 16 if self._pool_rects else SCREEN_W // 2 - 200,
        180,
        (self._pool_rects[-1].right - self._pool_rects[0].x + 32) if self._pool_rects else 400,
        CARD_H + 40,
      )
      if self._pool_rects:
        panel = pygame.Rect(
          self._pool_rects[0].x - 16,
          self._pool_rects[0].y - 12,
          self._pool_rects[-1].right - self._pool_rects[0].x + 32,
          self._pool_rects[0].h + 24,
        )
      pygame.draw.rect(self.screen, COLORS["panel"], panel, border_radius=10)
      pygame.draw.rect(self.screen, style["color"], panel, 2, border_radius=10)
      for i, rect in enumerate(self._pool_rects):
        if i < len(state.pick_pool):
          hover = rect.collidepoint(mouse_pos)
          self._draw_card(rect, state.pick_pool[i], highlight=hover)
    else:
      sub = self.font_sm.render(
        "덱 전체 — 카드 클릭 = 영구 제거", True, COLORS["text_dim"],
      )
      self.screen.blit(sub, sub.get_rect(center=(SCREEN_W // 2, 132)))
      view = pygame.Rect(80, 148, SCREEN_W - 160, 330)
      pygame.draw.rect(self.screen, COLORS["panel"], view, border_radius=10)
      pygame.draw.rect(self.screen, style["color"], view, 2, border_radius=10)
      for vi, rect in enumerate(self.well_deck_rects):
        di = self._well_deck_indices[vi] if vi < len(self._well_deck_indices) else vi
        if di < len(state.deck.deck):
          hover = rect.collidepoint(mouse_pos) and state.well_discard_remaining > 0
          from game.artifact_runtime import deck_min_for_run
          can_discard = state.well_discard_remaining > 0 and state.deck.can_remove_cards(
            1, min_deck=deck_min_for_run(state.artifact_stacks),
          )
          self._draw_card(rect, state.deck.deck[di], highlight=hover and can_discard)
          if hover and can_discard:
            tag = self.font_sm.render("제거", True, COLORS["danger"])
            self.screen.blit(tag, (rect.x + 2, rect.y + 2))

    if state.message:
      msg = self.font.render(state.message, True, COLORS["accent2"])
      self.screen.blit(msg, msg.get_rect(center=(SCREEN_W // 2, 470)))

  def _draw_jaw_stage(self, state: GameState, mouse_pos: tuple[int, int]) -> None:
    from game.jaws import JAW_TIER_LABELS, JawTier, get_jaw
    from game.progression import JAW_MARKS_PER_STAGE

    tier_colors = {
      JawTier.NOBILITY: (210, 175, 90),
      JawTier.HERO_VILLAIN: (200, 100, 100),
      JawTier.WANDERER_ARTIST: (120, 170, 210),
      JawTier.SAINT_DEVIL: (170, 120, 210),
    }

    overlay = pygame.Surface((SCREEN_W, SCREEN_H), pygame.SRCALPHA)
    for i in range(4):
      a = 18 + i * 6
      pygame.draw.rect(overlay, (120, 40, 40, a), (0, 0, SCREEN_W, 60 + i * 20))
    self.screen.blit(overlay, (0, 0))

    round_num = max(1, JAW_MARKS_PER_STAGE - state.jaw_marks_remaining + 1)
    title = self.font_title.render(
      f"턱 스테이지 — 자국 {round_num}/{JAW_MARKS_PER_STAGE}",
      True, COLORS["danger"],
    )
    self.screen.blit(title, title.get_rect(center=(SCREEN_W // 2, 88)))
    hint = self.font_sm.render(
      "이빨 자국은 덱에 영구 반영 · 같은 시퀀스를 두 번 반복",
      True, COLORS["text_dim"],
    )
    self.screen.blit(hint, hint.get_rect(center=(SCREEN_W // 2, 128)))

    if state.sub_phase == SubPhase.JAW_PICK_JAW:
      sub = self.font.render("먼저 이빨 자국(턱)을 선택하세요", True, COLORS["text"])
      self.screen.blit(sub, sub.get_rect(center=(SCREEN_W // 2, 155)))
      for i, rect in enumerate(self.jaw_offer_rects):
        if i >= len(state.jaw_offers):
          break
        jaw = get_jaw(state.jaw_offers[i])
        tier_label = JAW_TIER_LABELS[jaw.tier]
        tier_color = tier_colors.get(jaw.tier, COLORS["danger"])
        hover = rect.collidepoint(mouse_pos)
        color = COLORS["btn_hover"] if hover else COLORS["panel"]
        pygame.draw.rect(self.screen, color, rect, border_radius=12)
        pygame.draw.rect(self.screen, tier_color, rect, 3, border_radius=12)
        nm = self.font.render(jaw.name, True, COLORS["text"])
        self.screen.blit(nm, nm.get_rect(center=(rect.centerx, rect.y + 28)))
        tier_t = self.font_sm.render(tier_label, True, tier_color)
        self.screen.blit(tier_t, tier_t.get_rect(center=(rect.centerx, rect.y + 56)))
        text_rect = pygame.Rect(rect.x + 12, rect.y + 72, rect.w - 24, rect.h - 84)
        self._blit_wrapped_multiline(jaw.effect_summary, text_rect, COLORS["text_dim"])

    elif state.sub_phase == SubPhase.JAW_PICK_CARD:
      if state.jaw_picked_offer_index is not None:
        jaw = get_jaw(state.jaw_offers[state.jaw_picked_offer_index])
        tier_color = tier_colors.get(jaw.tier, COLORS["danger"])
        banner = pygame.Rect(SCREEN_W // 2 - 300, 155, 600, 110)
        pygame.draw.rect(self.screen, COLORS["panel"], banner, border_radius=10)
        pygame.draw.rect(self.screen, tier_color, banner, 2, border_radius=10)
        sel = self.font.render(f"선택한 턱: {jaw.name}", True, tier_color)
        self.screen.blit(sel, sel.get_rect(center=(banner.centerx, banner.y + 28)))
        self._blit_wrapped_multiline(
          jaw.effect_summary,
          pygame.Rect(banner.x + 16, banner.y + 48, banner.w - 32, 52),
          COLORS["text_dim"],
        )
      sub = self.font.render("자국을 남길 카드 1장을 선택하세요", True, COLORS["text"])
      self.screen.blit(sub, sub.get_rect(center=(SCREEN_W // 2, 275)))
      for i, rect in enumerate(self.jaw_card_rects):
        if i < len(state.jaw_card_pool):
          hover = rect.collidepoint(mouse_pos)
          self._draw_card(rect, state.jaw_card_pool[i], highlight=hover)
          if hover:
            pygame.draw.rect(self.screen, COLORS["danger"], rect, 3, border_radius=8)

    if state.message:
      msg = self.font_sm.render(state.message, True, COLORS["accent2"])
      self.screen.blit(msg, msg.get_rect(center=(SCREEN_W // 2, 470)))

  def _draw_header(self, state: GameState) -> None:
    bar = pygame.Rect(0, 0, SCREEN_W, 34)
    pygame.draw.rect(self.screen, (20, 24, 32), bar)
    pygame.draw.line(self.screen, (52, 58, 70), (0, 34), (SCREEN_W, 34))

    kind_label = {"well": "우물", "jaw": "턱", "normal": "전투"}.get(state.enemy.kind, "")
    stage_txt = f"STAGE {state.enemy.stage}"
    if kind_label:
      stage_txt += f" · {kind_label}"
    stage_txt += f"  │  클리어 {state.wins}"
    st = self.font.render(stage_txt, True, COLORS["accent"])
    self.screen.blit(st, (16, 4))

    phase_names = {
      Phase.TAROT_PICK: "시작 타로 선택",
      Phase.TAROT_REWARD: "타로 보상",
      Phase.ARTIFACT_REWARD: "유물 선택",
      Phase.UPGRADE_SELECT: "강화 선택",
      Phase.WELL_STAGE: "우물 스테이지",
      Phase.JAW_STAGE: "턱 스테이지",
      Phase.BAN_SELECT: "세븐카드 — 밴 선택",
      Phase.DRAW_PICK: "세븐카드 — 1장 선택",
      Phase.FILL_HAND: "손패 완성",
      Phase.SCORE: "점수 합산",
      Phase.BATTLE_RESULT: "전투 결과",
      Phase.GAME_OVER: "게임 오버",
    }
    phase = self.font_sm.render(phase_names.get(state.phase, ""), True, COLORS["text_dim"])
    self.screen.blit(phase, (16 + st.get_width() + 24, 9))

  def _draw_enemy(self, state: GameState) -> None:
    # 우물·턱은 전용 전체화면에서 따로 표기 — 전투 적만 우측 상단에 간소 표시
    if state.enemy.kind in ("well", "jaw"):
      return
    panel = pygame.Rect(SCREEN_W - 288, 42, 276, 66)
    pygame.draw.rect(self.screen, COLORS["panel"], panel, border_radius=10)
    pygame.draw.rect(self.screen, (90, 50, 50), panel, 1, border_radius=10)
    name_txt = state.enemy.name
    if state.enemy.archetype == "fortress":
      name_txt += " · 요새"
    elif state.enemy.archetype == "blitz":
      name_txt += " · 맹습"
    name = self.font.render(name_txt, True, COLORS["danger"])
    self.screen.blit(name, (panel.x + 12, panel.y + 6))
    turn = self.font_sm.render(
      f"턴 {state.battle_turn}/{state.enemy.max_turns}", True, COLORS["accent"],
    )
    self.screen.blit(turn, (panel.right - turn.get_width() - 12, panel.y + 10))
    bar_bg = pygame.Rect(panel.x + 12, panel.y + 40, panel.w - 24, 16)
    pygame.draw.rect(self.screen, (30, 30, 30), bar_bg, border_radius=4)
    ratio = state.enemy.hp / state.enemy.max_hp if state.enemy.max_hp else 0
    bar = pygame.Rect(bar_bg.x, bar_bg.y, int(bar_bg.w * ratio), bar_bg.h)
    pygame.draw.rect(self.screen, COLORS["danger"], bar, border_radius=4)
    hp_text = self.font_sm.render(f"{state.enemy.hp:,} / {state.enemy.max_hp:,}", True, COLORS["text"])
    self.screen.blit(hp_text, hp_text.get_rect(center=bar_bg.center))

  def _draw_hand_bonus_strip(self, state: GameState) -> None:
    if state.phase in (Phase.TAROT_PICK, Phase.TAROT_REWARD, Phase.UPGRADE_SELECT,
                        Phase.WELL_STAGE, Phase.JAW_STAGE, Phase.GAME_OVER):
      return
    if not state.hand_bonuses:
      return
    from game.constants import HAND_LABELS_KO
    parts = [
      f"{HAND_LABELS_KO.get(h, h)}+{b}"
      for h, b in sorted(state.hand_bonuses.items()) if b > 0
    ]
    if not parts:
      return
    text = "족보 배수  " + " · ".join(parts)
    t = self.font_sm.render(text, True, COLORS["success"])
    self.screen.blit(t, (16, 42))

  def enemy_center(self) -> tuple[int, int]:
    return (SCREEN_W - 150, 75)

  def hand_center(self) -> tuple[int, int]:
    if self.hand_slot_rects:
      xs = [r.centerx for r in self.hand_slot_rects]
      ys = [r.centery for r in self.hand_slot_rects]
      return (sum(xs) // len(xs), sum(ys) // len(ys))
    return (SCREEN_W // 2, 336)

  def slot_center(self, index: int) -> tuple[int, int]:
    if 0 <= index < len(self.hand_slot_rects):
      return self.hand_slot_rects[index].center
    return self.hand_center()

  def starter_center(self, index: int) -> tuple[int, int]:
    if 0 <= index < len(self.starter_tarot_rects):
      return self.starter_tarot_rects[index].center
    return (SCREEN_W // 2, 290)

  def reward_center(self, index: int) -> tuple[int, int]:
    if 0 <= index < len(self.reward_tarot_rects):
      return self.reward_tarot_rects[index].center
    return (SCREEN_W // 2, 290)

  def _draw_discard_bar(self, state: GameState) -> None:
    if state.phase in (Phase.TAROT_PICK, Phase.TAROT_REWARD, Phase.UPGRADE_SELECT, Phase.GAME_OVER, Phase.WELL_STAGE, Phase.JAW_STAGE):
      return
    draw_discard_panel(
      self.screen,
      state.deck.discard,
      state.deck.banned,
      self.font_sm,
      self.font_sm,
      scroll=state.discard_scroll,
    )

  def _draw_tarot_pick(self, state: GameState, mouse_pos: tuple[int, int]) -> None:
    title = self.font_lg.render("시작 타로를 선택하세요", True, COLORS["text"])
    self.screen.blit(title, title.get_rect(center=(SCREEN_W // 2, 150)))
    sub = self.font_sm.render("탭하여 선택 · 확정 버튼으로 획득", True, COLORS["text_dim"])
    self.screen.blit(sub, sub.get_rect(center=(SCREEN_W // 2, 180)))

    for i, rect in enumerate(self.starter_tarot_rects):
      tarot = state.starter_tarot_choices[i]
      hover = rect.collidepoint(mouse_pos)
      selected = state.starter_pick_pending == i
      self._draw_tarot_card(rect, tarot, used=False, hover=hover, large=True, selected=selected)
      if hover and not self._hovered_tarot:
        draw_tarot_tooltip(self.screen, tarot, self.font_sm, mouse_pos)

  def _draw_tarot_reward(self, state: GameState, mouse_pos: tuple[int, int]) -> None:
    title = self.font_lg.render("새 타로를 선택하세요", True, COLORS["text"])
    self.screen.blit(title, title.get_rect(center=(SCREEN_W // 2, 150)))
    sub = self.font_sm.render("탭하여 선택 · 확정 버튼으로 획득", True, COLORS["text_dim"])
    self.screen.blit(sub, sub.get_rect(center=(SCREEN_W // 2, 180)))

    for i, rect in enumerate(self.reward_tarot_rects):
      tarot = state.reward_tarot_choices[i]
      hover = rect.collidepoint(mouse_pos)
      selected = state.reward_pick_pending == i
      self._draw_tarot_card(rect, tarot, used=False, hover=hover, large=True, selected=selected)
      if hover and not self._hovered_tarot:
        draw_tarot_tooltip(self.screen, tarot, self.font_sm, mouse_pos)

  def _draw_artifact_reward(self, state: GameState, mouse_pos: tuple[int, int]) -> None:
    title = self.font_lg.render("유물을 선택하세요", True, COLORS["text"])
    self.screen.blit(title, title.get_rect(center=(SCREEN_W // 2, 130)))
    sub = self.font_sm.render(
      "탭하여 선택 · 확정 버튼으로 획득",
      True, COLORS["text_dim"],
    )
    self.screen.blit(sub, sub.get_rect(center=(SCREEN_W // 2, 160)))

    for i, rect in enumerate(self.artifact_reward_rects):
      if i >= len(state.artifact_reward_choices):
        break
      aid = state.artifact_reward_choices[i]
      art = get_artifact(aid)
      hover = rect.collidepoint(mouse_pos)
      selected = state.artifact_pick_pending == i
      color = RARITY_COLORS[art.rarity]
      bg = COLORS["btn_hover"] if hover or selected else COLORS["panel"]
      pygame.draw.rect(self.screen, bg, rect, border_radius=12)
      border_w = 4 if selected else (3 if hover else 2)
      pygame.draw.rect(self.screen, color, rect, border_w, border_radius=12)
      rarity = self.font_sm.render(RARITY_LABELS[art.rarity], True, color)
      self.screen.blit(rarity, rarity.get_rect(center=(rect.centerx, rect.y + 22)))
      name = self.font.render(art.name, True, COLORS["text"])
      self.screen.blit(name, name.get_rect(center=(rect.centerx, rect.y + 52)))
      self._blit_wrapped_multiline(
        art.effect_summary,
        pygame.Rect(rect.x + 14, rect.y + 78, rect.w - 28, rect.h - 96),
        COLORS["text_dim"],
      )

  def _draw_artifact_strip(self, state: GameState) -> None:
    if state.phase in (
      Phase.TAROT_PICK, Phase.TAROT_REWARD, Phase.ARTIFACT_REWARD,
      Phase.UPGRADE_SELECT, Phase.WELL_STAGE, Phase.JAW_STAGE, Phase.GAME_OVER,
    ):
      return
    if not state.artifact_stacks:
      return
    parts: list[str] = []
    for aid, n in sorted(state.artifact_stacks.items()):
      if n <= 0:
        continue
      name = get_artifact(aid).name
      parts.append(f"{name}×{n}" if n > 1 else name)
    if not parts:
      return
    text = "유물  " + " · ".join(parts)
    t = self.font_sm.render(text, True, (210, 185, 130))
    self.screen.blit(t, (16, 58))

  def artifact_center(self, index: int) -> tuple[int, int]:
    if 0 <= index < len(self.artifact_reward_rects):
      return self.artifact_reward_rects[index].center
    return (SCREEN_W // 2, 290)

  def artifact_strip_anchor(self) -> tuple[int, int]:
    """상단 유물 스트립 부근 — 효과 발동 연출 기준점."""
    return (120, 64)

  def _draw_upgrade_select(self, state: GameState, mouse_pos: tuple[int, int]) -> None:
    from game.constants import HAND_LABELS_KO, HAND_MULTIPLIERS
    from game.progression import HAND_UPGRADE_AMOUNT

    title = self.font_lg.render("보상을 선택하세요", True, COLORS["text"])
    self.screen.blit(title, title.get_rect(center=(SCREEN_W // 2, 58)))
    tab_name = "타로 강화" if state.upgrade_tab == "tarot" else "족보 배수 강화"
    sub = self.font_sm.render(
      f"{tab_name} · 탭하여 선택 후 확정 (+{HAND_UPGRADE_AMOUNT} 배수 또는 타로 Lv+1)",
      True, COLORS["text_dim"],
    )
    self.screen.blit(sub, sub.get_rect(center=(SCREEN_W // 2, 128)))

    from game.tarot_data import get_tarot_def
    if state.upgrade_tab == "tarot":
      if not self.upgrade_tarot_rects:
        empty = self.font.render("강화할 타로가 없습니다", True, COLORS["text_dim"])
        self.screen.blit(empty, empty.get_rect(center=(SCREEN_W // 2, 280)))
      for rect, tarot in self.upgrade_tarot_rects:
        hover = rect.collidepoint(mouse_pos)
        selected = state.upgrade_tarot_pending == tarot.uid
        max_lv = get_tarot_def(tarot.number).max_level
        maxed = tarot.upgrade_level >= max_lv
        self._draw_tarot_card(
          rect, tarot, used=maxed, hover=hover, selected=selected and not maxed,
        )
        lv_color = COLORS["text_dim"] if maxed else COLORS["success"]
        lv = self.font_sm.render(f"Lv.{tarot.upgrade_level}/{max_lv}", True, lv_color)
        self.screen.blit(lv, (rect.x + 6, rect.y + 6))
        if maxed:
          mx = self.font_sm.render("MAX", True, COLORS["accent2"])
          self.screen.blit(mx, mx.get_rect(center=(rect.centerx, rect.bottom - 14)))
        if hover and not self._hovered_tarot:
          draw_tarot_tooltip(self.screen, tarot, self.font_sm, mouse_pos)
    else:
      for rect, hand_name in self.upgrade_hand_rects:
        hover = rect.collidepoint(mouse_pos)
        selected = state.upgrade_hand_pending == hand_name
        base = HAND_MULTIPLIERS[hand_name]
        bonus = state.hand_bonuses.get(hand_name, 0)
        label = HAND_LABELS_KO[hand_name]
        text = f"{label}  {base + bonus}x"
        if bonus > 0:
          text += f" (+{bonus})"
        if selected:
          color = COLORS["accent"]
        elif hover:
          color = COLORS["btn_hover"]
        else:
          color = COLORS["btn"]
        pygame.draw.rect(self.screen, color, rect, border_radius=8)
        border_col = COLORS["accent2"] if selected else COLORS["accent"]
        pygame.draw.rect(self.screen, border_col, rect, 3 if selected else 2, border_radius=8)
        t = self.font_sm.render(text, True, COLORS["text"])
        self.screen.blit(t, t.get_rect(center=rect.center))

  def _gradient_surface(self, w: int, h: int, c1, c2) -> pygame.Surface:
    surf = pygame.Surface((w, h))
    for y in range(h):
      t = y / max(1, h - 1)
      col = (
        int(c1[0] + (c2[0] - c1[0]) * t),
        int(c1[1] + (c2[1] - c1[1]) * t),
        int(c1[2] + (c2[2] - c1[2]) * t),
      )
      pygame.draw.line(surf, col, (0, y), (w, y))
    return surf

  def _draw_glow(self, rect: pygame.Rect, color, intensity: float, spread: int = 18) -> None:
    if intensity <= 0:
      return
    s = pygame.Surface((rect.w + spread * 2, rect.h + spread * 2), pygame.SRCALPHA)
    layers = 5
    for i in range(layers, 0, -1):
      a = int(intensity * 60 * (i / layers) / layers)
      pad = int(spread * i / layers)
      pygame.draw.rect(
        s, (*color, a),
        (spread - pad, spread - pad, rect.w + pad * 2, rect.h + pad * 2),
        border_radius=14,
      )
    self.screen.blit(s, (rect.x - spread, rect.y - spread))

  def _draw_tarot_card(
    self,
    rect: pygame.Rect,
    tarot: TarotCard,
    *,
    used: bool,
    hover: bool,
    large: bool = False,
    selected: bool = False,
  ) -> None:
    from game.tarot_data import get_tarot_def, ranks_to_text
    defn = get_tarot_def(tarot.number)
    theme = tarot_theme(tarot.number)
    pulse = 0.5 + 0.5 * math.sin(self.time * 4 + tarot.number)

    if not used and (hover or selected or large):
      glow_i = 1.4 if selected else (1.1 if hover else 0.7)
      self._draw_glow(rect, theme["accent"], glow_i * (0.7 + 0.3 * pulse))

    # 그라데이션 본체
    if used:
      grad = self._gradient_surface(rect.w, rect.h, (34, 30, 42), (46, 40, 56))
    else:
      grad = self._gradient_surface(rect.w, rect.h, theme["c1"], theme["c2"])
    mask = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
    pygame.draw.rect(mask, (255, 255, 255, 255), (0, 0, rect.w, rect.h), border_radius=10)
    grad = grad.convert_alpha()
    grad.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    self.screen.blit(grad, rect.topleft)

    # 빛나는 테두리
    border = theme["accent"] if (selected or hover) else theme["c2"]
    bw = 3 if (hover or selected) else 2
    pygame.draw.rect(self.screen, border, rect, bw, border_radius=10)
    if not used:
      inner = rect.inflate(-8, -8)
      ia = int(60 + 80 * pulse)
      isurf = pygame.Surface((inner.w, inner.h), pygame.SRCALPHA)
      pygame.draw.rect(isurf, (*theme["accent"], ia), (0, 0, inner.w, inner.h), 1, border_radius=8)
      self.screen.blit(isurf, inner.topleft)

    # 상단 로마숫자 + 별 장식
    num_font = self.font_title if large else self.font_lg
    self._blit_text_shadow(num_font, str(tarot.number), (rect.centerx, rect.y + (34 if large else 24)), (255, 255, 255))

    # 중앙 문양 글리프 (대응 문양 느낌의 빛나는 원)
    gcx, gcy = rect.centerx, rect.centery + (4 if large else 2)
    grad_r = (rect.w // 4) if large else (rect.w // 5)
    halo = pygame.Surface((grad_r * 4, grad_r * 4), pygame.SRCALPHA)
    pygame.draw.circle(halo, (*theme["accent"], int(70 + 60 * pulse)), (grad_r * 2, grad_r * 2), grad_r)
    pygame.draw.circle(halo, (255, 255, 255, 120), (grad_r * 2, grad_r * 2), max(2, grad_r // 2))
    self.screen.blit(halo, (gcx - grad_r * 2, gcy - grad_r * 2))

    # 이름
    if large:
      self._blit_text_shadow(self.font, defn.name, (rect.centerx, rect.centery + 44), (255, 245, 220))
      match = self.font_sm.render(ranks_to_text(defn.matching_ranks), True, (240, 240, 255))
      self.screen.blit(match, match.get_rect(center=(rect.centerx, rect.bottom - 24)))
    else:
      short = defn.name.split(" ", 1)[-1][:8]
      nm = self.font_sm.render(short, True, (245, 240, 255))
      self.screen.blit(nm, nm.get_rect(center=(rect.centerx, rect.bottom - 18)))

    if used:
      veil = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
      veil.fill((10, 8, 14, 150))
      self.screen.blit(veil, rect.topleft)
      used_t = self.font_sm.render("사용됨", True, COLORS["ban"])
      self.screen.blit(used_t, used_t.get_rect(center=rect.center))

  def _blit_text_shadow(self, font, text, center, color, shadow=(0, 0, 0)) -> None:
    sh = font.render(text, True, shadow)
    self.screen.blit(sh, sh.get_rect(center=(center[0] + 2, center[1] + 2)))
    t = font.render(text, True, color)
    self.screen.blit(t, t.get_rect(center=center))

  def _find_hovered_tarot(self, state: GameState, mouse_pos: tuple[int, int]) -> TarotCard | None:
    if state.phase == Phase.TAROT_PICK:
      for i, rect in enumerate(self.starter_tarot_rects):
        if rect.collidepoint(mouse_pos) and i < len(state.starter_tarot_choices):
          return state.starter_tarot_choices[i]
    if state.phase == Phase.TAROT_REWARD:
      for i, rect in enumerate(self.reward_tarot_rects):
        if rect.collidepoint(mouse_pos) and i < len(state.reward_tarot_choices):
          return state.reward_tarot_choices[i]
    if state.phase == Phase.UPGRADE_SELECT:
      for rect, tarot in self.upgrade_tarot_rects:
        if rect.collidepoint(mouse_pos):
          return tarot
    if state.phase == Phase.FILL_HAND:
      for rect, tarot in self.tarot_rects:
        used = tarot.uid in state.used_tarot_uids
        if rect.collidepoint(mouse_pos) and not used:
          return tarot
    return None

  def _draw_tarot_detail(self, state: GameState) -> None:
    show = state.pending_tarot or self._hovered_tarot
    if not show:
      return
    tarot = state.pending_tarot or self._hovered_tarot
    if not tarot:
      return
    is_pending = state.pending_tarot and state.pending_tarot.uid == tarot.uid
    if state.phase == Phase.TAROT_PICK:
      x, y, width = SCREEN_W - 300, 160, 280
    elif state.phase in (Phase.TAROT_REWARD, Phase.UPGRADE_SELECT):
      x, y, width = SCREEN_W - 300, 160, 280
    elif is_pending:
      x, y, width = SCREEN_W - 290, 280, 276
    else:
      x, y, width = SCREEN_W - 290, 280, 276
    draw_tarot_detail(
      self.screen,
      tarot,
      self.font,
      self.font_sm,
      self.font_lg,
      x=x,
      y=y,
      width=width,
      compact=not is_pending and state.phase not in (Phase.TAROT_PICK, Phase.TAROT_REWARD, Phase.UPGRADE_SELECT),
    )
    if state.phase in (Phase.TAROT_PICK, Phase.TAROT_REWARD) and self._hovered_tarot:
      hint = self.font_sm.render("클릭하여 선택", True, COLORS["accent"])
      self.screen.blit(hint, (x, y - 22))
    elif not is_pending and self._hovered_tarot:
      hint = self.font_sm.render("클릭하여 사용 · 우클릭 없음", True, COLORS["text_dim"])
      self.screen.blit(hint, (x, y - 22))

  def _draw_sub_phase(self, state: GameState, mouse_pos: tuple[int, int]) -> None:
    if state.phase != Phase.FILL_HAND:
      return
    labels = {
      SubPhase.PICK_FIVE: "5장 중 1장 선택",
      SubPhase.DEATH_PICK_THREE: f"묘지에서 3장 선택 ({len(state.death_picks)}/3) — 재탭 취소",
      SubPhase.MOON_PICK_HAND: f"달 — 교환할 패 선택 ({len(state.moon_hand_picks)}/2)",
      SubPhase.MOON_PICK_DISCARD: f"달 — 교환할 패 선택 ({len(state.moon_hand_picks)}/2)",
      SubPhase.MOON_PICK_DRAW: f"묘지에서 교환할 2장 ({len(state.death_picks)}/2) — 재탭 취소",
      SubPhase.RANK_PICK_TARGET: "변경할 카드 선택",
      SubPhase.RANK_PICK_VALUE: "변경할 랭크 선택",
      SubPhase.WHEEL_REROLL: f"수레바퀴 리롤 ({state.wheel_rolls}/5)",
      SubPhase.HERMIT_SUIT: "은둔자: 문양 선택",
      SubPhase.TEMPERANCE_SUIT: "절제: 원하는 문양 선택",
      SubPhase.TEMPERANCE_OFFER: "절제: 이 카드를 받을까요?",
      SubPhase.JUSTICE_PICK_SOURCE: "정의: 대칭 복제할 카드 선택",
      SubPhase.JOKER_TRANSFORM: "합산 전: 마법사 조커 변형 (52장 중 선택)",
      SubPhase.JOKER_FOOL_PICK: f"바보: 리롤할 카드 선택 ({state.fool_rerolls_left}회)",
      SubPhase.JAW_FANG_PICK: (
        f"앞니 유해: {len(state.jaw_fang_picks)}/{state.jaw_fang_quota}장 선택"
      ),
      SubPhase.JAW_MICHAEL_SEAL: "미카엘: 봉인할 타로 슬롯 선택",
      SubPhase.ACOLYTE_PICK: "안식의 시종 — 묘지에서 1장 선택",
      SubPhase.JIRI_DECK_PICK: "지리산 작두 — 덱에서 1장 선택",
      SubPhase.JAW_PICK_JAW: "턱 스테이지 — 이빨 자국(턱) 선택",
      SubPhase.JAW_PICK_CARD: "턱 스테이지 — 카드 선택",
      SubPhase.PRIESTESS_PICK: "여사제: 덱 위 5장 중 1장 선택",
    }
    if state.sub_phase != SubPhase.NONE and state.sub_phase in labels:
      label_y = 48 if state.sub_phase == SubPhase.JOKER_TRANSFORM else 90
      t = self.font.render(labels[state.sub_phase], True, COLORS["accent2"])
      self.screen.blit(t, t.get_rect(center=(SCREEN_W // 2, label_y)))

    pool = []
    if state.sub_phase == SubPhase.PICK_FIVE:
      pool = state.pick_pool
    elif state.sub_phase in (
      SubPhase.DEATH_PICK_THREE, SubPhase.MOON_PICK_DRAW,
      SubPhase.JOKER_TRANSFORM, SubPhase.PRIESTESS_PICK,
    ):
      pool = state.pick_pool

    if state.sub_phase == SubPhase.JOKER_TRANSFORM and self._pool_rects:
      panel = pygame.Rect(
        self._pool_rects[0].x - 16,
        self._pool_rects[0].y - 12,
        self._pool_rects[-1].right - self._pool_rects[0].x + 32,
        self._pool_rects[-1].bottom - self._pool_rects[0].y + 24,
      )
      pygame.draw.rect(self.screen, COLORS["panel"], panel, border_radius=10)
      pygame.draw.rect(self.screen, COLORS["accent"], panel, 2, border_radius=10)

    for i, rect in enumerate(self._pool_rects):
      if i < len(pool):
        selected = i in state.death_picks or (
          state.sub_phase == SubPhase.JOKER_FOOL_PICK and i in state.fool_pick_slots
        )
        self._draw_card(rect, pool[i], highlight=selected)

    if state.sub_phase == SubPhase.TEMPERANCE_OFFER and state.temperance_pending_card:
      rect = pygame.Rect(SCREEN_W // 2 - CARD_W // 2, 130, CARD_W, CARD_H)
      self._draw_card(rect, state.temperance_pending_card)

    if state.sub_phase == SubPhase.RANK_PICK_VALUE:
      from game.constants import RANK_LABELS
      from ui.suits import draw_suit, SUIT_LABELS_KO
      cx = SCREEN_W // 2
      # 미리보기 카드
      prev = pygame.Rect(cx - CARD_W // 2, 110, CARD_W, CARD_H)
      preview_card = Card(state.strength_rank, state.strength_suit)
      self._draw_card(prev, preview_card, highlight=True)
      hint = self.font.render(
        "랭크만 변경" if not state.strength_allow_suit else "랭크 / 문양을 골라 카드를 바꾸세요",
        True, COLORS["accent"],
      )
      self.screen.blit(hint, hint.get_rect(center=(cx, 90)))
      rlab = self.font.render(f"랭크: {RANK_LABELS[state.strength_rank]}", True, COLORS["text"])
      self.screen.blit(rlab, rlab.get_rect(center=(cx - 95, 230)))
      if state.strength_allow_suit:
        slab = self.font.render(f"문양: {SUIT_LABELS_KO[state.strength_suit]}", True, COLORS["text"])
        self.screen.blit(slab, slab.get_rect(center=(cx + 75, 230)))

    if state.sub_phase == SubPhase.HERMIT_SUIT:
      hint = self.font.render(
        "다음에 뽑을 카드는 가려져 있습니다 — 문양을 예측해 선택하세요",
        True, COLORS["accent"],
      )
      self.screen.blit(hint, hint.get_rect(center=(SCREEN_W // 2, 150)))
      for i in range(2):
        r = pygame.Rect(SCREEN_W // 2 - 100 + i * 110, 180, 90, 130)
        pygame.draw.rect(self.screen, COLORS["card_bg"], r, border_radius=8)
        pygame.draw.rect(self.screen, COLORS["accent"], r, 2, border_radius=8)
        q = self.font_title.render("?", True, COLORS["accent"])
        self.screen.blit(q, q.get_rect(center=r.center))

    if state.sub_phase == SubPhase.TEMPERANCE_SUIT:
      hint = self.font.render(
        "절제 — 다음 드로우에 적용할 문양을 선택하세요",
        True, COLORS["accent"],
      )
      self.screen.blit(hint, hint.get_rect(center=(SCREEN_W // 2, 150)))

    if self.selection_collapsed and state.sub_phase in COLLAPSIBLE_POOL_SUBPHASES:
      hint = self.font_sm.render(
        "선택창을 내렸습니다 — 아래 [선택창 올리기]로 다시 표시", True, COLORS["text_dim"],
      )
      self.screen.blit(hint, hint.get_rect(center=(SCREEN_W // 2, 120)))

  def _draw_next_draw_preview(self, state: GameState) -> None:
    """은둔자 등으로 공개된 다음 드로우 카드를 지속 표시 (실제로 뽑힐 때까지 유지)."""
    if not state.next_draw_preview or state.phase != Phase.FILL_HAND:
      return
    if state.sub_phase not in (SubPhase.NONE, SubPhase.TEMPERANCE_OFFER):
      return
    cards = state.next_draw_preview
    mw, mh, gap = 60, 86, 8
    panel_w = max(150, len(cards) * mw + (len(cards) - 1) * gap + 24)
    panel = pygame.Rect(SCREEN_W // 2 - panel_w // 2, 40, panel_w, mh + 40)
    pygame.draw.rect(self.screen, COLORS["panel"], panel, border_radius=10)
    pygame.draw.rect(self.screen, COLORS["accent2"], panel, 2, border_radius=10)
    title = self.font_sm.render("다음 드로우 (은둔자 공개)", True, COLORS["accent2"])
    self.screen.blit(title, (panel.x + 12, panel.y + 6))
    self._preview_rects = []
    sx = panel.centerx - (len(cards) * mw + (len(cards) - 1) * gap) // 2
    for i, card in enumerate(cards):
      r = pygame.Rect(sx + i * (mw + gap), panel.y + 28, mw, mh)
      self._preview_rects.append(r)
      self._draw_card(r, card)
      if i == 0:
        draw_triangle(self.screen, (r.centerx, panel.bottom - 10), 6, "down", COLORS["accent"])

  def _draw_hand_slots(self, state: GameState, score_reveal: ScoreRevealPlayer | None = None) -> None:
    from ui.themes import tier_style

    # 밴 단계에서는 손패가 완전히 비어 있고 배분된 카드가 상단에 따로 표시되므로
    # 빈 슬롯 플레이스홀더를 그리면 밴 카드와 겹친다 — 생략.
    if state.phase == Phase.BAN_SELECT:
      return

    joker_transform = (
      state.phase == Phase.FILL_HAND and state.sub_phase == SubPhase.JOKER_TRANSFORM
    )
    if not self.hand_slot_rects:
      return

    if joker_transform:
      panel = pygame.Rect(
        self.hand_slot_rects[0].x - 14,
        self.hand_slot_rects[0].y - 30,
        self.hand_slot_rects[-1].right - self.hand_slot_rects[0].x + 28,
        self.hand_slot_rects[0].h + 40,
      )
      pygame.draw.rect(self.screen, COLORS["panel"], panel, border_radius=10)
      pygame.draw.rect(self.screen, COLORS["accent"], panel, 2, border_radius=10)
      label = self.font_sm.render("현재 손패", True, COLORS["accent2"])
      self.screen.blit(label, (panel.x + 12, panel.y + 8))
    else:
      label = self.font.render(f"손패 ({state.max_hand_slots}칸)", True, COLORS["text"])
      self.screen.blit(label, (self.hand_slot_rects[0].x, self.hand_slot_rects[0].y - 30))

    if state.phase == Phase.FILL_HAND and state.live_hand_label and not joker_transform:
      style = tier_style(state.live_hand_tier)
      live = self.font_sm.render(
        f"현재 족보: {state.live_hand_label} ({state.live_hand_tier}등급)",
        True, style["color"],
      )
      self.screen.blit(live, (self.hand_slot_rects[-1].right - live.get_width(), self.hand_slot_rects[0].y - 28))
    elif joker_transform and state.live_hand_label:
      style = tier_style(state.live_hand_tier)
      live = self.font_sm.render(
        f"족보: {state.live_hand_label}",
        True, style["color"],
      )
      self.screen.blit(live, (self.hand_slot_rects[-1].right - live.get_width() - 8, self.hand_slot_rects[0].y - 22))

    joker_slot = state.joker_target_slot if joker_transform else None
    reveal_slots = score_reveal.highlight_slots if score_reveal and score_reveal.active else ()
    for i, rect in enumerate(self.hand_slot_rects):
      card = state.hand[i]
      if card:
        can_enhance = (
          state.pending_tarot is not None
          and state.phase == Phase.FILL_HAND
          and state.sub_phase == SubPhase.NONE
          and state.pending_tarot.can_enhance(card)
        )
        rank_target = state.sub_phase == SubPhase.RANK_PICK_TARGET
        moon_pick = (
          state.sub_phase in (SubPhase.MOON_PICK_HAND, SubPhase.MOON_PICK_DISCARD)
          and i in state.moon_hand_picks
        )
        justice_pick = state.sub_phase == SubPhase.JUSTICE_PICK_SOURCE
        fool_pick = state.sub_phase == SubPhase.JOKER_FOOL_PICK and i in state.fool_pick_slots
        fang_pick = state.sub_phase == SubPhase.JAW_FANG_PICK and i in state.jaw_fang_picks
        in_best = i in state.live_best_indices
        is_joker_target = joker_slot is not None and i == joker_slot
        reveal_highlight = i in reveal_slots
        self._draw_card(
          rect, card,
          highlight=can_enhance or rank_target or moon_pick or justice_pick or fool_pick or fang_pick or in_best or is_joker_target or reveal_highlight,
        )
        if is_joker_target:
          pygame.draw.rect(self.screen, COLORS["accent2"], rect, 3, border_radius=8)
          tag = self.font_sm.render("조커", True, COLORS["accent2"])
          self.screen.blit(tag, (rect.x + 4, rect.y + 4))
      else:
        pygame.draw.rect(self.screen, COLORS["slot_empty"], rect, border_radius=8)
        pygame.draw.rect(self.screen, COLORS["card_border"], rect, 2, border_radius=8)
        num = self.font_sm.render(str(i + 1), True, COLORS["text_dim"])
        self.screen.blit(num, num.get_rect(center=rect.center))

  def _draw_phase_cards(self, state: GameState) -> None:
    if state.phase == Phase.BAN_SELECT:
      from game.artifact_runtime import indulgence_discard_count
      if has_artifact(state.artifact_stacks, "indulgence"):
        need = indulgence_discard_count(state.artifact_stacks)
        label_txt = f"묘지로 보낼 카드 {need}장 선택"
      else:
        label_txt = "밴할 카드 2장 선택"
      label = self.font.render(label_txt, True, COLORS["text"])
      self.screen.blit(label, (self.card_rects[0].x if self.card_rects else 40, 90))
      for i, rect in enumerate(self.card_rects):
        banned = i in state.ban_selection
        card = state.opening_five[i]
        self._draw_card(rect, card, highlight=banned, ban_overlay=banned)

    elif state.phase == Phase.DRAW_PICK:
      label = self.font.render("가져갈 카드 1장 선택", True, COLORS["text"])
      self.screen.blit(label, (self.card_rects[0].x if self.card_rects else 40, 90))
      for i, rect in enumerate(self.card_rects):
        self._draw_card(rect, state.draw_three[i])

  def _draw_kingslayer(self, state: GameState, mouse_pos: tuple[int, int]) -> None:
    if state.phase != Phase.FILL_HAND or not self.kingslayer_rect:
      return
    rect = self.kingslayer_rect
    if not self.tarot_rects:
      label = self.font_sm.render("유물 검", True, COLORS["text_dim"])
      self.screen.blit(label, (rect.x, 386))
    spent = state.kingslayer_spent
    armed = state.kingslayer_armed
    hover = rect.collidepoint(mouse_pos) and state.sub_phase == SubPhase.NONE
    used = spent
    border = (220, 70, 80) if armed else COLORS["card_border"]
    if hover and not used:
      border = (255, 140, 130)
    pygame.draw.rect(self.screen, (28, 22, 30), rect, border_radius=10)
    pygame.draw.rect(self.screen, border, rect, 3 if armed else 2, border_radius=10)
    title = self.font_sm.render("왕을", True, (220, 90, 90))
    sub = self.font_sm.render("죽이는 검", True, (255, 180, 170))
    self.screen.blit(title, title.get_rect(center=(rect.centerx, rect.centery - 18)))
    self.screen.blit(sub, sub.get_rect(center=(rect.centerx, rect.centery + 4)))
    if armed:
      tag = self.font_sm.render("발동", True, (255, 220, 120))
      self.screen.blit(tag, tag.get_rect(center=(rect.centerx, rect.bottom - 14)))
    elif used:
      tag = self.font_sm.render("사용됨", True, COLORS["ban"])
      self.screen.blit(tag, tag.get_rect(center=(rect.centerx, rect.bottom - 14)))
    else:
      tag = self.font_sm.render("클릭", True, COLORS["text_dim"])
      self.screen.blit(tag, tag.get_rect(center=(rect.centerx, rect.bottom - 14)))
    if hover and not used:
      lines = [
        "왕을 죽이는 검",
        "클릭해 발동 · 합산 후 검격",
        f"칩 1당 최대HP {KINGSLAYER_CHIP_PCT * 100:.2f}%",
        "스테이지당 1회",
      ]
      w = max(self.font_sm.size(line)[0] for line in lines) + 24
      h = len(lines) * 20 + 14
      x = min(mouse_pos[0] + 16, SCREEN_W - w - 8)
      y = max(8, mouse_pos[1] - h - 8)
      tip_rect = pygame.Rect(x, y, w, h)
      pygame.draw.rect(self.screen, (20, 24, 32), tip_rect, border_radius=8)
      pygame.draw.rect(self.screen, (220, 80, 80), tip_rect, 1, border_radius=8)
      for i, line in enumerate(lines):
        t = self.font_sm.render(line, True, COLORS["text"])
        self.screen.blit(t, (tip_rect.x + 10, tip_rect.y + 8 + i * 20))

  def _draw_tarots(self, state: GameState, mouse_pos: tuple[int, int]) -> None:
    if state.phase not in (Phase.FILL_HAND, Phase.SCORE):
      return
    if self.tarot_rects:
      label = self.font_sm.render(
        f"타로 ({state.tarot_uses_left}/{3}회 남음)", True, COLORS["text"]
      )
      lx = self.tarot_rects[0][0].x
      self.screen.blit(label, (lx, 386))
    for rect, tarot in self.tarot_rects:
      sealed = tarot.uid in state.sealed_tarot_uids
      used = tarot.uid in state.used_tarot_uids or sealed
      hover = rect.collidepoint(mouse_pos) and (
        not used or state.sub_phase == SubPhase.JAW_MICHAEL_SEAL
      ) and not sealed
      selected = state.pending_tarot and state.pending_tarot.uid == tarot.uid
      self._draw_tarot_card(rect, tarot, used=used, hover=hover, selected=bool(selected))
      if sealed:
        seal = self.font_sm.render("봉인", True, COLORS["ban"])
        self.screen.blit(seal, seal.get_rect(center=rect.center))
      if hover and not self._hovered_tarot:
        draw_tarot_tooltip(self.screen, tarot, self.font_sm, mouse_pos)

  def _draw_sidebar(self, state: GameState, score_reveal: ScoreRevealPlayer | None = None) -> None:
    # 좌측 열: 메시지 + 덱 통계 (스테이지 정보는 상단 바, 족보배수는 별도 스트립)
    msg_panel = pygame.Rect(12, 66, 276, 48)
    pygame.draw.rect(self.screen, COLORS["panel"], msg_panel, border_radius=10)
    self._blit_wrapped(state.message, msg_panel, COLORS["accent2"])

    stats = (
      f"덱 {len(state.deck.deck)} · 묘지 {len(state.deck.discard)} · "
      f"밴 {len(state.deck.banned)} · 손 {state.hand_count()}/{state.max_hand_slots}"
    )
    st = self.font_sm.render(stats, True, COLORS["text_dim"])
    self.screen.blit(st, (16, 498))
    if state.hanged_man_cooldown > 0:
      cd = self.font_sm.render(f"매달린 사람 CD {state.hanged_man_cooldown}", True, COLORS["ban"])
      self.screen.blit(cd, (16, 520))
    if has_artifact(state.artifact_stacks, "kingslayer_sword") and state.kingslayer_spent:
      kcd = self.font_sm.render(
        "왕을 죽이는 검 — 이번 스테이지 사용됨", True, (200, 90, 90),
      )
      y_cd = 542 if state.hanged_man_cooldown > 0 else 520
      self.screen.blit(kcd, (16, y_cd))

    # 우측 열: 점수 미리보기 / 족보 참조
    preview = state.preview_score()
    show_preview = (
      preview and state.phase == Phase.FILL_HAND
      and not state.pending_tarot and not self._hovered_tarot
    )
    if show_preview:
      prev_panel = pygame.Rect(SCREEN_W - 288, 120, 276, 140)
      pygame.draw.rect(self.screen, COLORS["panel"], prev_panel, border_radius=10)
      pygame.draw.rect(self.screen, COLORS["success"], prev_panel, 1, border_radius=10)
      p_lines = [
        "점수 미리보기",
        f"족보: {preview['hand_label']}",
        f"배수: {preview['multiplier']}x",
        f"칩 합: {preview['chip_sum']}",
        f"예상: {preview['total']}",
      ]
      for i, line in enumerate(p_lines):
        color = COLORS["success"] if i == 4 else COLORS["text"]
        t = self.font_sm.render(line, True, color)
        self.screen.blit(t, (prev_panel.x + 14, prev_panel.y + 10 + i * 24))
    elif state.phase in (Phase.BAN_SELECT, Phase.DRAW_PICK, Phase.FILL_HAND) and not self._hovered_tarot and not state.pending_tarot:
      ref = pygame.Rect(SCREEN_W - 288, 120, 276, 150)
      draw_hand_reference(self.screen, self.font_sm, ref)

    if state.last_score and state.phase in (Phase.SCORE, Phase.BATTLE_RESULT):
      if state.phase == Phase.SCORE and score_reveal and (score_reveal.active or score_reveal.in_crack):
        score_reveal.draw_panel(self.screen, SCREEN_W // 2, 108)
      elif state.score_damage_applied or state.phase == Phase.BATTLE_RESULT:
        score_panel = pygame.Rect(SCREEN_W // 2 - 200, 120, 400, 140)
        pygame.draw.rect(self.screen, COLORS["panel"], score_panel, border_radius=12)
        pygame.draw.rect(self.screen, COLORS["success"], score_panel, 3, border_radius=12)
        s = state.last_score
        lines = [
          s["hand_label"],
          f"{s['multiplier']} × {s['chip_sum']} = {s['total']}",
          f"→ {s['total'] + s.get('bonus_damage', 0)} 피해!",
        ]
        for i, line in enumerate(lines):
          font = self.font_lg if i == 0 else self.font
          color = COLORS["success"] if i == 2 else COLORS["text"]
          t = font.render(line, True, color)
          self.screen.blit(t, t.get_rect(center=(score_panel.centerx, score_panel.y + 30 + i * 36)))

  def _draw_buttons(self, mouse_pos: tuple[int, int]) -> None:
    for btn in self.buttons:
      suit = self._suit_btn_map.get(btn.action)
      btn.draw(self.screen, self.font_sm if suit else self.font, btn.hit(mouse_pos), suit)

  def _draw_card(
    self,
    rect: pygame.Rect,
    card: Card,
    highlight: bool = False,
    ban_overlay: bool = False,
  ) -> None:
    pulse = 0.5 + 0.5 * math.sin(self.time * 5)
    if card.is_joker_card:
      theme = tarot_theme(1)
      self._draw_glow(rect, theme["accent"], 0.9 + 0.4 * pulse, spread=20)
      grad = self._gradient_surface(rect.w, rect.h, theme["c1"], theme["c2"])
      self.screen.blit(grad, rect.topleft)
      pygame.draw.rect(self.screen, theme["accent"], rect, 3, border_radius=8)
      star = self.font_title.render("★", True, (255, 255, 220))
      self.screen.blit(star, star.get_rect(center=rect.center))
      jk = self.font_sm.render("조커", True, (255, 245, 200))
      self.screen.blit(jk, jk.get_rect(center=(rect.centerx, rect.bottom - 16)))
      if card._has_real_rank():
        sub = self.font_sm.render(f"{card.label}{card.suit[0].upper()}", True, COLORS["text"])
        self.screen.blit(sub, (rect.x + 6, rect.y + 6))
      return
    if highlight and not ban_overlay:
      self._draw_glow(rect, COLORS["accent"], 0.6 + 0.5 * pulse, spread=14)
    elif ban_overlay:
      self._draw_glow(rect, COLORS["ban"], 0.5 + 0.4 * pulse, spread=12)
    elif card.tarot_number:
      theme = tarot_theme(card.tarot_number)
      self._draw_glow(rect, theme["accent"], 0.4 + 0.25 * pulse, spread=10)

    pygame.draw.rect(self.screen, COLORS["card_bg"], rect, border_radius=8)
    if card.tarot_number:
      theme = tarot_theme(card.tarot_number)
      tint = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
      pygame.draw.rect(tint, (*theme["c2"], 60), (0, 0, rect.w, rect.h), border_radius=8)
      self.screen.blit(tint, rect.topleft)
    border = COLORS["ban"] if ban_overlay else COLORS["accent"] if highlight else COLORS["card_border"]
    width = 3 if highlight or ban_overlay else 2
    pygame.draw.rect(self.screen, border, rect, width, border_radius=8)

    suit_color = SUIT_COLORS[card.suit]
    rank_font = self.font_sm if rect.w < 56 else self.font_lg
    rank_x = rect.x + max(4, rect.w // 12)
    rank_y = rect.y + max(4, rect.h // 14)

    mod = card_visual_mods(card, getattr(self, "_artifact_stacks", {}))

    if mod and mod.new_rank_label:
      self._draw_rank_change(rect, rank_font, mod, suit_color, rank_x, rank_y)
    else:
      rank = rank_font.render(card.label, True, suit_color)
      self.screen.blit(rank, (rank_x, rank_y))
    suit_size = min(44, max(14, rect.h // 3))
    draw_suit(self.screen, card.suit, rect.center, suit_size, suit_color)
    if mod and mod.chip_override is not None and rect.w >= 50:
      self._draw_chip_override(rect, mod)
    if rect.w >= 56:
      draw_suit(self.screen, card.suit, (rect.right - 18, rect.bottom - 16), min(16, rect.h // 8), suit_color)

    if card.tarot_number:
      tarot_t = self.font_sm.render(f"T{card.tarot_number}", True, COLORS["accent2"])
      self.screen.blit(tarot_t, (rect.x + 8, rect.bottom - 22))
    if card.bonus_value:
      bonus = self.font_sm.render(f"+{card.bonus_value}", True, COLORS["success"])
      self.screen.blit(bonus, (rect.right - 30, rect.y + 8))
    if card.has_jaw_mark:
      from game.jaws import get_jaw
      jaw = get_jaw(card.jaw_id or "")
      bite_color = (200, 55, 55)
      pygame.draw.line(
        self.screen, bite_color,
        (rect.x + 6, rect.y + rect.h - 10), (rect.x + rect.w // 2, rect.y + rect.h - 22), 3,
      )
      pygame.draw.line(
        self.screen, bite_color,
        (rect.x + rect.w // 2, rect.y + rect.h - 22), (rect.right - 8, rect.y + rect.h - 8), 3,
      )
      # 송곳니(이빨자국) 아이콘을 도형으로 — 번들 폰트에 한자 글리프가 없음
      fx0 = rect.x + 6
      fy = rect.bottom - 8
      for k in range(3):
        bx = fx0 + k * 7
        pygame.draw.polygon(
          self.screen, bite_color,
          [(bx, fy - 9), (bx + 6, fy - 9), (bx + 3, fy)],
        )
      jt = self.font_sm.render(jaw.name[:4], True, COLORS["danger"])
      self.screen.blit(jt, (rect.right - min(40, rect.w - 4), rect.bottom - 20))

  def _draw_rank_change(
    self,
    rect: pygame.Rect,
    rank_font: pygame.font.Font,
    mod,
    suit_color: tuple[int, int, int],
    rank_x: int,
    rank_y: int,
  ) -> None:
    """페일노트 등 — 원래 랭크는 희미하게, 적용된 랭크를 강조해 표시."""
    pulse = 0.5 + 0.5 * math.sin(self.time * 4)
    accent = (130, 225, 255)

    # 원래 랭크: 작고 희미하게 + 취소선
    small = self.font_sm
    orig = small.render(mod.orig_rank_label, True, (120, 125, 135))
    orig.set_alpha(150)
    self.screen.blit(orig, (rank_x, rank_y))
    ow, oh = orig.get_size()
    pygame.draw.line(
      self.screen, (170, 90, 90),
      (rank_x, rank_y + oh // 2), (rank_x + ow, rank_y + oh // 2), 2,
    )

    # 적용된 랭크: 바로 아래에 강조색으로
    glow_col = tuple(min(255, int(c * (0.7 + 0.3 * pulse))) for c in accent)
    new = rank_font.render(mod.new_rank_label, True, glow_col)
    self.screen.blit(new, (rank_x, rank_y + oh - 2))

    if rect.w >= 56:
      tag = self.font_sm.render(mod.source, True, accent)
      tag.set_alpha(200)
      self.screen.blit(tag, (rect.x + 4, rect.bottom - 34))

  def _draw_chip_override(self, rect: pygame.Rect, mod) -> None:
    """진은의 깃털 등 — 변경된 칩 값을 배지로 표시."""
    pulse = 0.5 + 0.5 * math.sin(self.time * 4)
    col = (240, 200, 90)
    glow_col = tuple(min(255, int(c * (0.7 + 0.3 * pulse))) for c in col)
    txt = self.font_sm.render(f"칩 {mod.chip_override}", True, glow_col)
    bw, bh = txt.get_size()
    badge = pygame.Rect(rect.right - bw - 10, rect.bottom - bh - 6, bw + 8, bh + 4)
    bg = pygame.Surface((badge.w, badge.h), pygame.SRCALPHA)
    pygame.draw.rect(bg, (30, 25, 10, 200), (0, 0, badge.w, badge.h), border_radius=5)
    self.screen.blit(bg, badge.topleft)
    pygame.draw.rect(self.screen, col, badge, 1, border_radius=5)
    self.screen.blit(txt, (badge.x + 4, badge.y + 2))

  def _layout_compact_card_grid(
    self,
    count: int,
    cols: int = 13,
    cw: int = 46,
    ch: int = 58,
    gap: int = 3,
    start_y: int = 108,
  ) -> list[pygame.Rect]:
    grid_w = cols * cw + max(0, cols - 1) * gap
    sx = (SCREEN_W - grid_w) // 2
    rects: list[pygame.Rect] = []
    for i in range(count):
      row = i // cols
      col = i % cols
      x = sx + col * (cw + gap)
      y = start_y + row * (ch + gap)
      rects.append(pygame.Rect(x, y, cw, ch))
    return rects

  def _blit_wrapped_multiline(
    self,
    text: str,
    rect: pygame.Rect,
    color: tuple[int, int, int],
    line_gap: int = 4,
  ) -> None:
    words = text.replace(" · ", " · ").split()
    lines: list[str] = []
    current = ""
    max_w = rect.w
    for word in words:
      trial = f"{current} {word}".strip()
      if self.font_sm.size(trial)[0] <= max_w:
        current = trial
      else:
        if current:
          lines.append(current)
        current = word
    if current:
      lines.append(current)
    y = rect.y
    for line in lines:
      if y + self.font_sm.get_height() > rect.bottom:
        break
      surf = self.font_sm.render(line, True, color)
      self.screen.blit(surf, (rect.x, y))
      y += self.font_sm.get_height() + line_gap

  def _blit_wrapped(self, text: str, rect: pygame.Rect, color: tuple[int, int, int]) -> None:
    self._blit_wrapped_multiline(text, rect, color)

  def handle_click(self, state: GameState, pos: tuple[int, int], mods: int = 0) -> str | None:
    alchemy_action = alchemy_click_action(state, pos, self.alchemy_rects)
    if alchemy_action:
      if alchemy_action == "alchemy_toggle":
        self.alchemy_collapsed = not self.alchemy_collapsed
        return None
      return alchemy_action

    if state.phase == Phase.MAIN_MENU:
      for btn in self.buttons:
        if btn.hit(pos):
          return btn.action
      return None

    n_ban = len(state.deck.banned)
    if n_ban > 0 or not self.banned_collapsed:
      bar_h = 36 if self.banned_collapsed else min(180, 56 + (n_ban + 5) // 6 * 28)
      bar = pygame.Rect(300, SCREEN_H - bar_h - 8, SCREEN_W - 320, bar_h)
      if bar.collidepoint(pos) and pos[1] < bar.y + 30:
        self.banned_collapsed = not self.banned_collapsed
        return None

    if state.phase == Phase.GAME_OVER:
      for btn in self.buttons:
        if btn.hit(pos):
          return btn.action
      return None

    for btn in self.buttons:
      if btn.hit(pos):
        if btn.action == "toggle_pool":
          self.selection_collapsed = not self.selection_collapsed
          return None
        return btn.action

    if state.phase == Phase.TAROT_PICK:
      for i, rect in enumerate(self.starter_tarot_rects):
        if rect.collidepoint(pos):
          return f"select_starter_{i}"

    elif state.phase == Phase.TAROT_REWARD:
      for i, rect in enumerate(self.reward_tarot_rects):
        if rect.collidepoint(pos):
          return f"select_reward_{i}"

    elif state.phase == Phase.ARTIFACT_REWARD:
      for i, rect in enumerate(self.artifact_reward_rects):
        if rect.collidepoint(pos):
          return f"select_artifact_{i}"

    elif state.phase == Phase.UPGRADE_SELECT:
      for rect, tarot in self.upgrade_tarot_rects:
        if rect.collidepoint(pos):
          return f"select_upgrade_tarot_{tarot.uid}"
      for rect, hand_name in self.upgrade_hand_rects:
        if rect.collidepoint(pos):
          return f"select_upgrade_hand_{hand_name}"

    elif state.phase == Phase.JAW_STAGE:
      if state.sub_phase == SubPhase.JAW_PICK_CARD:
        for i, rect in enumerate(self.jaw_card_rects):
          if rect.collidepoint(pos):
            return f"pick_jaw_card_{i}"
      elif state.sub_phase == SubPhase.JAW_PICK_JAW:
        for i, rect in enumerate(self.jaw_offer_rects):
          if rect.collidepoint(pos):
            return f"pick_jaw_{i}"

    elif state.phase == Phase.WELL_STAGE:
      if state.sub_phase == SubPhase.WELL_GAIN_PICK:
        for i, rect in enumerate(self._pool_rects):
          if rect.collidepoint(pos):
            return f"well_pick_gain_{i}"
      elif state.sub_phase == SubPhase.NONE:
        for vi, rect in enumerate(self.well_deck_rects):
          if rect.collidepoint(pos):
            di = self._well_deck_indices[vi] if vi < len(self._well_deck_indices) else vi
            return f"well_discard_{di}"

    elif state.phase == Phase.BAN_SELECT:
      for i, rect in enumerate(self.card_rects):
        if rect.collidepoint(pos):
          return f"ban_{i}"

    elif state.phase == Phase.DRAW_PICK:
      for i, rect in enumerate(self.card_rects):
        if rect.collidepoint(pos):
          return f"pick_{i}"

    elif state.phase == Phase.FILL_HAND:
      if state.sub_phase == SubPhase.RANK_PICK_TARGET:
        for i, rect in enumerate(self.hand_slot_rects):
          if rect.collidepoint(pos) and state.hand[i]:
            return f"rank_target_{i}"
      elif state.sub_phase in (SubPhase.MOON_PICK_HAND, SubPhase.MOON_PICK_DISCARD):
        for i, rect in enumerate(self.hand_slot_rects):
          if rect.collidepoint(pos) and state.hand[i]:
            return f"moon_toggle_{i}"
      elif state.sub_phase == SubPhase.JUSTICE_PICK_SOURCE:
        for i, rect in enumerate(self.hand_slot_rects):
          if rect.collidepoint(pos) and state.hand[i]:
            return f"justice_pick_{i}"
      elif state.sub_phase == SubPhase.JOKER_FOOL_PICK:
        for i, rect in enumerate(self.hand_slot_rects):
          if rect.collidepoint(pos) and state.hand[i]:
            return f"fool_toggle_{i}"
      elif state.sub_phase == SubPhase.JAW_FANG_PICK:
        for i, rect in enumerate(self.hand_slot_rects):
          if rect.collidepoint(pos) and state.hand[i]:
            return f"jaw_fang_toggle_{i}"
      elif state.sub_phase == SubPhase.JAW_MICHAEL_SEAL:
        for rect, tarot in self.tarot_rects:
          if rect.collidepoint(pos) and tarot.uid not in state.sealed_tarot_uids:
            return f"seal_tarot_{tarot.uid}"
      elif state.sub_phase == SubPhase.JOKER_TRANSFORM:
        for i, rect in enumerate(self._pool_rects):
          if rect.collidepoint(pos):
            return f"pick_joker_{i}"
      elif state.sub_phase == SubPhase.PRIESTESS_PICK:
        for i, rect in enumerate(self._pool_rects):
          if rect.collidepoint(pos):
            return f"pick_priestess_{i}"
      elif state.sub_phase == SubPhase.PICK_FIVE:
        for i, rect in enumerate(self._pool_rects):
          if rect.collidepoint(pos):
            return f"pick_five_{i}"
      elif state.sub_phase in (
        SubPhase.DEATH_PICK_THREE, SubPhase.MOON_PICK_DRAW, SubPhase.ACOLYTE_PICK,
        SubPhase.JIRI_DECK_PICK,
      ):
        for i, rect in enumerate(self._pool_rects):
          if rect.collidepoint(pos):
            if state.sub_phase == SubPhase.JIRI_DECK_PICK:
              return f"jiri_pick_{i}"
            return f"pick_pool_{i}"
      elif state.sub_phase == SubPhase.RANK_PICK_VALUE:
        for rect, rank in self._rank_btn_rects:
          if rect.collidepoint(pos):
            return f"rank_value_{rank}"
      elif state.pending_tarot:
        for rect, tarot in self.tarot_rects:
          if (
            rect.collidepoint(pos)
            and tarot.uid not in state.used_tarot_uids
            and tarot.uid not in state.sealed_tarot_uids
          ):
            return f"tarot_{tarot.uid}"
        for i, rect in enumerate(self.hand_slot_rects):
          if rect.collidepoint(pos) and state.hand[i]:
            return f"enhance_{i}"
      elif state.sub_phase == SubPhase.NONE:
        if self.kingslayer_rect and self.kingslayer_rect.collidepoint(pos):
          return "kingslayer_toggle"
        for rect, tarot in self.tarot_rects:
          if (
            rect.collidepoint(pos)
            and tarot.uid not in state.used_tarot_uids
            and tarot.uid not in state.sealed_tarot_uids
          ):
            return f"tarot_{tarot.uid}"

    return None
