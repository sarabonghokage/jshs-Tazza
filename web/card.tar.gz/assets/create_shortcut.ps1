# Create desktop shortcut for the game
$ErrorActionPreference = "Stop"
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$bat = Join-Path $root "run_game.bat"
$desk = [Environment]::GetFolderPath("Desktop")
$lnkPath = Join-Path $desk "Play Tarot Trump.lnk"

$wsh = New-Object -ComObject WScript.Shell
$sc = $wsh.CreateShortcut($lnkPath)
$sc.TargetPath = $bat
$sc.WorkingDirectory = $root
$sc.Description = "Tarot Trump card game"
$sc.Save()

Write-Host "Shortcut: $lnkPath"
