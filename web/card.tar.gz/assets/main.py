"""트럼프 × 타로 — Pygame 프로토타입"""

from __future__ import annotations

import asyncio
import sys

import pygame

from game.constants import FPS, SCREEN_H, SCREEN_W
from game.state import GameState, Phase, SubPhase, SubPhase
from ui.effects import EffectManager
from ui.renderer import Renderer
from ui.info_panels import InfoPanelManager
from ui.score_reveal import ScoreRevealPlayer
from ui.themes import hand_tier, tier_style
from game.artifact_runtime import has_artifact, indulgence_discard_count


def spawn_score_damage_effects(
  state: GameState, renderer: Renderer, fx: EffectManager, damage: int,
) -> None:
  if not state.last_score or damage <= 0:
    return
  s = state.last_score
  tier = hand_tier(s["hand_name"])
  center = renderer.hand_center()
  enemy = renderer.enemy_center()
  defeated = state.enemy.hp <= 0
  fx.spawn_score(center, s["hand_label"], tier, s["total"], enemy)

  def on_hit(_enemy=enemy, _total=damage, _tier=tier, _defeated=defeated):
    fx.spawn_hit(_enemy, _total, _tier)
    if _defeated:
      fx.spawn_enemy_defeat(_enemy)

  fx.spawn_damage_beam(center, enemy, damage, tier, on_hit)


def update_score_reveal(
  state: GameState,
  renderer: Renderer,
  fx: EffectManager,
  score_reveal: ScoreRevealPlayer,
  dt: float,
  last_step_index: int,
) -> int:
  if state.phase != Phase.SCORE:
    return -1
  event = score_reveal.update(dt)
  if event == "crack_start":
    fx.spawn_kingslayer_crack()
  idx = score_reveal.index
  if idx != last_step_index and score_reveal.current:
    step = score_reveal.current
    slot_center = renderer.slot_center(step.slot) if step.slot is not None else renderer.hand_center()
    score_reveal.spawn_step_fx(fx, slot_center, step, renderer)
  if score_reveal.ready_for_damage and not state.score_damage_applied:
    damage = state.apply_score_damage()
    if damage > 0:
      spawn_score_damage_effects(state, renderer, fx, damage)
    score_reveal.consume_total_fx()
  return idx


def _hand_sig(hand) -> tuple:
  return tuple(
    (c.rank, c.suit, c.tarot_number, c.bonus_value) if c else None for c in hand
  )


def _changed_index(before: tuple, after: tuple) -> int | None:
  for i in range(min(len(before), len(after))):
    if before[i] != after[i] and after[i] is not None:
      return i
  return None


def perform(state: GameState, action: str, renderer: Renderer | None = None) -> dict:
  """액션을 수행하고, 효과 트리거에 필요한 변화 정보를 반환."""
  snap = {
    "count": state.hand_count(),
    "uses": state.tarot_uses_left,
    "phase": state.phase,
    "hand_sig": _hand_sig(state.hand),
    "sig": _hand_sig(state.hand),
    "pending": state.pending_tarot.number if state.pending_tarot else None,
    "enemy_hp": state.enemy.hp,
    "starter_index": None,
    "reward_index": None,
    "joker_draw_face": None,
    "joker_transform": False,
    "jaw_mark": None,
    "artifact_index": None,
    "artifact_id": None,
    "artifact_activate": None,
  }
  sub_before = state.sub_phase
  if action.startswith("pick_starter_"):
    snap["starter_index"] = int(action.split("_")[2])
  if action.startswith("pick_reward_"):
    snap["reward_index"] = int(action.split("_")[2])
  if action.startswith("pick_artifact_"):
    idx = int(action.split("_")[2])
    snap["artifact_index"] = idx
    if idx < len(state.artifact_reward_choices):
      snap["artifact_id"] = state.artifact_reward_choices[idx]
  if action.startswith("pick_jaw_card_") and renderer:
    renderer.layout(state)
    idx = int(action.split("_")[3])
    if (
      state.phase == Phase.JAW_STAGE
      and state.sub_phase == SubPhase.JAW_PICK_CARD
      and state.jaw_picked_offer_index is not None
      and idx < len(renderer.jaw_card_rects)
    ):
      from game.jaws import get_jaw
      jaw = get_jaw(state.jaw_offers[state.jaw_picked_offer_index])
      snap["jaw_mark"] = {
        "center": renderer.jaw_card_rects[idx].center,
        "name": jaw.name,
        "tier": jaw.tier.value,
        "id": jaw.id,
      }
  handle_action(state, action)
  if renderer:
    anchor = renderer.artifact_strip_anchor()
    hand_c = renderer.hand_center()
  else:
    anchor = (120, 64)
    hand_c = (640, 360)
  if action == "draw" and has_artifact(state.artifact_stacks, "blood_horn"):
    snap["artifact_activate"] = {"aid": "blood_horn", "center": anchor}
  elif action == "confirm_ban" and has_artifact(state.artifact_stacks, "indulgence"):
    snap["artifact_activate"] = {"aid": "indulgence", "center": hand_c}
  elif action.startswith("jaw_reroll_") and has_artifact(state.artifact_stacks, "rusty_pelican"):
    snap["artifact_activate"] = {"aid": "rusty_pelican", "center": hand_c}
  elif action == "traitor_jaw_tarot" and has_artifact(state.artifact_stacks, "traitor_tongue"):
    snap["artifact_activate"] = {"aid": "traitor_tongue", "center": hand_c}
  elif (
    action.startswith("pick_pool_")
    and sub_before == SubPhase.ACOLYTE_PICK
    and has_artifact(state.artifact_stacks, "resting_acolyte")
  ):
    snap["artifact_activate"] = {"aid": "resting_acolyte", "center": anchor}
  elif (
    action == "confirm_score"
    and snap["enemy_hp"] > 0
    and state.enemy.hp <= 0
    and has_artifact(state.artifact_stacks, "ether")
  ):
    snap["artifact_activate"] = {"aid": "ether", "center": hand_c}
  elif "부활" in state.message and has_artifact(state.artifact_stacks, "compressed_head"):
    snap["artifact_activate"] = {"aid": "compressed_head", "center": hand_c}
  elif action == "color_red" and has_artifact(state.artifact_stacks, "red_bowl"):
    snap["artifact_activate"] = {"aid": "red_bowl", "center": hand_c, "slot": hand_c}
  elif action.startswith("suit_") and has_artifact(state.artifact_stacks, "red_bowl"):
    idx = int(action.split("_")[1])
    if idx in (0, 1):
      slot = renderer.slot_center(idx) if renderer else hand_c
      snap["artifact_activate"] = {"aid": "red_bowl", "center": anchor, "slot": slot}
  elif action == "score" and has_artifact(state.artifact_stacks, "star_clock"):
    hn = (state.last_score or {}).get("hand_name", "")
    if hn in ("high_card", "pair"):
      snap["artifact_activate"] = {"aid": "star_clock", "center": hand_c}
  elif (
    state.tarot_uses_left < snap["uses"]
    and has_artifact(state.artifact_stacks, "future_shackle")
  ):
    snap["artifact_activate"] = {"aid": "future_shackle", "center": anchor}
  if action.startswith("pick_joker_"):
    snap["joker_transform"] = True
  face = state.joker_draw_face
  if face is not None:
    snap["joker_draw_face"] = face
    state.joker_draw_face = None
  return snap


def trigger_effects(state: GameState, snap: dict, renderer: Renderer, fx: EffectManager) -> None:
  new_count = state.hand_count()
  new_sig = _hand_sig(state.hand)

  # 시작 타로 선택 → 큰 테마 폭발
  if snap["phase"] == Phase.TAROT_PICK and state.phase != Phase.TAROT_PICK:
    idx = snap["starter_index"] or 0
    num = state.tarots[0].number if state.tarots else 1
    rect = pygame.Rect(0, 0, 140, 180)
    rect.center = renderer.starter_center(idx)
    fx.spawn_tarot(rect, num, big=True)

  if snap["phase"] == Phase.TAROT_REWARD and state.phase != Phase.TAROT_REWARD:
    idx = snap.get("reward_index") or 0
    num = state.tarots[-1].number if state.tarots else 1
    rect = pygame.Rect(0, 0, 140, 180)
    rect.center = renderer.reward_center(idx)
    fx.spawn_tarot(rect, num, big=True)

  if snap["phase"] == Phase.ARTIFACT_REWARD and state.phase != Phase.ARTIFACT_REWARD:
    idx = snap.get("artifact_index") or 0
    center = renderer.artifact_center(idx)
    aid = snap.get("artifact_id")
    if aid:
      from ui.artifact_fx import spawn_artifact_acquire
      spawn_artifact_acquire(fx, aid, center)
    else:
      from ui.artifact_fx import spawn_artifact_acquire
      spawn_artifact_acquire(fx, "", center)

  # 드로우 / 손패 변화 → 족보 미리보기 연출
  new_sig = _hand_sig(state.hand)
  if state.phase == Phase.FILL_HAND and state.live_hand_label:
    if new_sig != snap["hand_sig"] or new_count > snap["count"]:
      center = renderer.hand_center()
      fx.spawn_hand_preview(center, state.live_hand_label, state.live_hand_tier)
    fx.set_ambient_tier(state.live_hand_tier)
  elif state.phase != Phase.FILL_HAND:
    fx.set_ambient_tier(0)

  if snap.get("artifact_activate"):
    from ui.artifact_fx import spawn_artifact_activate
    info = snap["artifact_activate"]
    spawn_artifact_activate(
      fx, info["aid"], info["center"],
      slot_center=info.get("slot"),
    )

  if snap.get("jaw_mark"):
    from game.jaws import JawTier
    info = snap["jaw_mark"]
    tier_colors = {
      JawTier.NOBILITY.value: (210, 175, 90),
      JawTier.HERO_VILLAIN.value: (200, 100, 100),
      JawTier.WANDERER_ARTIST.value: (120, 170, 210),
      JawTier.SAINT_DEVIL.value: (170, 120, 210),
    }
    color = tier_colors.get(info["tier"], (200, 80, 80))
    fx.spawn_jaw_mark(info["center"], info["name"], color)
    if info["tier"] == JawTier.SAINT_DEVIL.value:
      is_devil = str(info.get("id", "")).startswith("devil")
      fx.spawn_saint_devil_mark(info["center"], info["name"], is_devil)

  if snap.get("joker_transform"):
    rect = pygame.Rect(0, 0, 140, 180)
    rect.center = renderer.hand_center()
    fx.spawn_tarot(rect, 1, big=True)

  if snap.get("joker_draw_face") is not None:
    face = snap["joker_draw_face"]
    fx.spawn_joker_flip(renderer.hand_center(), face)
    if face == 21:
      fx.spawn_world_swap()

  # 타로 사용 (사용 횟수 감소)
  if state.tarot_uses_left < snap["uses"]:
    num = snap["pending"] or 1
    if new_count > snap["count"]:
      ci = snap["count"]  # 새로 추가된 슬롯
    else:
      ci = _changed_index(snap["sig"], new_sig)
    rect = pygame.Rect(0, 0, 90, 130)
    rect.center = renderer.slot_center(ci if ci is not None else 0)
    fx.spawn_tarot(rect, num, big=False)
  # 일반 드로우 (사용 횟수 변화 없이 카드 증가)
  elif new_count > snap["count"]:
    for slot in range(snap["count"], new_count):
      rect = pygame.Rect(0, 0, 90, 130)
      rect.center = renderer.slot_center(slot)
      fx.spawn_draw(rect)

  # 손패 완성 알림 (7장째 — 자동 합산 없음)
  if (
    snap["phase"] == Phase.FILL_HAND
    and state.phase == Phase.FILL_HAND
    and state.is_hand_full()
    and snap["count"] < state.max_hand_slots
  ):
    center = renderer.hand_center()
    fx.spawn_hand_preview(center, state.live_hand_label or "손패 완성", max(1, state.live_hand_tier))


def handle_action(state: GameState, action: str) -> None:
  if action.startswith("select_starter_"):
    state.select_starter_tarot(int(action.split("_")[2]))
  elif action == "confirm_starter":
    state.confirm_starter_tarot()
  elif action == "cancel_starter":
    state.cancel_starter_pick()
  elif action.startswith("pick_starter_"):
    state.pick_starter_tarot(int(action.split("_")[2]))
  elif action.startswith("select_reward_"):
    state.select_reward_tarot(int(action.split("_")[2]))
  elif action == "confirm_reward":
    state.confirm_reward_tarot()
  elif action == "cancel_reward":
    state.cancel_reward_pick()
  elif action.startswith("pick_reward_"):
    state.pick_reward_tarot(int(action.split("_")[2]))
  elif action.startswith("select_artifact_"):
    state.select_artifact(int(action.split("_")[2]))
  elif action == "confirm_artifact":
    state.confirm_artifact_pick()
  elif action == "cancel_artifact":
    state.cancel_artifact_pick()
  elif action.startswith("pick_artifact_"):
    state.pick_artifact(int(action.split("_")[2]))
  elif action == "upgrade_tab_tarot":
    state.set_upgrade_tab("tarot")
  elif action == "upgrade_tab_hand":
    state.set_upgrade_tab("hand")
  elif action.startswith("select_upgrade_tarot_"):
    state.select_upgrade_tarot(int(action.split("_")[3]))
  elif action.startswith("select_upgrade_hand_"):
    state.select_upgrade_hand(action[len("select_upgrade_hand_"):])
  elif action == "confirm_upgrade":
    state.confirm_upgrade_pick()
  elif action == "cancel_upgrade":
    state.cancel_upgrade_pick()
  elif action.startswith("upgrade_tarot_"):
    state.upgrade_tarot(int(action.split("_")[2]))
  elif action.startswith("upgrade_hand_"):
    state.upgrade_hand(action[len("upgrade_hand_"):])
  elif action.startswith("pick_joker_"):
    state.pick_joker_transform(int(action.split("_")[2]))
  elif action.startswith("pick_priestess_"):
    state.pick_priestess(int(action.split("_")[2]))
  elif action.startswith("pick_jaw_card_"):
    state.pick_jaw_card(int(action.split("_")[3]))
  elif action.startswith("pick_jaw_"):
    state.pick_jaw_offer(int(action.split("_")[2]))
  elif action.startswith("fool_toggle_"):
    state.toggle_fool_pick(int(action.split("_")[2]))
  elif action.startswith("jaw_fang_toggle_"):
    state.toggle_jaw_fang_pick(int(action.split("_")[3]))
  elif action == "confirm_jaw_fang":
    state.confirm_jaw_fang_reroll()
  elif action.startswith("seal_tarot_"):
    state.seal_tarot_michael(int(action.split("_")[2]))
  elif action == "confirm_fool":
    state.confirm_fool_reroll()
  elif action == "well_gain_pick":
    state.well_begin_gain_pick()
  elif action.startswith("well_pick_gain_"):
    state.well_pick_gain(int(action.split("_")[3]))
  elif action.startswith("well_discard_"):
    state.well_discard_at(int(action.split("_")[2]))
  elif action == "well_finish":
    state.well_finish()
  elif action == "confirm_ban":
    state.confirm_ban()
  elif action.startswith("ban_"):
    state.toggle_ban(int(action.split("_")[1]))
  elif action.startswith("pick_five_"):
    state.pick_from_five(int(action.split("_")[2]))
  elif action.startswith("pick_pool_"):
    idx = int(action.split("_")[2])
    if state.sub_phase == SubPhase.DEATH_PICK_THREE:
      state.toggle_death_pick(idx)
    elif state.sub_phase == SubPhase.MOON_PICK_DRAW:
      state.toggle_moon_grave_pick(idx)
    elif state.sub_phase == SubPhase.ACOLYTE_PICK:
      state.pick_acolyte_card(idx)
  elif action == "confirm_death_pick":
    state.confirm_death_pick()
  elif action == "confirm_moon_pick":
    state.confirm_moon_pick()
  elif action.startswith("jaw_reroll_"):
    state.reroll_jaw_offer(int(action.split("_")[2]))
  elif action == "traitor_jaw_tarot":
    state.traitor_jaw_take_tarot()
  elif action.startswith("pick_"):
    state.pick_from_three(int(action.split("_")[1]))
  elif action == "draw":
    state.draw_trump()
  elif action == "kingslayer_toggle":
    state.toggle_kingslayer()
  elif action.startswith("tarot_"):
    uid = int(action.split("_")[1])
    for tarot in state.tarots:
      if tarot.uid == uid:
        state.select_tarot(tarot)
        break
  elif action.startswith("suit_"):
    idx = int(action.split("_")[1])
    if state.sub_phase == SubPhase.HERMIT_SUIT:
      state.pick_hermit_suit(idx)
    elif state.sub_phase == SubPhase.TEMPERANCE_SUIT:
      state.pick_temperance_suit(idx)
    elif state.pending_tarot and state.tarot_mode == "choose":
      state.play_tarot_with_suit(idx)
    else:
      state.play_tarot_with_suit(idx)
  elif action.startswith("justice_pick_"):
    state.pick_justice_source(int(action.split("_")[2]))
  elif action == "color_red":
    state.play_tarot_with_color("red")
  elif action == "color_black":
    state.play_tarot_with_color("black")
  elif action.startswith("enhance_"):
    state.enhance_with_tarot(int(action.split("_")[1]))
  elif action.startswith("rank_target_"):
    state.pick_rank_target(int(action.split("_")[2]))
  elif action.startswith("rank_value_"):
    state.apply_rank_change(int(action.split("_")[2]))
  elif action == "str_rank_dec":
    state.strength_adjust_rank(-1)
  elif action == "str_rank_inc":
    state.strength_adjust_rank(1)
  elif action == "str_suit_dec":
    state.strength_adjust_suit(-1)
  elif action == "str_suit_inc":
    state.strength_adjust_suit(1)
  elif action == "str_confirm":
    state.strength_confirm()
  elif action.startswith("moon_toggle_"):
    state.toggle_moon_discard(int(action.split("_")[2]))
  elif action == "wheel_reroll":
    state.wheel_reroll()
  elif action == "wheel_done":
    state.wheel_done()
  elif action == "temperance_accept":
    state.accept_temperance_draw()
  elif action == "temperance_reroll":
    state.reroll_temperance()
  elif action == "score":
    if state.phase == Phase.FILL_HAND and state.is_hand_full():
      state._try_enter_score_phase()
  elif action == "cancel_tarot":
    state.cancel_tarot()
  elif action == "confirm_score":
    state.confirm_score()
  elif action == "restart_game":
    state.restart_game()
  elif action == "begin_run":
    state.begin_run()
  elif action == "continue_run":
    state.continue_from_save()
  elif action == "show_records":
    state.show_records()
    from game.leaderboard import schedule_sync
    schedule_sync(fetch_after=True)
  elif action == "back_main":
    state.show_main_menu()
  elif action == "records_tab_local":
    state.records_tab = "local"
    state.name_editing = False
  elif action == "records_tab_global":
    state.records_tab = "global"
    state.name_editing = False
    from game.leaderboard import schedule_sync
    schedule_sync(fetch_after=True)
  elif action == "records_sort_stage":
    state.records_global_sort = "stage"
    from game.leaderboard import schedule_sync
    schedule_sync(fetch_after=True)
  elif action == "records_sort_damage":
    state.records_global_sort = "damage"
    from game.leaderboard import schedule_sync
    schedule_sync(fetch_after=True)
  elif action == "toggle_name_edit":
    if state.name_editing:
      from game.leaderboard import set_player_name, schedule_sync
      set_player_name(state.name_edit_buffer)
      state.name_editing = False
      try:
        pygame.key.stop_text_input()
      except Exception:
        pass
      schedule_sync(fetch_after=False)
    elif sys.platform == "emscripten":
      # 모바일/웹(WebView)에서는 SDL 텍스트 입력만으로는 가상 키보드가 뜨지
      # 않는 경우가 많다. 네이티브 prompt 다이얼로그를 쓰면 키보드/한글 IME가
      # 정상 동작한다. (Capacitor 가 네이티브 입력 다이얼로그로 처리)
      #
      # 한글 인코딩 주의: prompt() 가 돌려준 JS 문자열을 Python 으로 "직접"
      # 변환하면 멀티바이트(한글)가 깨진다. 그래서 JS 쪽에서 encodeURIComponent
      # 로 ASCII(%XX)로 만들어 건너온 뒤 Python 에서 utf-8 로 unquote 한다.
      import json as _json
      import urllib.parse as _up

      from game.leaderboard import get_player_name, set_player_name, schedule_sync
      cur = get_player_name()
      name = None
      try:
        import platform  # type: ignore[import-not-found]
        js = (
          '((x)=>x===null?"":("v"+encodeURIComponent(x)))'
          "(window.prompt(%s,%s))"
          % (_json.dumps("이름을 입력하세요 (최대 16자)"), _json.dumps(cur or ""))
        )
        enc = str(platform.window.eval(js))
        if enc.startswith("v"):
          name = _up.unquote(enc[1:], encoding="utf-8").strip()[:16]
      except Exception:
        name = None
      if name:
        set_player_name(name)
        state.name_edit_buffer = name
        schedule_sync(fetch_after=False)
    else:
      from game.leaderboard import get_player_name
      state.name_edit_buffer = get_player_name()
      state.name_editing = True
      try:
        pygame.key.start_text_input()
      except Exception:
        pass
  elif action == "jiri_pick":
    state.begin_jiri_pick()
  elif action.startswith("jiri_pick_"):
    state.jiri_pick_card(int(action.split("_")[2]))
  elif action == "coward_void":
    state.coward_void_hand()
  elif action == "alchemy_toggle":
    pass
  elif action == "next_round":
    state.next_round()
  elif action.startswith("alchemy_add_"):
    state.alchemy_add_essence(action[len("alchemy_add_"):])
  elif action.startswith("alchemy_slot_"):
    state.alchemy_return_slot(int(action.split("_")[2]))
  elif action == "alchemy_transmute":
    state.alchemy_transmute()
  elif action == "alchemy_clear":
    state.alchemy_clear_slots()


def do(state, action, renderer, fx) -> None:
  snap = perform(state, action, renderer)
  trigger_effects(state, snap, renderer, fx)
  if action not in ("continue_run",):
    state.save_progress()


def _reseed_rng() -> None:
  """pygbag 웹 런타임은 random.seed(1)을 고정으로 박아 매 실행이 동일해진다.
  실행마다 다른 난수를 보장하기 위해 비결정적 소스로 다시 시드한다."""
  import random
  import time
  seed = time.time_ns() ^ (id(object()) << 16)
  try:
    seed ^= int.from_bytes(__import__("os").urandom(8), "big")
  except Exception:
    pass
  random.seed(seed)


async def main() -> None:
  _reseed_rng()
  pygame.init()
  pygame.display.set_caption("한라산 작두 강지후-제곽의 타짜")
  display = pygame.display.set_mode((SCREEN_W, SCREEN_H))
  scene = pygame.Surface((SCREEN_W, SCREEN_H))
  clock = pygame.time.Clock()
  renderer = Renderer(scene)
  fx = EffectManager()
  score_reveal = ScoreRevealPlayer()
  info_panels = InfoPanelManager()
  state = GameState()
  state.show_main_menu()
  from game.leaderboard import schedule_sync
  schedule_sync(fetch_after=False)
  prev_phase = state.phase
  prev_phase_for_sync = state.phase
  reveal_step_index = -1

  running = True

  def frame():
    nonlocal running, prev_phase, prev_phase_for_sync, reveal_step_index
    dt = clock.tick(FPS) / 1000.0
    dt = min(dt, 0.05)
    renderer.time += dt
    fx.update(dt)

    if state.phase == Phase.SCORE and prev_phase != Phase.SCORE and state.score_reveal_steps:
      tier = hand_tier(state.last_score["hand_name"]) if state.last_score else 0
      finale = state.kingslayer_finale_steps or None
      score_reveal.start(state.score_reveal_steps, tier, finale_steps=finale)
      reveal_step_index = -1
    elif state.phase != Phase.SCORE and score_reveal.active:
      score_reveal.reset()
      reveal_step_index = -1

    reveal_step_index = update_score_reveal(
      state, renderer, fx, score_reveal, dt, reveal_step_index,
    )

    prev_phase = state.phase

    if state.phase in (Phase.MAIN_MENU, Phase.RECORDS) and prev_phase_for_sync != state.phase:
      from game.leaderboard import schedule_sync
      schedule_sync(fetch_after=(state.phase == Phase.RECORDS))
    if state.phase == Phase.GAME_OVER and prev_phase_for_sync != Phase.GAME_OVER:
      from game.leaderboard import schedule_sync
      schedule_sync(fetch_after=False)
    prev_phase_for_sync = state.phase
    mouse_pos = pygame.mouse.get_pos()
    for event in pygame.event.get():
      if event.type == pygame.QUIT:
        state.save_progress()
        running = False
      elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
        inv_action = info_panels.handle_click(event.pos)
        if inv_action:
          info_panels.apply_inventory_action(inv_action)
        else:
          action = renderer.handle_click(state, event.pos, pygame.key.get_mods())
          if action:
            do(state, action, renderer, fx)
      elif event.type == pygame.MOUSEWHEEL:
        if info_panels.show_deck or info_panels.show_banned:
          info_panels.scroll_deck(event.y)
        elif state.phase == Phase.WELL_STAGE and state.sub_phase == SubPhase.NONE:
          pass  # 우물 덱은 스크롤 없이 전체 표시
        elif state.phase not in (Phase.TAROT_PICK, Phase.TAROT_REWARD, Phase.UPGRADE_SELECT):
          state.scroll_discard(-event.y)
      elif event.type == pygame.KEYDOWN:
        if state.phase == Phase.RECORDS and state.name_editing:
          # 이름 편집 중에는 게임 단축키(인벤토리 등)가 동작하면 안 된다.
          # 편집용 키만 처리하고 나머지는 무시한다(글자는 TEXTINPUT 에서 처리).
          if event.key == pygame.K_RETURN:
            do(state, "toggle_name_edit", renderer, fx)
          elif event.key == pygame.K_ESCAPE:
            from game.leaderboard import get_player_name
            state.name_editing = False
            state.name_edit_buffer = get_player_name()
            try:
              pygame.key.stop_text_input()
            except Exception:
              pass
          elif event.key == pygame.K_BACKSPACE:
            state.name_edit_buffer = state.name_edit_buffer[:-1]
        elif info_panels.handle_key(event.key):
          pass
        elif event.key == pygame.K_d and state.phase == Phase.FILL_HAND and not info_panels.any_open():
          do(state, "draw", renderer, fx)
        elif event.key == pygame.K_RETURN:
          if state.phase == Phase.RECORDS and state.name_editing:
            do(state, "toggle_name_edit", renderer, fx)
          elif state.phase == Phase.BAN_SELECT:
            need = (
              indulgence_discard_count(state.artifact_stacks)
              if has_artifact(state.artifact_stacks, "indulgence")
              else 2
            )
            if len(state.ban_selection) == need:
              do(state, "confirm_ban", renderer, fx)
          elif state.phase == Phase.FILL_HAND and state.is_hand_full() and state.sub_phase == SubPhase.NONE:
            do(state, "score", renderer, fx)
          elif state.phase == Phase.SCORE:
            if score_reveal.in_crack:
              score_reveal.skip_crack()
              fx.spawn_kingslayer_crack()
            elif not score_reveal.done:
              score_reveal.skip_to_end()
              if score_reveal.in_crack:
                fx.spawn_kingslayer_crack()
            elif score_reveal.ready_for_damage and not state.score_damage_applied:
              damage = state.apply_score_damage()
              if damage > 0:
                spawn_score_damage_effects(state, renderer, fx, damage)
              score_reveal.consume_total_fx()
            elif state.score_damage_applied:
              do(state, "confirm_score", renderer, fx)
          elif state.phase == Phase.MAIN_MENU:
            from game.persistence import has_saved_game
            if has_saved_game():
              do(state, "continue_run", renderer, fx)
            else:
              do(state, "begin_run", renderer, fx)
          elif state.phase == Phase.RECORDS:
            if state.name_editing:
              do(state, "toggle_name_edit", renderer, fx)
            else:
              do(state, "back_main", renderer, fx)
          elif state.phase == Phase.BATTLE_RESULT:
            do(state, "next_round", renderer, fx)
          elif state.phase == Phase.GAME_OVER:
            do(state, "restart_game", renderer, fx)
          elif state.phase == Phase.WELL_STAGE:
            do(state, "well_finish", renderer, fx)
          elif state.sub_phase == SubPhase.JOKER_FOOL_PICK:
            do(state, "confirm_fool", renderer, fx)
          elif state.sub_phase == SubPhase.JAW_FANG_PICK:
            do(state, "confirm_jaw_fang", renderer, fx)
          elif state.sub_phase == SubPhase.DEATH_PICK_THREE and len(state.death_picks) == 3:
            do(state, "confirm_death_pick", renderer, fx)
          elif state.sub_phase == SubPhase.MOON_PICK_DRAW and len(state.death_picks) == 2:
            do(state, "confirm_moon_pick", renderer, fx)
          elif state.phase == Phase.TAROT_PICK and state.starter_pick_pending is not None:
            do(state, "confirm_starter", renderer, fx)
          elif state.phase == Phase.TAROT_REWARD and state.reward_pick_pending is not None:
            do(state, "confirm_reward", renderer, fx)
          elif state.phase == Phase.ARTIFACT_REWARD and state.artifact_pick_pending is not None:
            do(state, "confirm_artifact", renderer, fx)
          elif state.phase == Phase.UPGRADE_SELECT and (
            state.upgrade_tarot_pending is not None or state.upgrade_hand_pending is not None
          ):
            do(state, "confirm_upgrade", renderer, fx)
        elif event.key == pygame.K_ESCAPE:
          if info_panels.any_open():
            info_panels.close_all()
          elif state.phase == Phase.RECORDS and state.name_editing:
            from game.leaderboard import get_player_name
            state.name_editing = False
            state.name_edit_buffer = get_player_name()
          elif state.phase == Phase.RECORDS:
            do(state, "back_main", renderer, fx)
          elif state.phase == Phase.TAROT_PICK and state.starter_pick_pending is not None:
            state.cancel_starter_pick()
          elif state.phase == Phase.TAROT_REWARD and state.reward_pick_pending is not None:
            state.cancel_reward_pick()
          elif state.phase == Phase.ARTIFACT_REWARD and state.artifact_pick_pending is not None:
            state.cancel_artifact_pick()
          elif state.phase == Phase.UPGRADE_SELECT and (
            state.upgrade_tarot_pending is not None or state.upgrade_hand_pending is not None
          ):
            state.cancel_upgrade_pick()
          elif state.pending_tarot:
            state.cancel_tarot()
          elif state.sub_phase == SubPhase.WHEEL_REROLL:
            state.wheel_done()
        elif (
          state.phase == Phase.RECORDS
          and state.name_editing
          and event.key == pygame.K_BACKSPACE
        ):
          state.name_edit_buffer = state.name_edit_buffer[:-1]
      elif event.type == pygame.TEXTINPUT:
        # 글자 입력은 TEXTINPUT 에서만 처리한다. KEYDOWN(event.unicode)에서도
        # 추가하면 영어가 두 번 입력되고, 한글 IME 조합과 충돌해 깨진다.
        if state.phase == Phase.RECORDS and state.name_editing:
          for ch in event.text:
            if ch.isprintable() and len(state.name_edit_buffer) < 16:
              state.name_edit_buffer += ch

    renderer.draw(state, mouse_pos, score_reveal=score_reveal)
    info_panels.draw(scene, state)
    if state.phase not in (Phase.MAIN_MENU, Phase.RECORDS):
      info_panels.draw_inventory_button(scene, renderer.font_sm)
    fx.draw_world(scene)
    help = "D: 드로우 | Enter: 확정 | I: 유물 | T: 타로 | L: 덱 | B: 밴 | ESC: 닫기"
    if state.phase == Phase.MAIN_MENU:
      from game.persistence import has_saved_game
      help = "Enter: 이어하기 | 새 게임은 버튼 클릭" if has_saved_game() else "Enter: 게임 시작"
    elif state.phase == Phase.RECORDS:
      if state.name_editing:
        help = "이름 입력 — Enter: 저장 | ESC: 취소"
      else:
        help = "랭킹 — 탭 전환 | 이름 변경 | Enter/ESC/뒤로: 메인으로"
    if state.phase == Phase.FILL_HAND and state.is_hand_full() and state.sub_phase == SubPhase.NONE:
      help = "손패 완성 — 타로 사용 후 [점수 확정] | Enter: 점수 확정"
    elif state.phase == Phase.SCORE and score_reveal.in_crack:
      help = "검격 연출 중... Enter: 건너뛰기"
    elif state.phase == Phase.SCORE and not score_reveal.ready_for_damage:
      help = "점수 합산 연출 중... Enter: 건너뛰기"
    elif state.phase == Phase.SCORE and state.score_damage_applied:
      help = "Enter: 확인"
    help_text = renderer.font_sm.render(help, True, (120, 125, 135))
    scene.blit(help_text, (SCREEN_W // 2 - help_text.get_width() // 2, SCREEN_H - 134))

    ox, oy = fx.get_shake()
    display.fill((0, 0, 0))
    display.blit(scene, (ox, oy))
    fx.draw_overlay(display)
    pygame.display.flip()

  import traceback as _tb
  while running:
    try:
      frame()
    except Exception:
      # 한 프레임에서 예외가 나도 게임 전체(웹 탭)가 죽지 않도록 방어.
      # 트레이스백은 브라우저 콘솔에 남겨 원인 추적에 사용.
      print("[FRAME ERROR] 프레임 처리 중 예외 — 게임을 계속 진행합니다")
      _tb.print_exc()
    # pygbag(웹) 환경에서 브라우저에 제어권을 넘겨주기 위해 필수
    await asyncio.sleep(0)

  pygame.quit()


if __name__ == "__main__":
  asyncio.run(main())
