# 트럼프 × 타로

포커 족보 점수로 적을 처치하는 Pygame 로그라이크. 타로·턱·우물·연금술 시스템 포함.

## 로컬 실행 (데스크톱)

```bash
pip install pygame
python main.py
```

- `D`: 트럼프 드로우 · `Enter`: 확정 · 마우스 휠: 묘지 스크롤
- 연금술: 좌측 하단 패널에서 원소를 슬롯에 넣고 `연성`

## 웹 배포 (Netlify)

이 게임은 [pygbag](https://pypi.org/project/pygbag/)으로 WebAssembly로 빌드해 정적 호스팅한다.

### 핵심 전제 (이미 적용됨)

- `main.py`의 메인 루프가 `async def main()` + `await asyncio.sleep(0)` 구조로 작성됨 (pygbag 필수 요건)
- 한글 폰트(`assets/fonts/Pretendard-*.ttf`)를 번들하고 `ui/fonts.py`로 로드 — 브라우저 환경엔 시스템 한글 폰트가 없기 때문

### 방법 A — 로컬 빌드 후 결과물 배포 (가장 안정적)

```bash
pip install pygbag
python -m pygbag --build main.py
```

> **Windows 주의:** 소스에 한글 주석이 있어 pygbag가 cp949로 읽으면 에러가 난다.
> PowerShell에서 빌드 전에 `$env:PYTHONUTF8=1` 을 설정하세요.
> (Linux/Netlify CI는 기본이 UTF-8이라 불필요)

- `build/web/` 폴더가 생성된다.
- Netlify 대시보드에서 이 `build/web` 폴더를 **드래그&드롭** 하거나, Netlify CLI 사용:

```bash
npm install -g netlify-cli
netlify deploy --prod --dir build/web
```

> 이 방식으로 git 배포하려면 `.gitignore`의 `build/` 줄을 지우고 `build/web`을 커밋하세요.

### 방법 B — Netlify CI에서 자동 빌드

저장소를 Netlify에 연결하면 `netlify.toml`의 설정에 따라 CI가 직접 빌드한다.

```toml
[build]
  publish = "build/web"
  command = "pip install pygbag && python -m pygbag --build main.py"
```

CI 빌드가 실패하면 방법 A(로컬 빌드본 배포)로 전환하세요.

### 로컬에서 웹 빌드 미리보기

```bash
python -m pygbag main.py
# 브라우저로 http://localhost:8000 접속
```

## 폰트 라이선스

`assets/fonts/Pretendard-*.ttf` 는 SIL Open Font License(OFL) 인 [Pretendard](https://github.com/orioncactus/pretendard) 이며 재배포가 허용된다.
