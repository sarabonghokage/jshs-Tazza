@echo off
chcp 65001 >nul
cd /d "%~dp0"
title 트럼프 x 타로
python main.py
if errorlevel 1 (
  echo.
  echo 게임이 오류로 종료되었습니다.
  pause
)
