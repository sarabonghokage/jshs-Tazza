from __future__ import annotations

import random

from game.card import Card
from game.constants import DECK_MAX, DECK_MIN, JOKER_SUIT, STANDARD_DECK_SIZE, SUITS


def create_joker() -> Card:
  return Card(rank=0, suit=JOKER_SUIT, is_joker=True)


def create_standard_deck() -> list[Card]:
  deck: list[Card] = []
  for suit in SUITS:
    for rank in range(2, 15):
      deck.append(Card(rank=rank, suit=suit))
  return deck


def all_card_templates() -> list[Card]:
  return create_standard_deck()


def build_play_deck(trump_count: int = STANDARD_DECK_SIZE, include_joker: bool = True) -> list[Card]:
  """트럼프 매수(조커 제외)를 조절해 덱 구성. 전체는 DECK_MIN~DECK_MAX."""
  trump_count = max(1, min(STANDARD_DECK_SIZE, trump_count))
  base = create_standard_deck()
  random.shuffle(base)
  deck = base[:trump_count]
  if include_joker:
    deck.append(create_joker())
  return deck


class DeckManager:
  def __init__(self) -> None:
    self.trump_count: int = STANDARD_DECK_SIZE
    self.include_joker: bool = True
    self.run_deck: list[Card] = []
    self.discard: list[Card] = []
    self.banned: list[Card] = []
    self.reset_for_enemy()

  def reset_for_enemy(self) -> None:
    """게임 시작 — 런 덱을 새로 구성하고 가득 채움."""
    self.run_deck = build_play_deck(self.trump_count, self.include_joker)
    self._load_from_run_deck()

  def _load_from_run_deck(self) -> None:
    """런 덱(영구 구성)에서 작업 덱을 복사해 채우고 묘지·밴을 비움."""
    self.deck = [c.copy() for c in self.run_deck]
    self.discard = []
    self.banned = []
    self.shuffle()

  def start_new_stage(self) -> None:
    """스테이지 시작마다 — 덱·묘지·밴 초기화 후 런 덱에서 덱을 가득 채움."""
    self._load_from_run_deck()

  def commit_run_deck(self) -> None:
    """우물·턱의 영구 편집 결과(현재 덱+묘지 구성)를 런 덱에 반영."""
    self.run_deck = [c.copy() for c in (self.deck + self.discard)]

  def prepare_for_combat(self) -> None:
    """스테이지 시작 — 런 덱에서 덱을 다시 채운다."""
    self.start_new_stage()

  def prepare_for_well_edit(self) -> None:
    """특수 스테이지(우물·턱) 진입 — 런 덱 전체를 편집 대상으로 채움."""
    self.start_new_stage()

  def permanently_remove_top(self, count: int) -> list[Card]:
    """우물에서 덱 위 카드를 영구 제거 (묘지로 보내지 않음)"""
    removed: list[Card] = []
    for _ in range(count):
      if not self.deck:
        break
      removed.append(self.deck.pop())
    return removed

  def permanently_remove_at(self, index: int) -> Card | None:
    """우물에서 지정 인덱스 카드를 영구 제거."""
    if index < 0 or index >= len(self.deck):
      return None
    return self.deck.pop(index)

  def random_trump_offers(self, count: int) -> list[Card]:
    """덱에 없는 트럼프 후보 중 무작위 count장 (우물 뽑기용)."""
    templates = create_standard_deck()
    existing = {c.card_key() for c in self.deck}
    pool = [t.copy() for t in templates if t.card_key() not in existing]
    if len(pool) < count:
      pool = [t.copy() for t in templates]
    if not pool:
      return []
    return random.sample(pool, min(count, len(pool)))

  def reset(self) -> None:
    self.reset_for_enemy()

  def shuffle(self) -> None:
    random.shuffle(self.deck)

  def is_exhausted(self) -> bool:
    return not self.deck and not self.discard

  def draw(self) -> Card | None:
    if not self.deck:
      if self.discard:
        self.deck = self.discard[:]
        self.discard.clear()
        self.shuffle()
      else:
        self.replenish_from_banned()
    if not self.deck:
      return None
    return self.deck.pop()

  def replenish_from_banned(self) -> bool:
    """덱·묘지가 모두 비면 밴 카드를 덱으로 되돌려 보충."""
    if self.banned:
      self.deck = self.banned[:]
      self.banned.clear()
      self.shuffle()
      return True
    return False

  def draw_many(self, count: int) -> list[Card]:
    return [c for _ in range(count) if (c := self.draw()) is not None]

  def peek_many(self, count: int) -> list[Card]:
    n = min(count, len(self.deck))
    if n == 0:
      return []
    return [c.copy() for c in self.deck[-n:]]

  def swap_deck_and_discard(self) -> None:
    self.deck, self.discard = self.discard, self.deck
    self.shuffle()

  def total_in_deck_discard(self) -> int:
    return len(self.deck) + len(self.discard)

  def can_add_cards(self, count: int = 1) -> bool:
    return self.total_in_deck_discard() + count <= DECK_MAX

  def can_remove_cards(self, count: int = 1, *, min_deck: int | None = None) -> bool:
    floor = DECK_MIN if min_deck is None else min_deck
    return self.total_in_deck_discard() - count >= floor

  def discard_from_deck_top(self, count: int) -> list[Card]:
    removed: list[Card] = []
    for _ in range(count):
      if not self.deck:
        break
      removed.append(self.deck.pop())
    if removed:
      self.discard_cards(removed)
    return removed

  def gain_from_discard(self, count: int) -> list[Card]:
    gained: list[Card] = []
    for _ in range(count):
      if not self.discard:
        break
      card = self.discard.pop()
      self.deck.append(card)
      gained.append(card)
    if gained:
      self.shuffle()
    return gained

  def add_random_trump(self) -> Card | None:
    if not self.can_add_cards(1):
      return None
    templates = create_standard_deck()
    existing = {c.card_key() for c in self.deck + self.discard}
    pool = [t for t in templates if t.card_key() not in existing]
    if not pool:
      pool = templates
    card = random.choice(pool).copy()
    self.deck.append(card)
    return card

  def joker_transform_pool(self) -> list[Card]:
    """조커 변형 선택 — 표준 52장 전체."""
    return [c.copy() for c in all_card_templates()]

  def ban_cards(self, cards: list[Card]) -> None:
    for card in cards:
      self.banned.append(card)
      self._remove_from_deck(card)
      self._remove_from_discard(card)

  def discard_cards(self, cards: list[Card]) -> None:
    self.discard.extend(cards)

  def remove_from_discard(self, card: Card) -> bool:
    for i, c in enumerate(self.discard):
      if c.rank == card.rank and c.suit == card.suit:
        self.discard.pop(i)
        return True
    return False

  def _remove_from_discard(self, card: Card) -> None:
    self.remove_from_discard(card)

  def _remove_from_deck(self, card: Card) -> None:
    if card.is_joker_card:
      for i, c in enumerate(self.deck):
        if c.is_joker_card:
          self.deck.pop(i)
          return
      return
    for i, c in enumerate(self.deck):
      if c.rank == card.rank and c.suit == card.suit:
        self.deck.pop(i)
        return

  def cards_remaining(self) -> int:
    return len(self.deck) + len(self.discard)
