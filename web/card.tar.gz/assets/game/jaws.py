"""턱(이빨 자국) 정의 — 등급별 카탈로그."""

from __future__ import annotations

import random
from dataclasses import dataclass
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
  from game.state import GameState


class JawTier(str, Enum):
  NOBILITY = "nobility"
  HERO_VILLAIN = "hero_villain"
  WANDERER_ARTIST = "wanderer_artist"
  SAINT_DEVIL = "saint_devil"


JAW_TIER_LABELS: dict[JawTier, str] = {
  JawTier.NOBILITY: "귀족의 유해",
  JawTier.HERO_VILLAIN: "영웅과 역적의 유해",
  JawTier.WANDERER_ARTIST: "낭인과 예술가의 유해",
  JawTier.SAINT_DEVIL: "성인과 악마의 유해",
}

JAW_TIER_HINTS: dict[JawTier, str] = {
  JawTier.NOBILITY: "칩 보정",
  JawTier.HERO_VILLAIN: "족보 배수 보정",
  JawTier.WANDERER_ARTIST: "드로우 시 유틸리티",
  JawTier.SAINT_DEVIL: "런을 뒤흔드는 특수 효과",
}

RED_SUITS = frozenset({"hearts", "diamonds"})
BLACK_SUITS = frozenset({"clubs", "spades"})
PAINT_JAW_ID = "wanderer_paint"
BELIAL_JAW_ID = "devil_belial"
ABADDON_JAW_ID = "devil_abaddon"
BELIAL_MARKS_REQUIRED = 6
DEVIL_TAROT_NUMBER = 15

FLUSH_HANDS = frozenset({
  "flush", "flush_plus", "straight_flush", "rainbow", "spectrum", "royal_flush",
})
PAIR_TRIPLE_HANDS = frozenset({
  "pair", "two_pair", "three_kind", "full_house",
  "three_pair", "four_pair", "double_triple", "octa_triple", "quad_double", "four_kind",
})
STRAIGHT_HANDS = frozenset({
  "straight", "straight_plus", "straight_flush", "dragon", "leviathan", "royal_flush",
})
STRAIGHT_BONUS_PCT: dict[str, float] = {
  "straight": 0.15,
  "straight_plus": 0.20,
  "straight_flush": 0.25,
  "dragon": 0.30,
  "leviathan": 0.35,
  "royal_flush": 0.30,
}


@dataclass(frozen=True)
class JawDefinition:
  id: str
  name: str
  tier: JawTier
  effect_summary: str


JAW_DEFINITIONS: dict[str, JawDefinition] = {
  # 귀족 — 칩
  "noble_lion": JawDefinition(
    "noble_lion", "사자머리의 가문", JawTier.NOBILITY,
    "J·Q·K 카드 칩 ×1.2",
  ),
  "noble_gold": JawDefinition(
    "noble_gold", "금의 가문", JawTier.NOBILITY,
    "6~10 카드 칩 +5",
  ),
  "noble_feather": JawDefinition(
    "noble_feather", "깃털의 가문", JawTier.NOBILITY,
    "A~5 카드 칩 ×1.5",
  ),
  "noble_red_thread": JawDefinition(
    "noble_red_thread", "붉은 실의 가문", JawTier.NOBILITY,
    "붉은 문양 카드당 칩 +3",
  ),
  "noble_octopus": JawDefinition(
    "noble_octopus", "문어의 가문", JawTier.NOBILITY,
    "검은 문양 카드당 칩 +3",
  ),
  # 영웅·역적 — 배수
  "hero_spear": JawDefinition(
    "hero_spear", "창에 꿰뚤린 영웅", JawTier.HERO_VILLAIN,
    "짝수 카드 5장 이상 시 배수 ×1.5",
  ),
  "hero_arrow": JawDefinition(
    "hero_arrow", "화살이 박힌 영웅", JawTier.HERO_VILLAIN,
    "홀수 카드 5장 이상 시 배수 ×1.5",
  ),
  "hero_crushed": JawDefinition(
    "hero_crushed", "머리가 짓눌린 영웅", JawTier.HERO_VILLAIN,
    "동전 앞면 시 배수 ×1.3",
  ),
  "villain_eyes": JawDefinition(
    "villain_eyes", "눈과 혀가 뽑힌 역적", JawTier.HERO_VILLAIN,
    "플러시 계열 배수 ×1.4",
  ),
  "villain_limbs": JawDefinition(
    "villain_limbs", "사지가 잘린 역적", JawTier.HERO_VILLAIN,
    "페어·트리플 계열 배수 ×1.7",
  ),
  "villain_charred": JawDefinition(
    "villain_charred", "검게 탄 역적", JawTier.HERO_VILLAIN,
    "묘지 8장 이상 시 배수 ×1.5",
  ),
  # 낭인·예술가 — 드로우 유틸
  "wanderer_paint": JawDefinition(
    "wanderer_paint", "물감 묻은 유해", JawTier.WANDERER_ARTIST,
    "빨간 문양 취급 · 플러시 보조",
  ),
  "wanderer_sword": JawDefinition(
    "wanderer_sword", "검을 쥔 유해", JawTier.WANDERER_ARTIST,
    "스트레이트 계열 시 최대 HP 추가 피해",
  ),
  "wanderer_fang": JawDefinition(
    "wanderer_fang", "앞니가 밀린 유해", JawTier.WANDERER_ARTIST,
    "드로우 시 1~3장 리롤 후 묘지",
  ),
  "wanderer_lead": JawDefinition(
    "wanderer_lead", "납이 묻은 유해", JawTier.WANDERER_ARTIST,
    "드로우 시 묘지 이동 · 최대 HP 5% 피해",
  ),
  "wanderer_spine": JawDefinition(
    "wanderer_spine", "등뼈가 휜 유해", JawTier.WANDERER_ARTIST,
    "드로우 시 밴 카드로 이동",
  ),
  # 성인·악마
  "saint_michael": JawDefinition(
    "saint_michael", "미카엘", JawTier.SAINT_DEVIL,
    "타로 1슬롯 영구 봉인 · 드로우 시 처형",
  ),
  "saint_raphael": JawDefinition(
    "saint_raphael", "라파엘", JawTier.SAINT_DEVIL,
    "드로우 시 타로 사용 횟수 전부 초기화",
  ),
  "devil_belial": JawDefinition(
    "devil_belial", "벨리알", JawTier.SAINT_DEVIL,
    "자국 6개 이상 시 합산에 6자국 바쳐 전 카드에 랜덤 자국",
  ),
  "devil_abaddon": JawDefinition(
    "devil_abaddon", "아바돈", JawTier.SAINT_DEVIL,
    "악마 타로 보유 시 드로우마다 묘지 칩 합산",
  ),
}

JAW_STAGE_OFFER_COUNT = 3
JAW_STAGE_CARD_POOL = 7

# 턱 제안 시 등급별 가중치 — 성인·악마는 희귀하게
JAW_TIER_WEIGHTS: dict[JawTier, float] = {
  JawTier.NOBILITY: 4.0,
  JawTier.HERO_VILLAIN: 4.0,
  JawTier.WANDERER_ARTIST: 4.0,
  JawTier.SAINT_DEVIL: 1.0,
}


def get_jaw(jaw_id: str) -> JawDefinition:
  return JAW_DEFINITIONS.get(
    jaw_id,
    JawDefinition(jaw_id, jaw_id, JawTier.WANDERER_ARTIST, "(알 수 없는 턱)"),
  )


def effective_suits_for_flush(card) -> set[str]:
  """플러시 판정용 문양 — 물감 유해는 빨간 문양."""
  if card.jaw_id == PAINT_JAW_ID:
    return set(RED_SUITS)
  if card.joker_unresolved:
    return set()
  return {card.suit}


def count_run_jaw_marks(state: GameState) -> int:
  n = 0
  for c in state.deck.deck:
    if c.jaw_id:
      n += 1
  for c in state.deck.discard:
    if c.jaw_id:
      n += 1
  for c in state.deck.banned:
    if c.jaw_id:
      n += 1
  for c in state.hand:
    if c and c.jaw_id:
      n += 1
  return n


def has_devil_tarot(state: GameState) -> bool:
  return any(t.number == DEVIL_TAROT_NUMBER for t in state.tarots)


def eligible_jaw_ids(state: GameState) -> list[str]:
  from game.artifact_runtime import has_artifact

  marks = count_run_jaw_marks(state)
  devil = has_devil_tarot(state)
  block_saint_devil = has_artifact(state.artifact_stacks, "hallasan_kangjihu")
  ids: list[str] = []
  for jid in JAW_DEFINITIONS:
    if jid == BELIAL_JAW_ID and marks < BELIAL_MARKS_REQUIRED:
      continue
    if jid == ABADDON_JAW_ID and not devil:
      continue
    if block_saint_devil and JAW_DEFINITIONS[jid].tier == JawTier.SAINT_DEVIL:
      continue
    ids.append(jid)
  return ids


def random_jaw_offers(state: GameState, count: int = JAW_STAGE_OFFER_COUNT) -> list[str]:
  """등급 가중치로 제안 — 성인·악마는 낮은 확률, 인피 성경 시 대폭 상승."""
  from game.artifact_runtime import has_artifact

  pool = eligible_jaw_ids(state)
  if not pool:
    return list(JAW_DEFINITIONS.keys())[:count]

  tier_weights = dict(JAW_TIER_WEIGHTS)
  if has_artifact(state.artifact_stacks, "infi_bible"):
    tier_weights[JawTier.SAINT_DEVIL] = 8.0

  buckets: dict[JawTier, list[str]] = {}
  for jid in pool:
    buckets.setdefault(JAW_DEFINITIONS[jid].tier, []).append(jid)
  for ids in buckets.values():
    random.shuffle(ids)

  offers: list[str] = []
  for _ in range(min(count, len(pool))):
    available = [t for t, ids in buckets.items() if ids]
    if not available:
      break
    weights = [tier_weights.get(t, 1.0) for t in available]
    tier = random.choices(available, weights=weights, k=1)[0]
    offers.append(buckets[tier].pop())
  return offers


def jaws_by_tier(tier: JawTier) -> list[JawDefinition]:
  return [j for j in JAW_DEFINITIONS.values() if j.tier == tier]
