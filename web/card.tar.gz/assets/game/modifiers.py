from __future__ import annotations

from dataclasses import dataclass, field

from game.card import Card


@dataclass
class PlayModifiers:
  mult_multiplier: float = 1.0
  mult_bonus: int = 0
  chip_multiplier: float = 1.0
  chip_bonus: int = 0
  min_hand: str | None = None
  emperor_index: int | None = None
  emperor_mult: float = 4.0
  lovers_index: int | None = None
  lovers_mult: float = 1.5
  chariot_index: int | None = None
  chariot_mult: float = 2.25
  chariot_odd_mult: float = 0.65
  star_index: int | None = None
  star_per_suit: float = 1.25
  devil_roll: int | None = None
  devil_dice_sides: int = 6
  devil_zero_turn: bool = False
  hermit_chip_mult: float = 1.0
  applied_tarots: list[int] = field(default_factory=list)

  def reset(self) -> None:
    self.mult_multiplier = 1.0
    self.mult_bonus = 0
    self.chip_multiplier = 1.0
    self.chip_bonus = 0
    self.min_hand = None
    self.emperor_index = None
    self.emperor_mult = 4.0
    self.lovers_index = None
    self.lovers_mult = 1.5
    self.chariot_index = None
    self.chariot_mult = 2.25
    self.chariot_odd_mult = 0.65
    self.star_index = None
    self.star_per_suit = 1.25
    self.devil_roll = None
    self.devil_dice_sides = 6
    self.devil_zero_turn = False
    self.hermit_chip_mult = 1.0
    self.applied_tarots.clear()
