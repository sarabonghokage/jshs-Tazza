"""점수 합산 연출용 단계별 breakdown 생성."""

from __future__ import annotations

from dataclasses import dataclass

from game.alchemy import AggregatedAlchemyBonuses
from game.artifact_effects import (
  ArtifactRuntimeContext,
  apply_artifact_bonus_damage,
  apply_artifact_score,
  card_chip_with_artifacts,
  card_visual_mods,
  pale_note_active,
  whale_ribs_active,
)
from game.artifact_runtime import has_artifact
from game.card import Card
from game.constants import HAND_LABELS_KO, HAND_MULTIPLIERS
from game.jaw_effects import (
  JawScoreContext,
  active_jaw_ids,
  apply_jaw_mult_modifiers,
  decompose_jaw_chip_bonuses,
  jaw_straight_bonus_damage,
)
from game.modifiers import PlayModifiers
from game.poker import evaluate_hand_detailed, hand_at_least
from game.score import (
  _alchemy_card_chip_bonus,
  _alchemy_hand_mult_bonus,
  _chariot_mult,
  _lovers_mult,
  _safe_chip_factor,
  apply_devil_effect,
  describe_devil_roll,
)


@dataclass
class ScoreRevealStep:
  kind: str
  text: str
  slot: int | None = None
  chip_value: int = 0
  chips: int = 0
  mult: int = 1
  total: int = 0
  highlight_slots: tuple[int, ...] = ()
  artifact_id: str | None = None


def build_score_reveal_steps(
  hand: list[Card | None],
  modifiers: PlayModifiers | None = None,
  hand_bonuses: dict[str, int] | None = None,
  jaw_ctx: JawScoreContext | None = None,
  alchemy: AggregatedAlchemyBonuses | None = None,
  artifacts: ArtifactRuntimeContext | None = None,
) -> tuple[dict, list[ScoreRevealStep]]:
  mods = modifiers or PlayModifiers()
  bonuses = dict(hand_bonuses or {})
  alch = alchemy or AggregatedAlchemyBonuses()
  ctx = jaw_ctx or JawScoreContext()
  steps: list[ScoreRevealStep] = []

  if alch.hand_mult_all:
    for hand_name in HAND_MULTIPLIERS:
      bonuses[hand_name] = bonuses.get(hand_name, 0) + alch.hand_mult_all

  emperor_compact_idx: int | None = None
  if (
    mods.emperor_index is not None
    and 0 <= mods.emperor_index < len(hand)
    and hand[mods.emperor_index] is not None
  ):
    emperor_compact_idx = sum(1 for c in hand[: mods.emperor_index] if c is not None)

  cards = [c for c in hand if c is not None]
  compact_to_slot: list[int] = [i for i, c in enumerate(hand) if c is not None]

  hand_name, base_mult, best_indices = evaluate_hand_detailed(
    cards,
    pale_note=pale_note_active((artifacts or ArtifactRuntimeContext()).artifact_stacks or {}),
  )
  if mods.min_hand:
    hand_name = hand_at_least(hand_name, mods.min_hand)

  best_slots = tuple(compact_to_slot[i] for i in best_indices if i < len(compact_to_slot))

  art_ctx = artifacts or ArtifactRuntimeContext()
  stacks = art_ctx.artifact_stacks or {}
  art = apply_artifact_score(
    hand,
    hand_name,
    artifact_stacks=stacks,
    discard_count=art_ctx.discard_count,
    enemy_max_hp=art_ctx.enemy_max_hp,
    turns_remaining=art_ctx.turns_remaining,
    tarot_used_count=art_ctx.tarot_used_count,
    essence_total=art_ctx.essence_total,
    resting_mult_bonus=art_ctx.resting_mult_bonus,
    kingslayer_active=art_ctx.kingslayer_active,
  )
  kingslayer = art.kingslayer_mode
  if art.force_hand_name:
    hand_name = art.force_hand_name

  jaw_ids = active_jaw_ids(hand)
  chips = 0
  for slot, card in enumerate(hand):
    if card is None:
      continue
    art_base = card_chip_with_artifacts(card, stacks)
    chips += art_base
    label = f"{card.label}{card.suit[0].upper()}"
    chip_aid = None
    if has_artifact(stacks, "silver_feather") and card.rank >= 11:
      chip_aid = "silver_feather"
    elif has_artifact(stacks, "pale_note"):
      mod = card_visual_mods(card, stacks)
      if mod and mod.new_rank_label:
        chip_aid = "pale_note"
    steps.append(ScoreRevealStep(
      kind="card_chip",
      text=f"{label}  +{art_base}",
      slot=slot,
      chip_value=art_base,
      chips=chips,
      artifact_id=chip_aid,
    ))

  # 턱 칩 효과 — 카드 기본 칩 합산 후, 보너스마다 +N씩 개별 연출
  for evt in decompose_jaw_chip_bonuses(hand, jaw_ids):
    chips += evt.amount
    hl = (evt.target_slot,) + evt.source_slots
    steps.append(ScoreRevealStep(
      kind="jaw_chip",
      text=f"{evt.jaw_name}  {evt.card_label}  +{evt.amount}",
      slot=evt.target_slot,
      chip_value=evt.amount,
      chips=chips,
      highlight_slots=tuple(dict.fromkeys(hl)),
    ))

  if mods.chip_bonus:
    chips += mods.chip_bonus
    steps.append(ScoreRevealStep(
      kind="chip_bonus",
      text=f"타로 칩 보너스  +{mods.chip_bonus}",
      chips=chips,
    ))

  if alch.chip_flat:
    chips += alch.chip_flat
    steps.append(ScoreRevealStep(
      kind="chip_bonus",
      text=f"연금술 칩  +{alch.chip_flat}",
      chips=chips,
    ))

  alch_card_chip = _alchemy_card_chip_bonus(cards, alch)
  if alch_card_chip:
    chips += alch_card_chip
    steps.append(ScoreRevealStep(
      kind="chip_bonus",
      text=f"연금술 카드 칩  +{alch_card_chip}",
      chips=chips,
    ))

  if mods.lovers_index is not None:
    before = chips
    mult_lovers = _lovers_mult(hand, mods.lovers_index, mods.lovers_mult)
    if mult_lovers != 1.0:
      chips = int(chips * mult_lovers)
      steps.append(ScoreRevealStep(
        kind="chip_mult",
        text=f"연인 효과  ×{mult_lovers:.1f}  ({before}→{chips})",
        chips=chips,
      ))

  if mods.chariot_index is not None:
    before = chips
    mult_chariot = _chariot_mult(before, mods.chariot_mult, mods.chariot_odd_mult)
    mult_chariot = _safe_chip_factor(mult_chariot, whale=whale_ribs_active(stacks))
    if mult_chariot != 1.0:
      chips = int(chips * mult_chariot)
      steps.append(ScoreRevealStep(
        kind="chip_mult",
        text=f"전차 효과  ×{mult_chariot:.2f}  ({before}→{chips})",
        chips=chips,
      ))

  whale = whale_ribs_active(stacks)
  chip_mult_factor = (
    _safe_chip_factor(mods.chip_multiplier, whale=whale)
    * _safe_chip_factor(mods.hermit_chip_mult, whale=whale)
    * _safe_chip_factor(1.0 + alch.chip_mult, whale=whale)
  )
  if chip_mult_factor != 1.0:
    before = chips
    chips = int(chips * chip_mult_factor)
    parts = []
    if mods.chip_multiplier != 1.0:
      parts.append(f"칩×{mods.chip_multiplier}")
    if mods.hermit_chip_mult != 1.0:
      parts.append(f"은둔자×{mods.hermit_chip_mult}")
    if alch.chip_mult:
      parts.append(f"연금×{1.0 + alch.chip_mult:.2f}")
    steps.append(ScoreRevealStep(
      kind="chip_mult",
      text=f"{' · '.join(parts)}  ({before}→{chips})",
      chips=chips,
    ))

  if kingslayer:
    mult = 1
    hand_label = "왕을 죽이는 검"
    steps.append(ScoreRevealStep(
      kind="hand",
      text=f"왕을 죽이는 검 — 족보·배수 무효 · 칩 1당 최대HP {art.kingslayer_pct * 100:.1f}%",
      chips=chips,
      mult=mult,
      highlight_slots=best_slots,
    ))
  else:
    bonus_mult = bonuses.get(hand_name, 0)
    alch_hand_mult = _alchemy_hand_mult_bonus(hand_name, alch)
    mult = HAND_MULTIPLIERS[hand_name] + bonus_mult + mods.mult_bonus + alch.mult_flat + alch_hand_mult
    hand_label = HAND_LABELS_KO[hand_name]
    mult_parts = [f"기본 {HAND_MULTIPLIERS[hand_name]}x"]
    if bonus_mult:
      mult_parts.append(f"강화 +{bonus_mult}")
    if mods.mult_bonus:
      mult_parts.append(f"타로 +{mods.mult_bonus}")
    if alch.mult_flat:
      mult_parts.append(f"연금 +{alch.mult_flat}")
    if alch_hand_mult:
      mult_parts.append(f"연금 계열 +{alch_hand_mult}")
    steps.append(ScoreRevealStep(
      kind="hand",
      text=f"족보: {hand_label}  ({' · '.join(mult_parts)})",
      chips=chips,
      mult=mult,
      highlight_slots=best_slots,
    ))

    if emperor_compact_idx is not None and emperor_compact_idx in best_indices:
      before = mult
      mult = int(mult * mods.emperor_mult)
      steps.append(ScoreRevealStep(
        kind="mult",
        text=f"황제 효과  ×{mods.emperor_mult:.0f}  ({before}→{mult})",
        chips=chips,
        mult=mult,
        highlight_slots=best_slots,
      ))

    if mods.star_index is not None:
      anchor = hand[mods.star_index]
      if anchor:
        same = sum(1 for c in cards if c.suit == anchor.suit)
        before = mult
        mult = int(mult * (mods.star_per_suit ** same))
        steps.append(ScoreRevealStep(
          kind="mult",
          text=f"별 효과 (동문양 {same}장)  ×{mods.star_per_suit:.1f}^{same}  ({before}→{mult})",
          chips=chips,
          mult=mult,
          highlight_slots=best_slots,
        ))

    if mods.mult_multiplier != 1.0:
      before = mult
      mult = int(mult * mods.mult_multiplier)
      steps.append(ScoreRevealStep(
        kind="mult",
        text=f"배수 보정  ×{mods.mult_multiplier}  ({before}→{mult})",
        chips=chips,
        mult=mult,
        highlight_slots=best_slots,
      ))

    jaw_before = mult
    mult = apply_jaw_mult_modifiers(hand, hand_name, ctx, mult)
    if mult != jaw_before:
      steps.append(ScoreRevealStep(
        kind="mult",
        text=f"턱 효과 (배수)  ×배수 {jaw_before}→{mult}",
        chips=chips,
        mult=mult,
        highlight_slots=tuple(
          i for i, c in enumerate(hand) if c is not None and c.jaw_id in jaw_ids
        ),
      ))

  if art.chip_add:
    chips += art.chip_add
    for line in art.lines:
      if "배수" not in line:
        steps.append(ScoreRevealStep(
          kind="chip_bonus", text=line, chips=chips,
          artifact_id=art.line_sources.get(line),
        ))
  if art.chip_mult != 1.0:
    before = chips
    factor = _safe_chip_factor(art.chip_mult, whale=whale)
    chips = int(chips * factor)
    for line in art.lines:
      if "칩 ×" in line:
        steps.append(ScoreRevealStep(
          kind="chip_mult", text=f"{line}  ({before}→{chips})", chips=chips,
          artifact_id=art.line_sources.get(line),
        ))
  if not kingslayer and (art.mult_add or art.mult_mult != 1.0):
    before = mult
    mult = int((mult + art.mult_add) * art.mult_mult)
    for line in art.lines:
      if "배수" in line and "칩" not in line:
        steps.append(ScoreRevealStep(
          kind="mult", text=f"{line}  ({before}→{mult})", chips=chips, mult=mult,
          highlight_slots=best_slots,
          artifact_id=art.line_sources.get(line),
        ))

  if art_ctx.kyungcheon_chip:
    chips += art_ctx.kyungcheon_chip
    steps.append(ScoreRevealStep(
      kind="chip_bonus",
      text=f"경천 누적  칩 +{art_ctx.kyungcheon_chip}",
      chips=chips,
      artifact_id="kyungcheon",
    ))
  if art_ctx.kyungcheon_mult and not kingslayer:
    before = mult
    mult += art_ctx.kyungcheon_mult
    steps.append(ScoreRevealStep(
      kind="mult",
      text=f"경천 누적  배수 +{art_ctx.kyungcheon_mult}  ({before}→{mult})",
      chips=chips,
      mult=mult,
      highlight_slots=best_slots,
      artifact_id="kyungcheon",
    ))

  if mods.devil_zero_turn and not whale:
    chips = 0
    if not kingslayer:
      mult = 0
    steps.append(ScoreRevealStep(
      kind="devil",
      text="악마 — 이번 턴 점수 0!",
      chips=chips,
      mult=mult,
      highlight_slots=best_slots,
    ))
  elif mods.devil_roll is not None:
    before_chips, before_mult = chips, mult
    new_chips, new_mult = apply_devil_effect(
      mods.devil_roll, mods.devil_dice_sides, chips, mult, whale_ribs=whale,
    )
    chips = new_chips
    if not kingslayer:
      mult = new_mult
    detail = describe_devil_roll(mods.devil_roll, mods.devil_dice_sides)
    if chips != before_chips or mult != before_mult:
      steps.append(ScoreRevealStep(
        kind="devil",
        text=f"{detail}  (칩 {before_chips}→{chips}, 배수 {before_mult}→{mult})",
        chips=chips,
        mult=mult,
        highlight_slots=best_slots,
      ))
    else:
      steps.append(ScoreRevealStep(
        kind="devil",
        text=detail,
        chips=chips,
        mult=mult,
        highlight_slots=best_slots,
      ))

  if has_artifact(stacks, "locust_necklace"):
    effect_count = len([s for s in steps if s.kind not in ("card_chip",)])
    bonus = effect_count * 25
    if bonus:
      chips += bonus
      steps.append(ScoreRevealStep(
        kind="chip_bonus",
        text=f"메뚜기 목걸이  효과 {effect_count}개  +{bonus}",
        chips=chips,
        mult=mult,
        highlight_slots=best_slots,
        artifact_id="locust_necklace",
      ))

  if kingslayer:
    total = int(art_ctx.enemy_max_hp * chips * art.kingslayer_pct)
    pct_total = chips * art.kingslayer_pct * 100
    steps.append(ScoreRevealStep(
      kind="total",
      text=f"칩 {chips} → 최대HP {pct_total:.1f}% = {total}",
      chips=chips,
      mult=mult,
      total=total,
      highlight_slots=best_slots,
    ))
  else:
    total = mult * chips
    steps.append(ScoreRevealStep(
      kind="total",
      text=f"{mult} × {chips} = {total}",
      chips=chips,
      mult=mult,
      total=total,
      highlight_slots=best_slots,
    ))

  bonus_damage = 0
  if not kingslayer:
    bonus_damage = jaw_straight_bonus_damage(hand, hand_name, ctx.enemy_max_hp)
    bonus_damage += art.bonus_damage
    if alch.damage_pct > 0 and total > 0:
      bonus_damage += int(total * alch.damage_pct)
    sb, _, _ = apply_artifact_bonus_damage(total, artifact_stacks=stacks)
    bonus_damage += sb
  if bonus_damage:
    steps.append(ScoreRevealStep(
      kind="bonus",
      text=f"추가 피해  +{bonus_damage}",
      chips=chips,
      mult=mult,
      total=total + bonus_damage,
      highlight_slots=best_slots,
    ))

  result = {
    "hand_name": hand_name,
    "hand_label": hand_label,
    "multiplier": mult,
    "chip_sum": chips,
    "total": total,
    "bonus_damage": bonus_damage,
    "devil_roll": mods.devil_roll,
    "best_indices": best_indices,
    "jaw_crushed_heads": ctx.crushed_heads,
  }
  return result, steps


def build_kingslayer_finale_steps(
  chip_sum: int,
  enemy_max_hp: int,
  pct: float = 0.0,
) -> list[ScoreRevealStep]:
  """일반 합산 연출 후 재생되는 왕을 죽이는 검 피날레."""
  from game.artifact_effects import KINGSLAYER_CHIP_PCT
  if pct <= 0:
    pct = KINGSLAYER_CHIP_PCT
  total = int(enemy_max_hp * chip_sum * pct)
  hp_pct = chip_sum * pct * 100
  return [
    ScoreRevealStep(
      kind="kingslayer_crack",
      text="검신이 스며든다...",
      chips=chip_sum,
      mult=1,
    ),
    ScoreRevealStep(
      kind="kingslayer",
      text=f"왕을 죽이는 검  칩 {chip_sum} → 최대HP {hp_pct:.1f}%",
      chips=chip_sum,
      mult=1,
      total=total,
    ),
    ScoreRevealStep(
      kind="total",
      text=f"검격 피해 {total:,}",
      chips=chip_sum,
      mult=1,
      total=total,
    ),
  ]
