"""조커(마법사/바보/세계) — 덱 내 특수 카드 로직."""

from __future__ import annotations

import random

from game.card import Card


def roll_joker_on_draw() -> int:
  """드로우 시 조커 면 — 0 바보, 1 마법사, 21 세계."""
  r = random.random()
  if r < 0.25:
    return 0
  if r < 0.50:
    return 21
  return 1


def transform_joker(joker: Card, template: Card) -> Card:
  return Card(
    rank=template.rank,
    suit=template.suit,
    tarot_number=joker.tarot_number,
    bonus_value=joker.bonus_value,
    is_joker=True,
    jaw_id=joker.jaw_id,
  )


def joker_needs_transform(card: Card) -> bool:
  return card.joker_unresolved
