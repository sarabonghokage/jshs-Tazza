from __future__ import annotations

from game.constants import PRIESTESS_PEEK_COUNT
from game.score import describe_devil_roll, roll_devil_dice


def apply_tarot_enhance(state, hand_index: int) -> str:
  from game.state import SubPhase

  tarot = state.pending_tarot
  if not tarot:
    return "타로가 선택되지 않았습니다."
  card = state.hand[hand_index]
  if not card or not tarot.can_enhance(card):
    return "대응되지 않는 카드입니다."

  n = tarot.number
  lv = tarot.upgrade_level
  state.modifiers.applied_tarots.append(n)
  marked = card.copy()
  marked.tarot_number = n
  state.hand[hand_index] = marked

  if n == 2:
    state.priestess_passes_remaining = 2 if lv >= 1 else 1
    return _begin_priestess_pick(state)
  if n == 3:
    return _empress(state)
  if n == 4:
    state.modifiers.emperor_index = hand_index
    em = 4.0 + lv
    state.modifiers.emperor_mult = em
    return f"{tarot.name}: 해당 카드가 족보에 포함되면 배수 ×{em:.0f}"
  if n == 5:
    state.modifiers.min_hand = "two_pair" if lv == 0 else ("three_kind" if lv == 1 else "straight")
    floor = {"two_pair": "투페어", "three_kind": "트리플", "straight": "스트레이트"}[state.modifiers.min_hand]
    return f"{tarot.name}: 족보를 {floor} 미만이면 {floor}로 상향"
  if n == 6:
    state.modifiers.lovers_index = hand_index
    lm = 1.5 + 0.3 * lv
    state.modifiers.lovers_mult = lm
    return f"{tarot.name}: 양옆이 같은 문양이면 칩 ×{lm:.1f}"
  if n == 7:
    state.modifiers.chariot_index = hand_index
    cm = 2.25 + 0.4 * lv
    state.modifiers.chariot_mult = cm
    state.modifiers.chariot_odd_mult = 0.65 + 0.05 * lv
    return (
      f"{tarot.name}: 칩 합 짝수 ×{cm:.2f} / "
      f"홀수 ×{state.modifiers.chariot_odd_mult:.2f}"
    )
  if n == 8:
    state.strength_allow_suit = lv >= 1
    card = state.hand[hand_index]
    state.rank_change_target = hand_index
    state.strength_rank = max(2, card.rank)
    state.strength_suit = (
      card.suit if card.suit in ("hearts", "diamonds", "clubs", "spades") else "hearts"
    )
    state.sub_phase = SubPhase.RANK_PICK_VALUE
    if state.strength_allow_suit:
      return f"{tarot.name}: 화살표로 랭크·문양을 바꾼 뒤 확정하세요"
    return f"{tarot.name}: 화살표로 랭크를 바꾼 뒤 확정하세요 (문양 유지)"
  if n == 9:
    state.sub_phase = SubPhase.HERMIT_SUIT
    state.hermit_peek = []
    state.hermit_level = lv
    return "은둔자: 다음에 뽑을 카드의 문양을 예측해 선택하세요 (선택 후 공개)"
  if n == 10:
    state.sub_phase = SubPhase.WHEEL_REROLL
    state.wheel_index = hand_index
    state.wheel_rolls = 0
    return f"{tarot.name}: 리롤 버튼으로 카드 변경 (최대 5회)"
  if n == 11:
    state.justice_anchor_index = hand_index
    state.sub_phase = SubPhase.JUSTICE_PICK_SOURCE
    return f"{tarot.name}: 대칭 복제할 카드를 손패에서 선택하세요"
  if n == 12:
    return _hanged_man(state)
  if n == 13:
    return _death(state, hand_index)
  if n == 14:
    state.temperance_draws_remaining = 2 if lv >= 1 else 1
    state.temperance_rerolls = 2
    state.temperance_suit = None
    state.sub_phase = SubPhase.TEMPERANCE_SUIT
    draws = state.temperance_draws_remaining
    return f"{tarot.name}: 원하는 문양을 선택하세요 (다음 드로우 {draws}회 적용)"
  if n == 15:
    return _devil(state, lv)
  if n == 16:
    return _tower(state, hand_index)
  if n == 17:
    state.modifiers.star_index = hand_index
    sp = 1.25 + 0.12 * lv
    state.modifiers.star_per_suit = sp
    return f"{tarot.name}: 같은 문양 카드마다 배수 ×{sp:.2f}"
  if n == 18:
    return _moon(state)
  if n == 19:
    sun = 2.0 + 0.5 * lv
    state.modifiers.mult_multiplier *= sun
    return f"{tarot.name}: 정오의 가호 — 이번 합산 최종 배수 ×{sun:.1f}"
  if n == 20:
    if lv == 0:
      state.enemy.hp = max(1, state.enemy.hp * 2 // 3)
      return f"{tarot.name}: 적 HP → {state.enemy.hp} (2/3)"
    state.enemy.hp = max(1, state.enemy.hp // 2)
    return f"{tarot.name}: 적 HP → {state.enemy.hp} (1/2)"

  return f"{tarot.name} 강화 완료"


def _begin_priestess_pick(state) -> str:
  from game.state import SubPhase

  state.pick_pool = state.pull_many(PRIESTESS_PEEK_COUNT, allow_joker=False)
  if not state.pick_pool:
    state.priestess_passes_remaining = 0
    return "여사제: 덱에 카드가 없습니다."
  state.sub_phase = SubPhase.PRIESTESS_PICK
  left = state.priestess_passes_remaining
  round_txt = f" · {left}회 남음" if left > 1 else ""
  return f"여사제: 덱 위 {len(state.pick_pool)}장 중 1장 선택{round_txt}"


def _empress(state) -> str:
  tarot = state.pending_tarot
  lv = tarot.upgrade_level if tarot else 0
  from game.hand_size import empress_hand_target
  target = empress_hand_target(lv)
  state.hand_size_play_target = max(state.hand_size_play_target, target)
  state.sync_hand_slots()
  card = state.pull_card(allow_joker=False)
  if card:
    slot = state._first_empty_slot()
    if slot is not None:
      state.hand[slot] = card
  return f"여제: 손패 {state.max_hand_slots}장, 카드 1장 추가 드로우"


def _hanged_man(state) -> str:
  if state.hanged_man_cooldown > 0:
    return f"매달린 사람 쿨타임 {state.hanged_man_cooldown}턴"
  state.hanged_man_cooldown = 2
  state.restart_play_keep_progress()
  return "매달린 사람: 턴을 무효화하고 다시 시작 (쿨타임 2턴)"


def _death(state, index: int) -> str:
  from game.state import SubPhase

  anchor = state.hand[index]
  for i, c in enumerate(state.hand):
    if i != index and c:
      state.deck.discard_cards([c])
      state.hand[i] = None
  state.hand[index] = anchor
  state.sub_phase = SubPhase.DEATH_PICK_THREE
  state.pick_pool = [c for c in state.deck.discard if not c.is_joker_card]
  state.death_picks = []
  return "죽음: 묘지에서 3장을 선택하세요"


def _devil(state, lv: int) -> str:
  sides = 8 if lv >= 1 else 6
  roll = roll_devil_dice(sides)
  state.modifiers.devil_roll = roll
  state.modifiers.devil_dice_sides = sides
  if roll == 1:
    state.modifiers.devil_zero_turn = True
  return describe_devil_roll(roll, sides)


def _tower(state, keep_index: int) -> str:
  for i, c in enumerate(state.hand):
    if i == keep_index or not c:
      continue
    state.deck.discard_cards([c])
    new = state.pull_card(allow_joker=False)
    state.hand[i] = new
  return "탑: 대응 카드 외 전부 리롤"


def _moon(state) -> str:
  from game.state import SubPhase

  dumped = state.deck.discard_from_deck_top(3)
  state.moon_hand_picks = []
  state.sub_phase = SubPhase.MOON_PICK_HAND
  return f"달: 덱 위 {len(dumped)}장 묘지 전송 · 패에서 교환할 2장 선택"


def reroll_wheel_card(state) -> str:
  from game.state import SubPhase

  if state.sub_phase != SubPhase.WHEEL_REROLL or state.wheel_index is None:
    return ""
  if state.wheel_rolls >= 5:
    return "리롤 횟수를 모두 사용했습니다"
  old = state.hand[state.wheel_index]
  if old:
    state.deck.discard_cards([old])
  new = state.pull_card(allow_joker=False)
  state.hand[state.wheel_index] = new
  state.wheel_rolls += 1
  left = 5 - state.wheel_rolls
  return f"수레바퀴 리롤 ({left}회 남음)" if left else "수레바퀴 리롤 완료"


def finish_wheel(state) -> None:
  from game.state import SubPhase

  state.sub_phase = SubPhase.NONE
  state.wheel_index = None


def apply_hermit_suit(state, suit: str) -> str:
  from game.state import SubPhase
  from ui.suits import SUIT_LABELS_KO

  peeked = state.deck.peek_many(2)
  state.hermit_peek = peeked
  state.next_draw_preview = list(reversed(peeked))
  matched = any(c.suit == suit for c in peeked)
  hermit_mult = 1.4 + 0.2 * getattr(state, "hermit_level", 0)
  if matched:
    state.modifiers.hermit_chip_mult = hermit_mult
  state.sub_phase = SubPhase.NONE
  names = ", ".join(f"{c.label}{c.suit[0].upper()}" for c in state.next_draw_preview) or "-"
  picked = SUIT_LABELS_KO.get(suit, suit)
  return f"은둔자: {picked} 예측 → 공개 [{names}] · {'적중! 칩 ×%.1f' % hermit_mult if matched else '불일치'}"


def apply_temperance_suit(state, suit: str) -> str:
  from game.state import SubPhase
  from ui.suits import SUIT_LABELS_KO

  state.temperance_suit = suit
  state.sub_phase = SubPhase.NONE
  picked = SUIT_LABELS_KO.get(suit, suit)
  draws = state.temperance_draws_remaining
  return f"절제: {picked} 문양 지정 · 다음 드로우 {draws}회 동일 문양만 허용"
