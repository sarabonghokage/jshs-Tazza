from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional

from game.constants import JOKER_SUIT, RANK_LABELS, SUIT_SYMBOLS


@dataclass
class Card:
  rank: int
  suit: str
  tarot_number: Optional[int] = None
  bonus_value: int = 0
  is_joker: bool = False
  jaw_id: Optional[str] = None
  from_tarot_play: bool = False

  @property
  def is_joker_card(self) -> bool:
    return self.is_joker or self.suit == JOKER_SUIT

  @property
  def has_jaw_mark(self) -> bool:
    return self.jaw_id is not None

  @property
  def label(self) -> str:
    if self.is_joker_card:
      return "★"
    return RANK_LABELS[self.rank]

  @property
  def suit_symbol(self) -> str:
    if self.is_joker_card:
      return "★"
    return SUIT_SYMBOLS[self.suit]

  @property
  def is_tarot_played(self) -> bool:
    return self.tarot_number is not None

  def score_value(self) -> int:
    if self.joker_unresolved:
      return 5 + self.bonus_value
    if self.rank == 14:
      base = 11
    elif self.rank >= 11:
      base = self.rank
    else:
      base = self.rank
    return base + self.bonus_value

  def poker_rank(self) -> int:
    if self.joker_unresolved:
      return 2
    return 14 if self.rank == 14 else self.rank

  def _has_real_rank(self) -> bool:
    return self.suit in ("hearts", "diamonds", "clubs", "spades")

  @property
  def joker_unresolved(self) -> bool:
    """마법사 변형 전 조커 — 족보에 아직 펼쳐지지 않음."""
    return self.is_joker_card and not self._has_real_rank()

  def copy(self) -> Card:
    return Card(
      self.rank, self.suit, self.tarot_number, self.bonus_value,
      self.is_joker, self.jaw_id, self.from_tarot_play,
    )

  def card_key(self) -> tuple[int, str]:
    return (self.rank, self.suit)


@dataclass
class TarotCard:
  number: int
  uid: int = field(default=0)
  upgrade_level: int = 0

  @property
  def name(self) -> str:
    from game.constants import TAROT_NAMES
    return TAROT_NAMES.get(self.number, f"타로 {self.number}")

  def matching_ranks(self) -> list[int]:
    from game.tarot import tarot_matching_ranks
    return tarot_matching_ranks(self.number)

  def can_enhance(self, card: Card) -> bool:
    if card.is_joker_card:
      return self.number in (0, 1, 21)
    return card.rank in self.matching_ranks()
