SCREEN_W = 1280
SCREEN_H = 800
FPS = 60

SUITS = ("hearts", "diamonds", "clubs", "spades")
JOKER_SUIT = "joker"

DECK_MIN = 39
DECK_MAX = 65
STANDARD_DECK_SIZE = 52
JAW_MARK_CHIP_BONUS = 10  # deprecated — 턱별 효과로 대체 예정
PRIESTESS_PEEK_COUNT = 5
SUIT_SYMBOLS = {
    "hearts": "♥",
    "diamonds": "♦",
    "clubs": "♣",
    "spades": "♠",
}
SUIT_COLORS = {
    "hearts": (220, 50, 50),
    "diamonds": (220, 50, 50),
    "clubs": (30, 30, 30),
    "spades": (30, 30, 30),
}

RANK_LABELS = {
    2: "2", 3: "3", 4: "4", 5: "5", 6: "6", 7: "7",
    8: "8", 9: "9", 10: "10", 11: "J", 12: "Q", 13: "K", 14: "A",
}

# 희귀도·성립 난이도에 따라 배수 배치 (만들기 어려운 족보는 보상 대폭 상향)
HAND_MULTIPLIERS = {
    "high_card": 2,
    "pair": 3,
    "two_pair": 5,
    "three_kind": 8,
    "straight": 15,       # 5연속
    "flush": 18,          # 5동문양
    "full_house": 20,
    "three_pair": 28,     # 6장·3페어
    "straight_plus": 34,  # 6연속
    "four_pair": 38,      # 8장·4페어
    "flush_plus": 40,     # 6동문양
    "four_kind": 48,
    "double_triple": 52,  # 트리플 2조
    "octa_triple": 58,    # 8장·3+3+2
    "quad_double": 66,    # 8장·4+2+2
    "straight_flush": 88,
    "dragon": 105,        # 7연속
    "rainbow": 125,       # 7동문양
    "leviathan": 130,     # 8연속
    "spectrum": 150,      # 8동문양
    "royal_flush": 170,
}

HAND_LABELS_KO = {
    "high_card": "하이카드",
    "pair": "원페어",
    "two_pair": "투페어",
    "three_kind": "트리플",
    "straight": "스트레이트",
    "flush": "플러시",
    "full_house": "풀하우스",
    "three_pair": "쓰리페어",
    "four_pair": "포페어",
    "straight_plus": "스트레이트+",
    "flush_plus": "플러시+",
    "four_kind": "포카드",
    "double_triple": "더블트리플",
    "octa_triple": "옥타트리플",
    "quad_double": "쿼드더블",
    "straight_flush": "스트레이트 플러시",
    "dragon": "드래곤",
    "leviathan": "리바이어던",
    "rainbow": "레인보우",
    "spectrum": "스펙트럼",
    "royal_flush": "로열 플러시",
}

TAROT_NAMES = {
    0: "0 바보", 1: "I 마법사", 2: "II 여사제", 3: "III 여제", 4: "IV 황제", 5: "V 교황",
    21: "XXI 세계",
    6: "VI 연인", 7: "VII 전차", 8: "VIII 힘", 9: "IX 은둔자",
    10: "X 운명의 수레바퀴", 11: "XI 정의", 12: "XII 매달린 사람",
    13: "XIII 죽음", 14: "XIV 절제", 15: "XV 악마", 16: "XVI 탑",
    17: "XVII 별", 18: "XVIII 달", 19: "XIX 태양", 20: "XX 심판",
}

MAX_TAROT_USES = 3
MAX_TAROT_HELD = 5
HAND_SIZE = 7

def enemy_max_hp(stage: int, archetype: str = "normal") -> int:
  """스테이지별 적 HP — 후반 급상승, 요새형은 추가 배율."""
  base = 240
  linear = (stage - 1) * 165
  curve = max(0, stage - 1) ** 2 * 32
  hp = base + linear + curve
  if archetype == "fortress":
    hp = int(hp * 2.35)
  elif archetype == "blitz":
    hp = int(hp * 0.9)
  return hp


def enemy_turn_limit(stage: int, archetype: str = "normal") -> int:
  """스테이지별 전투 턴 제한 — 전반 짧게, 맹습형은 1턴."""
  if archetype == "blitz":
    return 1
  if archetype == "fortress":
    if stage <= 6:
      return 2
    if stage <= 12:
      return 3
    return 3
  if stage <= 4:
    return 2
  if stage <= 10:
    return 2
  if stage <= 16:
    return 3
  return min(4, 3 + (stage - 16) // 6)

COLORS = {
    "bg": (24, 28, 36),
    "panel": (36, 42, 54),
    "card_bg": (250, 248, 240),
    "card_border": (180, 170, 150),
    "slot_empty": (50, 56, 68),
    "text": (230, 230, 230),
    "text_dim": (160, 165, 175),
    "accent": (90, 180, 255),
    "accent2": (255, 180, 60),
    "danger": (230, 70, 70),
    "success": (80, 200, 120),
    "tarot_bg": (60, 40, 90),
    "ban": (180, 50, 50),
    "btn": (55, 65, 85),
    "btn_hover": (70, 85, 110),
}

CARD_W = 90
CARD_H = 130
CARD_GAP = 12
