"""아티팩트 런타임 헬퍼 — 보유 여부·수치 보정·획득 시 패시브."""

from __future__ import annotations

from game.constants import DECK_MIN, HAND_SIZE, MAX_TAROT_HELD
from game.progression import JAW_MARKS_PER_STAGE


def artifact_count(stacks: dict[str, int]) -> int:
  return sum(stacks.values())


def has_artifact(stacks: dict[str, int], aid: str) -> bool:
  return stacks.get(aid, 0) > 0


def effective_hand_size(stacks: dict[str, int]) -> int:
  from game.hand_size import artifact_hand_target
  return artifact_hand_target(stacks)


def effective_max_tarot_held(stacks: dict[str, int]) -> int:
  n = MAX_TAROT_HELD
  if has_artifact(stacks, "traitor_tongue"):
    n += 1
  return n


def jaw_marks_per_stage(stacks: dict[str, int]) -> int:
  if has_artifact(stacks, "infi_bible"):
    return 5
  return JAW_MARKS_PER_STAGE


def deck_min_for_run(stacks: dict[str, int]) -> int:
  if has_artifact(stacks, "infi_bible"):
    return 0
  return DECK_MIN


def alchemy_enabled(stacks: dict[str, int]) -> bool:
  return not has_artifact(stacks, "infi_bible")


def draw_pick_count(stacks: dict[str, int]) -> int:
  return 5 if has_artifact(stacks, "white_glove") else 3


def opening_deal_count(stacks: dict[str, int]) -> int:
  return 8 if has_artifact(stacks, "indulgence") else 5


def indulgence_discard_count(stacks: dict[str, int]) -> int:
  return 5 if has_artifact(stacks, "indulgence") else 2


def total_essence_count(state) -> int:
  return state.essence_salt + state.essence_sulfur + state.essence_mercury


def pale_note_rank(rank: int) -> int:
  """짝수 랭크를 반올림하여 홀수로 (J/Q/K/A는 그대로)."""
  if rank >= 11:
    return 13 if rank == 12 else rank
  if rank % 2 == 0:
    return min(13, rank + 1)
  return rank


def iceberg_upgrade_hand(hand_name: str) -> str:
  upgrades = {
    "pair": "three_kind",
    "two_pair": "full_house",
    "full_house": "double_triple",
    "three_kind": "four_kind",
  }
  return upgrades.get(hand_name, hand_name)


def on_artifact_acquired(state, aid: str) -> None:
  stacks = state.artifact_stacks
  if aid == "white_glove" or aid == "national_tournament":
    state.sync_hand_slots()
  if aid == "national_tournament":
    state.national_revive = True
  if aid == "rosary":
    state.rosary_revive = True
  if aid == "gyeongsang_twin_ghost":
    strip_all_jaw_marks(state)
    state.message = "경상도 짝귀 — 모든 이빨자국을 잃었습니다."
  if aid == "infi_bible":
    state.message = (
      "인피 성경 — 덱 최소 제한 해제 · 연금술·추가 유물 불가 · 턱 5회 자국 · 성인·악마 유해 확률↑"
    )


def strip_all_jaw_marks(state) -> None:
  pools = [state.deck.deck, state.deck.discard, state.deck.run_deck, state.deck.banned]
  for card in state.hand:
    if card:
      pools.append([card])
  for pool in pools:
    for card in pool:
      card.jaw_id = None
  state.deck.commit_run_deck()
