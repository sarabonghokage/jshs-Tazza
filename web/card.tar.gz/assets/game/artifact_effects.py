"""아티팩트 효과 — 점수·턴 시작·드로우 훅."""

from __future__ import annotations

from dataclasses import dataclass, field

from game.artifact_runtime import (
  artifact_count,
  has_artifact,
  iceberg_upgrade_hand,
  pale_note_rank,
  total_essence_count,
)
from game.constants import HAND_MULTIPLIERS, HAND_LABELS_KO
from game.jaws import PAIR_TRIPLE_HANDS, STRAIGHT_HANDS

FACE_CHIP = {14: 50, 13: 40, 12: 35, 11: 30}
# 왕을 죽이는 검 — 합산 칩 1당 적 최대 HP의 이 비율만큼 피해
KINGSLAYER_CHIP_PCT = 0.0075


@dataclass
class ArtifactRuntimeContext:
  artifact_stacks: dict[str, int] | None = None
  discard_count: int = 0
  enemy_max_hp: int = 0
  turns_remaining: int = 0
  tarot_used_count: int = 0
  essence_total: int = 0
  score_effect_count: int = 0
  resting_mult_bonus: int = 0
  kingslayer_active: bool = False
  kyungcheon_chip: int = 0
  kyungcheon_mult: int = 0


@dataclass
class ArtifactScoreResult:
  chip_add: int = 0
  chip_mult: float = 1.0
  mult_add: int = 0
  mult_mult: float = 1.0
  bonus_damage: int = 0
  lines: list[str] = field(default_factory=list)
  line_sources: dict[str, str] = field(default_factory=dict)
  kingslayer_mode: bool = False
  kingslayer_pct: float = 0.0
  block_pair_hands: bool = False
  force_hand_name: str | None = None


def apply_artifact_turn_start(state) -> None:
  stacks = state.artifact_stacks
  if not stacks:
    return
  if has_artifact(stacks, "resting_acolyte") and len(state.deck.discard) > 6:
    from game.state import SubPhase
    state.pick_pool = [c for c in state.deck.discard if not c.is_joker_card]
    if state.pick_pool:
      state.sub_phase = SubPhase.ACOLYTE_PICK
      state.message = "안식의 시종 — 묘지에서 덱으로 되돌릴 1장 선택"
      return
  state.resting_mult_bonus = getattr(state, "resting_mult_bonus", 0)


def silver_feather_chip(card) -> int | None:
  if card.rank in FACE_CHIP:
    return FACE_CHIP[card.rank] + card.bonus_value
  return None


def apply_artifact_score(
  hand: list,
  hand_name: str,
  *,
  artifact_stacks: dict[str, int],
  discard_count: int,
  enemy_max_hp: int,
  turns_remaining: int,
  tarot_used_count: int,
  essence_total: int = 0,
  score_effect_count: int = 0,
  resting_mult_bonus: int = 0,
  kingslayer_active: bool = False,
) -> ArtifactScoreResult:
  cards = [c for c in hand if c]
  if not artifact_stacks:
    return ArtifactScoreResult()

  stacks = artifact_stacks
  out = ArtifactScoreResult()

  if kingslayer_active and has_artifact(stacks, "kingslayer_sword"):
    out.kingslayer_mode = True
    out.kingslayer_pct = KINGSLAYER_CHIP_PCT
    line = f"왕을 죽이는 검  칩 1당 최대HP {KINGSLAYER_CHIP_PCT * 100:.1f}%"
    out.lines.append(line)
    out.line_sources[line] = "kingslayer_sword"
    return out

  if has_artifact(stacks, "silver_feather"):
    out.block_pair_hands = True
    if hand_name in PAIR_TRIPLE_HANDS:
      out.force_hand_name = "high_card"
      hand_name = "high_card"
      line = "진은의 깃털  페어·트리플 무효"
      out.lines.append(line)
      out.line_sources[line] = "silver_feather"

  if has_artifact(stacks, "sword_breaker"):
    if hand_name in STRAIGHT_HANDS:
      out.force_hand_name = "high_card"
      hand_name = "high_card"
      line = "소드 브레이커  스트레이트 계열 무효"
      out.lines.append(line)
      out.line_sources[line] = "sword_breaker"

  if has_artifact(stacks, "fair_trade"):
    out.chip_mult *= 0.5
    out.mult_mult *= 2.0
    line = "정당거래  칩 ×0.5 · 배수 ×2"
    out.lines.append(line)
    out.line_sources[line] = "fair_trade"

  suits_in_hand = {c.suit for c in cards if c and c.suit in ("hearts", "diamonds", "clubs", "spades")}
  if has_artifact(stacks, "fallen_flag") and len(suits_in_hand) >= 4:
    out.mult_mult *= 2.0
    line = "망국의 국기  4문양 · 배수 ×2"
    out.lines.append(line)
    out.line_sources[line] = "fallen_flag"

  if any(c and c.from_tarot_play for c in hand) and has_artifact(stacks, "silk_carpet"):
    out.chip_mult *= 1.5
    line = "실크 카펫  타로 카드로 낸 패 · 칩 +50%"
    out.lines.append(line)
    out.line_sources[line] = "silk_carpet"

  if has_artifact(stacks, "iceberg_tip"):
    upgraded = iceberg_upgrade_hand(hand_name)
    if upgraded != hand_name:
      out.force_hand_name = upgraded
      hand_name = upgraded
      line = f"빙산의 일각  {HAND_LABELS_KO.get(hand_name, hand_name)}"
      out.lines.append(line)
      out.line_sources[line] = "iceberg_tip"

  def add_chip(n: int, label: str, aid: str) -> None:
    if n:
      out.chip_add += n
      out.lines.append(label)
      out.line_sources[label] = aid

  def mul_mult(m: float, label: str, aid: str) -> None:
    if m != 1.0:
      out.mult_mult *= m
      out.lines.append(label)
      out.line_sources[label] = aid

  if has_artifact(stacks, "joy_blade") and essence_total > 0:
    add_chip(essence_total, f"환희검  칩 +{essence_total}", "joy_blade")
    out.mult_add += essence_total
    line = f"환희검  배수 +{essence_total}"
    out.lines.append(line)
    out.line_sources[line] = "joy_blade"

  if has_artifact(stacks, "severed_fingertip") and turns_remaining <= 0:
    mul_mult(3.0, "갈려나간 손 끝  마지막 턴 배수 ×3", "severed_fingertip")

  if resting_mult_bonus > 0 and has_artifact(stacks, "resting_acolyte"):
    out.mult_add += resting_mult_bonus
    line = f"안식의 시종  배수 +{resting_mult_bonus}"
    out.lines.append(line)
    out.line_sources[line] = "resting_acolyte"

  return out


def apply_artifact_bonus_damage(
  total: int,
  *,
  artifact_stacks: dict[str, int],
) -> tuple[int, list[str], dict[str, str]]:
  """합산 피해 기준 추가 피해 (소드 브레이커 등)."""
  bonus = 0
  lines: list[str] = []
  sources: dict[str, str] = {}
  if has_artifact(artifact_stacks, "sword_breaker") and total > 0:
    n = artifact_count(artifact_stacks)
    pct = 0.04 * n
    extra = int(total * pct)
    if extra > 0:
      bonus += extra
      line = f"소드 브레이커  유물 {n}개 · 추가 {extra}"
      lines.append(line)
      sources[line] = "sword_breaker"
  return bonus, lines, sources


def card_chip_with_artifacts(card, stacks: dict[str, int]) -> int:
  if has_artifact(stacks, "queen_spider"):
    if card.rank == 8:
      return 88 + card.bonus_value
    if card.rank >= 11:
      return 1 + card.bonus_value
  if has_artifact(stacks, "silver_feather"):
    custom = silver_feather_chip(card)
    if custom is not None:
      return custom
  return card.score_value()


@dataclass
class CardVisualMod:
  """유물로 인한 카드 표시 변화 (랭크/문양/칩)."""
  new_rank_label: str | None = None
  orig_rank_label: str | None = None
  new_suit: str | None = None
  orig_suit: str | None = None
  chip_override: int | None = None
  base_chip: int | None = None
  source: str = ""


def card_visual_mods(card, stacks: dict[str, int]):
  """카드에 적용되는 유물 시각 변화를 반환. 변화 없으면 None."""
  if not stacks or card is None or card.is_joker_card:
    return None
  from game.constants import RANK_LABELS

  mod = CardVisualMod()
  changed = False
  sources: list[str] = []

  if has_artifact(stacks, "pale_note"):
    pr = card.poker_rank()
    npr = pale_note_rank(pr)
    if npr != pr:
      mod.new_rank_label = RANK_LABELS.get(npr, str(npr))
      mod.orig_rank_label = RANK_LABELS.get(pr, str(pr))
      sources.append("페일노트")
      changed = True

  if has_artifact(stacks, "silver_feather"):
    custom = silver_feather_chip(card)
    if custom is not None and custom != card.score_value():
      mod.chip_override = custom
      mod.base_chip = card.score_value()
      sources.append("진은의 깃털")
      changed = True

  if sources:
    mod.source = " · ".join(sources)
  return mod if changed else None


def pale_note_active(stacks: dict[str, int]) -> bool:
  return has_artifact(stacks, "pale_note")


def whale_ribs_active(stacks: dict[str, int]) -> bool:
  return has_artifact(stacks, "whale_ribs")
