"""손패 칸 수 — 유물·타로 효과를 '목표 장수'로 합산 (max 방식)."""

from __future__ import annotations

from game.artifact_runtime import has_artifact
from game.constants import HAND_SIZE

# 유물별 손패 목표 장수 (고정값)
ARTIFACT_HAND_TARGETS: dict[str, int] = {
  "white_glove": 8,
  "national_tournament": 8,
}

# 타로별 손패 목표 (여제 등)
TAROT_HAND_TARGETS: dict[int, int] = {
  3: 8,  # III 여제
}


def artifact_hand_target(stacks: dict[str, int]) -> int:
  target = HAND_SIZE
  for aid, slots in ARTIFACT_HAND_TARGETS.items():
    if has_artifact(stacks, aid):
      target = max(target, slots)
  return target


def resolve_hand_slots(
  stacks: dict[str, int],
  *,
  play_target: int = 0,
) -> int:
  """기본·유물·이번 플레이 타로 효과 중 최대 손패 칸 수."""
  if has_artifact(stacks, "queen_spider"):
    return HAND_SIZE
  return max(HAND_SIZE, artifact_hand_target(stacks), play_target)


def empress_hand_target(upgrade_level: int) -> int:
  """여제 강화 시 손패 목표 (기본 8, 강화 9)."""
  return 9 if upgrade_level >= 1 else 8
