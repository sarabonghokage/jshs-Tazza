from __future__ import annotations

import random

from game.card import Card
from game.constants import HAND_LABELS_KO, HAND_MULTIPLIERS
from game.jaw_effects import (
  JawScoreContext,
  active_jaw_ids,
  apply_jaw_mult_modifiers,
  jaw_chip_for_card,
  jaw_straight_bonus_damage,
)
from game.jaws import FLUSH_HANDS, PAIR_TRIPLE_HANDS, STRAIGHT_HANDS


def _alchemy_card_chip_bonus(cards: list, alch) -> int:
  """연금술 카드별 칩 보너스(그림카드/낮은끗수 빌드)."""
  bonus = 0
  if alch.face_chip:
    bonus += alch.face_chip * sum(1 for c in cards if c.rank in (11, 12, 13))
  if alch.low_chip:
    bonus += alch.low_chip * sum(1 for c in cards if c.rank <= 5 or c.rank == 14)
  return bonus


def _alchemy_hand_mult_bonus(hand_name: str, alch) -> int:
  """연금술 족보 계열별 배수 보너스(아키타입 유도)."""
  bonus = 0
  if alch.flush_mult and hand_name in FLUSH_HANDS:
    bonus += alch.flush_mult
  if alch.straight_mult and hand_name in STRAIGHT_HANDS:
    bonus += alch.straight_mult
  if alch.set_mult and hand_name in PAIR_TRIPLE_HANDS:
    bonus += alch.set_mult
  return bonus
from game.alchemy import AggregatedAlchemyBonuses
from game.artifact_effects import (
  ArtifactRuntimeContext,
  apply_artifact_bonus_damage,
  apply_artifact_score,
  card_chip_with_artifacts,
  pale_note_active,
  whale_ribs_active,
)
from game.artifact_runtime import has_artifact
from game.modifiers import PlayModifiers
from game.poker import evaluate_hand_detailed, hand_at_least


def _safe_chip_factor(factor: float, *, whale: bool) -> float:
  if whale and factor < 1.0:
    return 1.0
  return factor


def calculate_score(
  hand: list[Card | None],
  modifiers: PlayModifiers | None = None,
  hand_bonuses: dict[str, int] | None = None,
  jaw_ctx: JawScoreContext | None = None,
  alchemy: AggregatedAlchemyBonuses | None = None,
  artifacts: ArtifactRuntimeContext | None = None,
) -> dict:
  mods = modifiers or PlayModifiers()
  bonuses = dict(hand_bonuses or {})
  alch = alchemy or AggregatedAlchemyBonuses()
  if alch.hand_mult_all:
    for hand_name in HAND_MULTIPLIERS:
      bonuses[hand_name] = bonuses.get(hand_name, 0) + alch.hand_mult_all
  ctx = jaw_ctx or JawScoreContext()
  cards = [c for c in hand if c is not None]

  # 황제 카드의 손패 슬롯 인덱스를 압축된 cards 리스트 기준 인덱스로 변환
  emperor_compact_idx: int | None = None
  if (
    mods.emperor_index is not None
    and 0 <= mods.emperor_index < len(hand)
    and hand[mods.emperor_index] is not None
  ):
    emperor_compact_idx = sum(1 for c in hand[: mods.emperor_index] if c is not None)

  art_ctx = artifacts or ArtifactRuntimeContext()
  stacks = art_ctx.artifact_stacks or {}
  pale = pale_note_active(stacks)
  whale = whale_ribs_active(stacks)

  hand_name, base_mult, best_indices = evaluate_hand_detailed(cards, pale_note=pale)

  if mods.min_hand:
    hand_name = hand_at_least(hand_name, mods.min_hand)

  pre_art = apply_artifact_score(
    hand, hand_name,
    artifact_stacks=stacks,
    discard_count=art_ctx.discard_count,
    enemy_max_hp=art_ctx.enemy_max_hp,
    turns_remaining=art_ctx.turns_remaining,
    tarot_used_count=art_ctx.tarot_used_count,
    essence_total=art_ctx.essence_total,
    score_effect_count=art_ctx.score_effect_count,
    resting_mult_bonus=art_ctx.resting_mult_bonus,
    kingslayer_active=art_ctx.kingslayer_active,
  )

  kingslayer = pre_art.kingslayer_mode

  if pre_art.force_hand_name:
    hand_name = pre_art.force_hand_name

  # 왕을 죽이는 검: 족보·배수형 효과 무효 (칩에 영향을 주는 효과는 유지)
  if kingslayer:
    mult = 1
  else:
    mult = (
      HAND_MULTIPLIERS[hand_name] + bonuses.get(hand_name, 0) + mods.mult_bonus
      + alch.mult_flat + _alchemy_hand_mult_bonus(hand_name, alch)
    )
    if emperor_compact_idx is not None and emperor_compact_idx in best_indices:
      mult = int(mult * mods.emperor_mult)
    mult = int(mult * mods.mult_multiplier)

  jaw_ids = active_jaw_ids(hand)
  chip_sum = mods.chip_bonus + alch.chip_flat + _alchemy_card_chip_bonus(cards, alch)
  for c in cards:
    base = card_chip_with_artifacts(c, stacks)
    chip_sum += base + jaw_chip_for_card(c, jaw_ids) - c.score_value()

  if mods.lovers_index is not None:
    chip_sum = int(chip_sum * _lovers_mult(hand, mods.lovers_index, mods.lovers_mult))

  if mods.chariot_index is not None:
    cm = _chariot_mult(chip_sum, mods.chariot_mult, mods.chariot_odd_mult)
    cm = _safe_chip_factor(cm, whale=whale)
    chip_sum = int(chip_sum * cm)

  if not kingslayer and mods.star_index is not None:
    anchor = hand[mods.star_index]
    if anchor:
      same = sum(1 for c in cards if c.suit == anchor.suit)
      mult = int(mult * (mods.star_per_suit ** same))

  if not kingslayer:
    mult = apply_jaw_mult_modifiers(hand, hand_name, ctx, mult)

  art = pre_art
  chip_sum += art.chip_add
  chip_sum = int(chip_sum * _safe_chip_factor(art.chip_mult, whale=whale))
  if not kingslayer:
    mult = int((mult + art.mult_add) * art.mult_mult)

  if art_ctx.kyungcheon_chip:
    chip_sum += art_ctx.kyungcheon_chip
  if art_ctx.kyungcheon_mult and not kingslayer:
    mult += art_ctx.kyungcheon_mult

  chip_mult_factor = (
    _safe_chip_factor(mods.chip_multiplier, whale=whale)
    * _safe_chip_factor(mods.hermit_chip_mult, whale=whale)
    * _safe_chip_factor(1.0 + alch.chip_mult, whale=whale)
  )
  chip_sum = int(chip_sum * chip_mult_factor)

  if mods.devil_zero_turn and not whale:
    chip_sum = 0
    if not kingslayer:
      mult = 0
  elif mods.devil_roll is not None:
    new_chips, new_mult = apply_devil_effect(
      mods.devil_roll, mods.devil_dice_sides, chip_sum, mult, whale_ribs=whale,
    )
    chip_sum = new_chips
    if not kingslayer:
      mult = new_mult

  if kingslayer:
    pct = pre_art.kingslayer_pct
    total = int(art_ctx.enemy_max_hp * chip_sum * pct)
    hand_name = "high_card"
    hand_label = "왕을 죽이는 검"
  else:
    total = mult * chip_sum
    hand_label = HAND_LABELS_KO[hand_name]

  bonus_damage = 0
  if not kingslayer:
    bonus_damage = jaw_straight_bonus_damage(hand, hand_name, ctx.enemy_max_hp)
    bonus_damage += art.bonus_damage
    if alch.damage_pct > 0 and total > 0:
      bonus_damage += int(total * alch.damage_pct)
    sb, _, _ = apply_artifact_bonus_damage(total, artifact_stacks=stacks)
    bonus_damage += sb
  return {
    "hand_name": hand_name,
    "hand_label": hand_label,
    "multiplier": mult,
    "chip_sum": chip_sum,
    "total": total,
    "bonus_damage": bonus_damage,
    "devil_roll": mods.devil_roll,
    "best_indices": best_indices,
    "jaw_crushed_heads": ctx.crushed_heads,
    "kingslayer": kingslayer,
  }


def _lovers_mult(hand: list[Card | None], index: int, bonus: float) -> float:
  left = hand[index - 1] if index > 0 else None
  right = hand[index + 1] if index + 1 < len(hand) else None
  center = hand[index]
  if not center or not left or not right:
    return 1.0
  if left.suit == center.suit and right.suit == center.suit:
    return bonus
  return 1.0


def _chariot_mult(chip_sum: int, even_mult: float = 2.25, odd_mult: float = 0.65) -> float:
  return even_mult if chip_sum % 2 == 0 else odd_mult


def discard_chip_half(discard: list[Card]) -> int:
  return sum(c.score_value() for c in discard) // 2


def roll_devil_dice(sides: int = 6) -> int:
  return random.randint(1, max(1, sides))


def apply_devil_effect(
  roll: int, sides: int, chips: int, mult: int, *, whale_ribs: bool = False,
) -> tuple[int, int]:
  """악마 주사위 결과를 칩·배수에 반영한다."""
  if roll == 1:
    return (chips, mult) if whale_ribs else (0, 0)
  if sides >= 8:
    if roll == 2:
      return (int(chips * 0.7), mult) if not whale_ribs else (chips, mult)
    if roll == 3:
      return (int(chips * 0.85), mult) if not whale_ribs else (chips, mult)
    if roll in (4, 5):
      return chips, int(mult * 2.0)
    if roll == 6:
      return chips, int(mult * 2.5)
    if roll == 7:
      return chips, int(mult * 3.5)
    if roll >= 8:
      return chips, int(mult * 5.0)
    return chips, mult
  if roll == 2:
    return (int(chips * 0.7), mult) if not whale_ribs else (chips, mult)
  if roll in (3, 4):
    return chips, int(mult * 2.0)
  if roll == 5:
    return chips, int(mult * 2.75)
  if roll >= 6:
    return chips, int(mult * 4.0)
  return chips, mult


def describe_devil_roll(roll: int, sides: int) -> str:
  if roll == 1:
    return "악마 주사위 1 — 이번 턴 칩 0, 즉시 종료"
  if sides >= 8:
    outcomes = {
      2: "칩 ×0.7",
      3: "칩 ×0.85",
      4: "배수 ×2.0",
      5: "배수 ×2.0",
      6: "배수 ×2.5",
      7: "배수 ×3.5",
      8: "배수 ×5.0!",
    }
    return f"악마 8각 주사위 {roll} — {outcomes.get(roll, '효과 없음')}"
  outcomes = {
    2: "칩 ×0.7",
    3: "배수 ×2.0",
    4: "배수 ×2.0",
    5: "배수 ×2.75",
    6: "배수 ×4.0!",
  }
  return f"악마 주사위 {roll} — {outcomes.get(roll, '효과 없음')}"
