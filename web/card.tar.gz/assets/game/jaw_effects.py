"""턱(이빨 자국) 효과 — 점수·드로우·벨리알 처리."""

from __future__ import annotations

import random
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from game.card import Card
from game.jaws import (
  ABADDON_JAW_ID,
  BELIAL_JAW_ID,
  BELIAL_MARKS_REQUIRED,
  BLACK_SUITS,
  FLUSH_HANDS,
  PAIR_TRIPLE_HANDS,
  RED_SUITS,
  STRAIGHT_BONUS_PCT,
  STRAIGHT_HANDS,
  count_run_jaw_marks,
)

if TYPE_CHECKING:
  from game.modifiers import PlayModifiers
  from game.state import GameState


@dataclass
class JawScoreContext:
  discard_count: int = 0
  enemy_max_hp: int = 0
  belial_jaws: list[str] = field(default_factory=list)
  crushed_heads: bool | None = None


def consume_run_jaw_marks(state: GameState, count: int) -> list[str]:
  """런 덱에서 count개 자국을 제거하고 해당 jaw_id 목록을 반환."""
  marked: list[Card] = []
  for c in state.deck.deck + state.deck.discard + state.deck.banned:
    if c.jaw_id:
      marked.append(c)
  random.shuffle(marked)
  sacrificed: list[str] = []
  for c in marked[:count]:
    if c.jaw_id:
      sacrificed.append(c.jaw_id)
      c.jaw_id = None
  return sacrificed


def _gather_run_jaw_ids(state: GameState) -> list[str]:
  ids: list[str] = []
  for c in state.deck.deck + state.deck.discard + state.deck.banned:
    if c.jaw_id:
      ids.append(c.jaw_id)
  for c in state.hand:
    if c and c.jaw_id:
      ids.append(c.jaw_id)
  return ids


def prepare_belial_hand(
  hand: list[Card | None],
  state: GameState,
  *,
  commit: bool = False,
) -> tuple[list[Card | None], JawScoreContext]:
  """벨리알: 손패에 벨리알이 있고 자국 6개 이상이면 6개 바쳐 랜덤 자국 부여."""
  ctx = JawScoreContext(
    discard_count=len(state.deck.discard),
    enemy_max_hp=state.enemy.max_hp,
  )
  has_belial = any(c and c.jaw_id == BELIAL_JAW_ID for c in hand)
  if not has_belial or count_run_jaw_marks(state) < BELIAL_MARKS_REQUIRED:
    return hand, ctx

  if commit:
    sacrificed = consume_run_jaw_marks(state, BELIAL_MARKS_REQUIRED)
  else:
    pool = _gather_run_jaw_ids(state)
    sacrificed = pool[:BELIAL_MARKS_REQUIRED] if len(pool) >= BELIAL_MARKS_REQUIRED else []

  if len(sacrificed) < BELIAL_MARKS_REQUIRED:
    return hand, ctx

  ctx.belial_jaws = sacrificed
  scored: list[Card | None] = []
  for c in hand:
    if c:
      copy = c.copy()
      copy.jaw_id = random.choice(sacrificed)
      scored.append(copy)
    else:
      scored.append(None)
  return scored, ctx


def active_jaw_ids(hand: list[Card | None]) -> set[str]:
  """패(혹은 카드 리스트)에 존재하는 모든 자국 id 집합."""
  return {c.jaw_id for c in hand if c and c.jaw_id}


@dataclass
class JawChipBonusEvent:
  """합산 연출용 — 턱 칩 보너스 1회분."""
  amount: int
  target_slot: int
  source_slots: tuple[int, ...]
  jaw_id: str
  jaw_name: str
  card_label: str


def _marked_slots_by_jaw(hand: list[Card | None]) -> dict[str, tuple[int, ...]]:
  slots: dict[str, list[int]] = {}
  for slot, card in enumerate(hand):
    if card and card.jaw_id:
      slots.setdefault(card.jaw_id, []).append(slot)
  return {jid: tuple(s) for jid, s in slots.items()}


def decompose_jaw_chip_bonuses(
  hand: list[Card | None],
  jaw_ids: set[str],
) -> list[JawChipBonusEvent]:
  """턱 칩 효과를 카드·효과별 +N 단계로 분해 (합산 연출용)."""
  if not jaw_ids:
    return []

  from game.jaws import JAW_DEFINITIONS

  marked = _marked_slots_by_jaw(hand)
  events: list[JawChipBonusEvent] = []

  def _emit(
    *,
    amount: int,
    target_slot: int,
    jaw_id: str,
    card: Card,
  ) -> None:
    if amount == 0:
      return
    jaw = JAW_DEFINITIONS.get(jaw_id)
    events.append(JawChipBonusEvent(
      amount=amount,
      target_slot=target_slot,
      source_slots=marked.get(jaw_id, ()),
      jaw_id=jaw_id,
      jaw_name=jaw.name if jaw else jaw_id,
      card_label=f"{card.label}{card.suit[0].upper()}",
    ))

  for slot, card in enumerate(hand):
    if not card:
      continue
    r = card.rank
    running = card.score_value()

    if "noble_gold" in jaw_ids and 6 <= r <= 10:
      _emit(amount=5, target_slot=slot, jaw_id="noble_gold", card=card)
      running += 5
    if "noble_red_thread" in jaw_ids and card.suit in RED_SUITS:
      _emit(amount=3, target_slot=slot, jaw_id="noble_red_thread", card=card)
      running += 3
    if "noble_octopus" in jaw_ids and card.suit in BLACK_SUITS:
      _emit(amount=3, target_slot=slot, jaw_id="noble_octopus", card=card)
      running += 3
    if "noble_lion" in jaw_ids and r in (11, 12, 13):
      new = int(running * 1.2)
      _emit(amount=new - running, target_slot=slot, jaw_id="noble_lion", card=card)
      running = new
    if "noble_feather" in jaw_ids and (r <= 5 or r == 14):
      new = int(running * 1.5)
      _emit(amount=new - running, target_slot=slot, jaw_id="noble_feather", card=card)
      running = new

  return events


def jaw_chip_for_card(card: Card, active_ids: set[str]) -> int:
  """자국 효과는 '패에 해당 자국 카드가 하나라도 있으면' 패 전체에 적용된다.

  예: 금의 가문(noble_gold) 자국 카드가 패에 있으면, 패의 모든 6~10 카드 칩 +5.
  """
  base = card.score_value()
  if not active_ids:
    return base
  bonus = 0
  mult = 1.0
  r = card.rank
  if "noble_gold" in active_ids and 6 <= r <= 10:
    bonus += 5
  if "noble_red_thread" in active_ids and card.suit in RED_SUITS:
    bonus += 3
  if "noble_octopus" in active_ids and card.suit in BLACK_SUITS:
    bonus += 3
  if "noble_lion" in active_ids and r in (11, 12, 13):
    mult *= 1.2
  if "noble_feather" in active_ids and (r <= 5 or r == 14):
    mult *= 1.5
  return int((base + bonus) * mult)


def jaw_chip_value(card: Card) -> int:
  """단일 카드 기준 칩(하위호환). 자국 효과는 그 카드 자신에게만 적용."""
  return jaw_chip_for_card(card, {card.jaw_id} if card.jaw_id else set())


def apply_jaw_mult_modifiers(
  hand: list[Card | None],
  hand_name: str,
  ctx: JawScoreContext,
  mult: int,
) -> int:
  cards = [c for c in hand if c]
  if not cards:
    return mult

  even_count = sum(1 for c in cards if c.poker_rank() % 2 == 0)
  odd_count = sum(1 for c in cards if c.poker_rank() % 2 == 1)
  jaw_ids = {c.jaw_id for c in cards if c.jaw_id}

  if "hero_spear" in jaw_ids and even_count >= 5:
    mult = int(mult * 1.5)
  if "hero_arrow" in jaw_ids and odd_count >= 5:
    mult = int(mult * 1.5)
  if "hero_crushed" in jaw_ids:
    if ctx.crushed_heads is None:
      ctx.crushed_heads = random.random() < 0.5
    if ctx.crushed_heads:
      mult = int(mult * 1.3)
  if "villain_eyes" in jaw_ids and hand_name in FLUSH_HANDS:
    mult = int(mult * 1.4)
  if "villain_limbs" in jaw_ids and hand_name in PAIR_TRIPLE_HANDS:
    mult = int(mult * 1.7)
  if "villain_charred" in jaw_ids and ctx.discard_count >= 8:
    mult = int(mult * 1.5)
  return mult


def jaw_straight_bonus_damage(hand: list[Card | None], hand_name: str, max_hp: int) -> int:
  if hand_name not in STRAIGHT_HANDS:
    return 0
  if not any(c and c.jaw_id == "wanderer_sword" for c in hand):
    return 0
  pct = STRAIGHT_BONUS_PCT.get(hand_name, 0.15)
  return int(max_hp * pct)


def discard_pile_chip_sum(discard: list[Card]) -> int:
  return sum(c.score_value() for c in discard)


def on_jaw_card_drawn(state: GameState, card: Card) -> str:
  """
  드로우된 자국 카드 처리.
  반환: 'hand' | 'consumed' | 'pending'
  """
  jid = card.jaw_id
  if not jid:
    return "hand"

  if jid == "wanderer_spine":
    state.deck.ban_cards([card])
    state.message = "등뼈가 휜 유해 — 밴 카드로 이동"
    return "consumed"

  if jid == "wanderer_lead":
    state.deck.discard_cards([card])
    dmg = max(1, state.enemy.max_hp * 5 // 100)
    state.enemy.hp = max(0, state.enemy.hp - dmg)
    state.message = f"납이 묻은 유해 — 묘지 이동 · 최대 HP 5% ({dmg}) 피해"
    return "consumed"

  if jid == "wanderer_fang":
    from game.state import SubPhase

    state.jaw_fang_quota = random.randint(1, 3)
    state.jaw_fang_picks = []
    state.jaw_fang_card = card
    state.sub_phase = SubPhase.JAW_FANG_PICK
    state.message = (
      f"앞니가 밀린 유해 — 손패에서 {state.jaw_fang_quota}장까지 선택해 리롤"
    )
    return "pending"

  if jid == "saint_michael":
    from game.state import SubPhase

    unsealed = [t for t in state.tarots if t.uid not in state.sealed_tarot_uids]
    if unsealed:
      state.jaw_pending_card = card
      state.sub_phase = SubPhase.JAW_MICHAEL_SEAL
      state.message = "미카엘 — 봉인할 타로 슬롯을 선택하세요 (처형)"
      return "pending"
    state.enemy.hp = 0
    state.message = "미카엘 — 처형! (봉인할 타로 없음)"
    return "hand"

  if jid == "saint_raphael":
    from game.constants import MAX_TAROT_USES

    state.tarot_uses_left = MAX_TAROT_USES
    state.used_tarot_uids.clear()
    state.message = "라파엘 — 타로 사용 횟수 전부 초기화"
    return "hand"

  if jid == ABADDON_JAW_ID:
    bonus = discard_pile_chip_sum(state.deck.discard)
    state.modifiers.chip_bonus += bonus
    state.message = f"아바돈 — 묘지 칩 +{bonus}"
    return "hand"

  return "hand"
