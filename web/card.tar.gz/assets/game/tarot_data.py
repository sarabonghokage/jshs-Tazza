"""타로 정의 — 효과 문구는 여기서 관리합니다."""

from __future__ import annotations

from dataclasses import dataclass

from game.constants import RANK_LABELS


@dataclass(frozen=True)
class TarotDefinition:
  number: int
  name: str
  matching_ranks: tuple[int, ...]
  effect_play: str
  effect_enhance: str
  bonus_play: int = 3
  bonus_enhance: int = 0
  max_level: int = 4


def _r(*ranks: int) -> tuple[int, ...]:
  return ranks


TAROT_DEFINITIONS: dict[int, TarotDefinition] = {
  0: TarotDefinition(0, "0 바보", _r(14), "조커 뒷면",
    "원하는 카드 선택 후 리롤 3회", bonus_play=5, bonus_enhance=0),
  1: TarotDefinition(1, "I 마법사", _r(14), "덱 조커",
    "뽑을 때 밴 제외 아무 카드로 변형", bonus_play=5, bonus_enhance=0),
  2: TarotDefinition(2, "II 여사제", _r(2), "카드로 내기 (기본)",
    "덱 위 5장 공개 → 1장 손패 (강화 시 2회)"),
  21: TarotDefinition(21, "XXI 세계", _r(14), "조커 앞면",
    "남은 덱과 묘지를 뒤바꿈", bonus_play=5, bonus_enhance=0),
  3: TarotDefinition(3, "III 여제", _r(3), "카드로 내기 (기본)",
    "손패 8장으로 확장 + 카드 1장 즉시 드로우 (강화 시 9장)"),
  4: TarotDefinition(4, "IV 황제", _r(4), "카드로 내기 (기본)",
    "해당 카드를 족보 판정에 강제 포함하고 그 족보 배수 ×4"),
  5: TarotDefinition(5, "V 교황", _r(5), "카드로 내기 (기본)",
    "투페어 이하 족보를 투페어 배수로 상향"),
  6: TarotDefinition(6, "VI 연인", _r(6), "카드로 내기 (기본)",
    "양옆 카드가 같은 문양이면 칩 ×1.5"),
  7: TarotDefinition(7, "VII 전차", _r(7), "카드로 내기 (기본)",
    "칩 합 짝수 ×2.25 / 홀수 ×0.65 (강화 시 상승)"),
  8: TarotDefinition(8, "VIII 힘", _r(8), "카드로 내기 (기본)",
    "랭크 변경 (강화 시 문양도 변경)"),
  9: TarotDefinition(9, "IX 은둔자", _r(9), "카드로 내기 (기본)",
    "문양 선택 + 다음 드로우 2장 공개, 일치 시 칩 ×1.4"),
  10: TarotDefinition(10, "X 운명의 수레바퀴", _r(10), "카드로 내기 (기본)",
    "대응 카드 리롤 (최대 5회)"),
  11: TarotDefinition(11, "XI 정의", _r(11), "카드로 내기 (기본)",
    "선택한 카드를 대칭 위치에 복제"),
  12: TarotDefinition(12, "XII 매달린 사람", _r(12), "카드로 내기 (기본)",
    "턴 무효화 후 재시작 (쿨타임 2턴)"),
  13: TarotDefinition(13, "XIII 죽음", _r(13), "카드로 내기 (기본)",
    "대응 카드 외 전부 묘지 → 묘지에서 3장 선택"),
  14: TarotDefinition(14, "XIV 절제", _r(14, 8), "카드로 내기 (기본)",
    "문양 지정 → 불일치 시 재드로우 (강화 시 2회 드로우 적용)"),
  15: TarotDefinition(15, "XV 악마", _r(2, 9), "카드로 내기 (기본)",
    "주사위: 1=턴종료 / 2=칩×0.7 / 3~4=배수×2 / 5=배수×2.75 / 6=배수×4 (강화=8각)"),
  16: TarotDefinition(16, "XVI 탑", _r(3, 10), "카드로 내기 (기본)",
    "대응 카드 제외 전부 리롤"),
  17: TarotDefinition(17, "XVII 별", _r(4, 11), "카드로 내기 (기본)",
    "같은 문양 카드 수만큼 배수 ×1.25 (곱연산, 강화 시 증가)"),
  18: TarotDefinition(18, "XVIII 달", _r(5, 12), "카드로 내기 (기본)",
    "덱 위 3장 묘지 → 패 2장과 묘지 2장 교환"),
  19: TarotDefinition(19, "XIX 태양", _r(6, 13), "카드로 내기 (기본)",
    "정오의 가호 — 이번 합산 최종 배수 ×2 (강화 시 증가)"),
  20: TarotDefinition(20, "XX 심판", _r(7), "카드로 내기 (기본)",
    "적 HP 2/3 감소 (강화 시 1/2)"),
}


def get_tarot_def(number: int) -> TarotDefinition:
  return TAROT_DEFINITIONS.get(
    number,
    TarotDefinition(number, f"타로 {number}", _r(number), "(미정)", "(미정)"),
  )


def ranks_to_text(ranks: tuple[int, ...] | list[int]) -> str:
  return " · ".join(RANK_LABELS[r] for r in ranks)


def tarot_match_text(number: int) -> str:
  defn = get_tarot_def(number)
  labels = ranks_to_text(defn.matching_ranks)
  if len(defn.matching_ranks) == 1:
    return f"트럼프 {labels} 에 대응"
  return f"트럼프 {labels} 에 대응 (둘 중 하나)"
