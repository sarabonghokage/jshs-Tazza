"""연금술 — 소금·유황·수은 원소 드랍 및 3슬롯 연성 아이템."""

from __future__ import annotations

import random
from dataclasses import dataclass
from enum import Enum


class Essence(str, Enum):
  SALT = "salt"
  SULFUR = "sulfur"
  MERCURY = "mercury"


ESSENCE_LABELS: dict[Essence, str] = {
  Essence.SALT: "소금",
  Essence.SULFUR: "유황",
  Essence.MERCURY: "수은",
}

ESSENCE_COLORS: dict[Essence, tuple[int, int, int]] = {
  Essence.SALT: (220, 220, 235),
  Essence.SULFUR: (230, 180, 60),
  Essence.MERCURY: (140, 200, 210),
}


@dataclass(frozen=True)
class ItemBonuses:
  """중첩 가능한 런 효과 — 스택 수만큼 곱해 합산.

  스탯형(flat/mult)뿐 아니라 족보 계열별 배수 보너스로 플레이 아키타입을 유도한다.
  """
  mult_flat: int = 0
  chip_flat: int = 0
  damage_pct: float = 0.0
  tarot_uses: int = 0
  turn_limit: int = 0
  hand_mult_all: int = 0
  chip_mult: float = 0.0
  # 아키타입 유도형
  flush_mult: int = 0      # 플러시 계열 족보 배수 +N
  straight_mult: int = 0   # 스트레이트 계열 족보 배수 +N
  set_mult: int = 0        # 페어/트리플/포카드 계열 배수 +N
  face_chip: int = 0       # J·Q·K 카드마다 칩 +N
  low_chip: int = 0        # A~5 카드마다 칩 +N


@dataclass(frozen=True)
class AlchemyItem:
  id: str
  name: str
  effect_summary: str
  bonuses: ItemBonuses


# 연금술발 턴/타로/수은 피해 보너스 전체 상한 — 중첩 폭주 방지
ALCHEMY_TURN_LIMIT_CAP = 1
ALCHEMY_TAROT_USES_CAP = 2
ALCHEMY_DAMAGE_PCT_CAP = 0.12

# 순서 무관 — (소금, 유황, 수은) 개수 튜플
ALCHEMY_RECIPES: dict[tuple[int, int, int], str] = {
  (3, 0, 0): "sal_tria",
  (0, 3, 0): "sulfur_ignis",
  (0, 0, 3): "mercurius_anima",
  (1, 1, 1): "tria_prima",
  (2, 1, 0): "coagulatio",
  (2, 0, 1): "fixatio",
  (1, 2, 0): "calcinatio",
  (1, 0, 2): "sublimatio",
  (0, 2, 1): "putrefactio",
  (0, 1, 2): "solutio",
}

ALCHEMY_ITEMS: dict[str, AlchemyItem] = {
  # 단일 원소 3개 — 강력한 범용 효과
  "sal_tria": AlchemyItem(
    "sal_tria", "Sal Tria (소금의 삼위)", "모든 족보 배수 +1 (중첩)",
    ItemBonuses(hand_mult_all=1),
  ),
  "sulfur_ignis": AlchemyItem(
    "sulfur_ignis", "Sulfur Ignis (유황 화염)", "합산 칩 ×1.12 (중첩)",
    ItemBonuses(chip_mult=0.12),
  ),
  "mercurius_anima": AlchemyItem(
    "mercurius_anima", "Mercurius Anima (수은의 혼)", "합산 피해의 5% 추가 (중첩·상한)",
    ItemBonuses(damage_pct=0.05),
  ),
  # 세 원소 균형 — 유틸 콤보 (턴/타로 보너스는 전체 상한이 있어 중첩 효율이 낮음)
  "tria_prima": AlchemyItem(
    "tria_prima", "Tria Prima (세 원소)", "전투 턴 +1(상한) · 타로 사용 +1(상한)",
    ItemBonuses(turn_limit=1, tarot_uses=1),
  ),
  # 아키타입 유도 — 플러시 빌드
  "coagulatio": AlchemyItem(
    "coagulatio", "Coagulatio (응고)", "플러시 계열 족보 배수 +6 (중첩)",
    ItemBonuses(flush_mult=6),
  ),
  # 스트레이트 빌드
  "fixatio": AlchemyItem(
    "fixatio", "Fixatio (고정)", "스트레이트 계열 족보 배수 +6 (중첩)",
    ItemBonuses(straight_mult=6),
  ),
  # 페어/트리플 빌드
  "calcinatio": AlchemyItem(
    "calcinatio", "Calcinatio (하소)", "페어·트리플·포카드 계열 배수 +5 (중첩)",
    ItemBonuses(set_mult=5),
  ),
  # 그림카드(J·Q·K) 빌드
  "sublimatio": AlchemyItem(
    "sublimatio", "Sublimatio (승화)", "J·Q·K 카드마다 칩 +8",
    ItemBonuses(face_chip=8),
  ),
  # 칩 폭증 + 배수
  "putrefactio": AlchemyItem(
    "putrefactio", "Putrefactio (부패)", "합산 칩 +22 · 모든 족보 배수 +1",
    ItemBonuses(chip_flat=22, hand_mult_all=1),
  ),
  # 낮은 끗수(A~5) 빌드
  "solutio": AlchemyItem(
    "solutio", "Solutio (용해)", "A~5 카드마다 칩 +8 · 칩 ×1.1",
    ItemBonuses(low_chip=8, chip_mult=0.10),
  ),
}


@dataclass
class AggregatedAlchemyBonuses:
  mult_flat: int = 0
  chip_flat: int = 0
  damage_pct: float = 0.0
  tarot_uses: int = 0
  turn_limit: int = 0
  hand_mult_all: int = 0
  chip_mult: float = 0.0
  flush_mult: int = 0
  straight_mult: int = 0
  set_mult: int = 0
  face_chip: int = 0
  low_chip: int = 0


def random_essence_drop() -> Essence:
  return random.choice(list(Essence))


def slot_recipe_key(slots: list[str | None]) -> tuple[int, int, int] | None:
  if len(slots) != 3 or any(s is None for s in slots):
    return None
  counts = {Essence.SALT.value: 0, Essence.SULFUR.value: 0, Essence.MERCURY.value: 0}
  for s in slots:
    if s not in counts:
      return None
    counts[s] += 1
  return (counts[Essence.SALT.value], counts[Essence.SULFUR.value], counts[Essence.MERCURY.value])


def resolve_recipe(slots: list[str | None]) -> str | None:
  key = slot_recipe_key(slots)
  if key is None:
    return None
  return ALCHEMY_RECIPES.get(key)


def aggregate_item_stacks(stacks: dict[str, int]) -> AggregatedAlchemyBonuses:
  total = AggregatedAlchemyBonuses()
  for item_id, count in stacks.items():
    if count <= 0:
      continue
    item = ALCHEMY_ITEMS.get(item_id)
    if not item:
      continue
    b = item.bonuses
    total.mult_flat += b.mult_flat * count
    total.chip_flat += b.chip_flat * count
    total.damage_pct += b.damage_pct * count
    total.tarot_uses += b.tarot_uses * count
    total.turn_limit += b.turn_limit * count
    total.hand_mult_all += b.hand_mult_all * count
    total.chip_mult += b.chip_mult * count
    total.flush_mult += b.flush_mult * count
    total.straight_mult += b.straight_mult * count
    total.set_mult += b.set_mult * count
    total.face_chip += b.face_chip * count
    total.low_chip += b.low_chip * count
  # 턴 경제를 무너뜨리는 무한 중첩 방지 — 연금술발 턴/타로/수은 피해 보너스 상한
  total.turn_limit = min(total.turn_limit, ALCHEMY_TURN_LIMIT_CAP)
  total.tarot_uses = min(total.tarot_uses, ALCHEMY_TAROT_USES_CAP)
  total.damage_pct = min(total.damage_pct, ALCHEMY_DAMAGE_PCT_CAP)
  return total


def get_item(item_id: str) -> AlchemyItem:
  return ALCHEMY_ITEMS.get(
    item_id,
    AlchemyItem(item_id, item_id, "(알 수 없는 연성물)", ItemBonuses()),
  )
