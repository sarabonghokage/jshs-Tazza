"""온라인 랭킹 서버 설정.

배포한 서버 주소를 LEADERBOARD_URL 에 넣으세요.
비어 있으면 온라인 랭킹·동기화가 비활성화됩니다(오프라인만 동작).
"""

# 예: 로컬 테스트  "http://127.0.0.1:8787"
# 예: 배포 서버    "https://your-ranking-server.example.com"
#
# 주의: 모바일(APK)에서는 127.0.0.1 이 폰 자신을 가리키므로 PC 서버에 닿지 않는다.
# 또한 WebView 는 https 에서 동작하므로 서버도 https 여야 혼합 콘텐츠 차단을 피한다.
# 서버를 배포하기 전까지는 빈 문자열로 두어 온라인 기능을 끈다(오프라인만 동작).
LEADERBOARD_URL = "https://jshs-tazza.onrender.com"
