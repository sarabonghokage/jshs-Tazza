from __future__ import annotations

from collections import Counter
from itertools import combinations

from game.card import Card
from game.constants import HAND_MULTIPLIERS


def evaluate_hand(cards: list[Card]) -> tuple[str, int]:
  name, mult, _ = evaluate_hand_detailed(cards)
  return name, mult


def _poker_rank(card: Card, *, pale_note: bool = False) -> int:
  r = card.poker_rank()
  if pale_note:
    from game.artifact_runtime import pale_note_rank
    return pale_note_rank(r)
  return r


def evaluate_hand_detailed(
  cards: list[Card],
  required_index: int | None = None,
  *,
  pale_note: bool = False,
) -> tuple[str, int, tuple[int, ...]]:
  pool = [(i, c) for i, c in enumerate(cards) if c is not None]
  if not pool:
    return "high_card", HAND_MULTIPLIERS["high_card"], ()

  all_cards = [c for _, c in pool]
  n = len(all_cards)

  candidates: list[tuple[str, tuple[int, ...]]] = []

  if n >= 8:
    if _is_flush(all_cards):
      candidates.append(("spectrum", tuple(i for i, _ in pool)))
    if _straight_length(all_cards, pale_note=pale_note) >= 8:
      candidates.append(("leviathan", tuple(i for i, _ in pool)))

  if n >= 7:
    if _is_flush(all_cards):
      candidates.append(("rainbow", tuple(i for i, _ in pool)))
    if _straight_length(all_cards, pale_note=pale_note) >= 7:
      candidates.append(("dragon", tuple(i for i, _ in pool)))

  if n >= 6:
    extended = _classify_extended(all_cards, pale_note=pale_note)
    if extended:
      candidates.append((extended, tuple(i for i, _ in pool)))

  if n >= 5:
    for combo in combinations(pool, 5):
      combo_cards = [c for _, c in combo]
      name = _classify_five(combo_cards, pale_note=pale_note)
      indices = tuple(i for i, _ in combo)
      if name == "straight_flush" and _is_royal(combo_cards):
        name = "royal_flush"
      candidates.append((name, indices))

  # 황제: 지정 카드가 반드시 족보 판정에 포함되도록 후보를 제한
  if required_index is not None:
    constrained = [(nm, idx) for nm, idx in candidates if required_index in idx]
    if constrained:
      candidates = constrained

  best_name = "high_card"
  best_mult = HAND_MULTIPLIERS["high_card"]
  best_indices: tuple[int, ...] = ()

  for name, indices in candidates:
    mult = HAND_MULTIPLIERS.get(name, 1)
    if mult > best_mult:
      best_mult = mult
      best_name = name
      best_indices = indices

  return best_name, best_mult, best_indices


def _classify_extended(cards: list[Card], *, pale_note: bool = False) -> str | None:
  n = len(cards)
  ranks = [_poker_rank(c, pale_note=pale_note) for c in cards]
  rank_counts = Counter(ranks)

  if n >= 8:
    counts_sorted = sorted(rank_counts.values(), reverse=True)
    if counts_sorted == [2, 2, 2, 2]:
      return "four_pair"
    if counts_sorted == [3, 3, 2]:
      return "octa_triple"
    if counts_sorted == [4, 2, 2]:
      return "quad_double"

  triples = sum(1 for v in rank_counts.values() if v >= 3)
  pair_ranks = [r for r, v in rank_counts.items() if v >= 2]

  if triples >= 2:
    return "double_triple"
  if len(pair_ranks) >= 3 and n >= 6:
    return "three_pair"

  if n >= 7:
    flush6 = any(_is_flush(list(combo)) for combo in combinations(cards, 6))
    straight6 = _straight_length(cards, pale_note=pale_note) >= 6
    if flush6 and not _is_flush(cards):
      return "flush_plus"
    if straight6 and _straight_length(cards, pale_note=pale_note) < 7:
      return "straight_plus"

  if n == 6:
    if _is_flush(cards):
      return "flush_plus"
    if _straight_length(cards, pale_note=pale_note) >= 6:
      return "straight_plus"

  return None


def _classify_five(cards: list[Card], *, pale_note: bool = False) -> str:
  ranks = sorted((_poker_rank(c, pale_note=pale_note) for c in cards), reverse=True)
  suits = [c.suit for c in cards]
  rank_counts = Counter(ranks)
  counts = sorted(rank_counts.values(), reverse=True)
  is_flush = _is_flush(cards)
  straight_high = _straight_high_five(ranks, pale_note=pale_note)

  if is_flush and straight_high == 14:
    return "royal_flush"
  if is_flush and straight_high:
    return "straight_flush"
  if counts == [4, 1]:
    return "four_kind"
  if counts == [3, 2]:
    return "full_house"
  if is_flush:
    return "flush"
  if straight_high:
    return "straight"
  if counts == [3, 1, 1]:
    return "three_kind"
  if counts == [2, 2, 1]:
    return "two_pair"
  if counts == [2, 1, 1, 1]:
    return "pair"
  return "high_card"


def _is_flush(cards: list[Card]) -> bool:
  if not cards:
    return False
  from game.jaws import effective_suits_for_flush
  for suit in ("hearts", "diamonds", "clubs", "spades"):
    if all(suit in effective_suits_for_flush(c) for c in cards):
      return True
  return False


def _is_royal(cards: list[Card]) -> bool:
  ranks = {c.poker_rank() for c in cards}
  return ranks == {10, 11, 12, 13, 14}


def _straight_high_five(ranks: list[int], *, pale_note: bool = False) -> int | None:
  return _straight_length_from_ranks(ranks, 5, pale_note=pale_note)


def _straight_length(cards: list[Card], *, pale_note: bool = False) -> int:
  ranks = [_poker_rank(c, pale_note=pale_note) for c in cards]
  for length in range(min(8, len(ranks)), 4, -1):
    if _straight_length_from_ranks(ranks, length, pale_note=pale_note):
      return length
  return 0


def _straight_length_from_ranks(ranks: list[int], need: int, *, pale_note: bool = False) -> int | None:
  if pale_note:
    from game.artifact_runtime import pale_note_rank
    transformed = sorted(set(pale_note_rank(r) for r in ranks))
    best: int | None = None
    for i in range(len(transformed) - need + 1):
      window = transformed[i : i + need]
      if len(window) == need and all(window[j + 1] - window[j] == 2 for j in range(need - 1)):
        if best is None or window[-1] > best:
          best = window[-1]
    if best is not None:
      return best

  unique = sorted(set(ranks))
  ace_low = unique[:]
  if 14 in ace_low:
    ace_low = sorted(set(ace_low) | {1})

  best: int | None = None
  for seq in (unique, ace_low):
    for i in range(len(seq) - need + 1):
      window = seq[i : i + need]
      if len(window) == need and window[-1] - window[0] == need - 1:
        high = window[-1]
        if high == 1:
          high = 5
        if best is None or high > best:
          best = high
  return best


HAND_ORDER = [
  "high_card", "pair", "two_pair", "three_kind",
  "straight", "flush", "full_house", "three_pair", "four_pair",
  "straight_plus", "flush_plus", "four_kind", "double_triple",
  "octa_triple", "quad_double",
  "straight_flush", "dragon", "leviathan", "rainbow", "spectrum", "royal_flush",
]


def hand_at_least(current: str, minimum: str) -> str:
  if current not in HAND_ORDER or minimum not in HAND_ORDER:
    return current
  if HAND_ORDER.index(current) < HAND_ORDER.index(minimum):
    return minimum
  return current
