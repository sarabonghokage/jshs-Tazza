"""온라인 랭킹 동기화 — 오프라인 우선, 온라인 시 자동 업로드."""

from __future__ import annotations

import asyncio
import json
import sys
import time
import uuid
from typing import Any

from game.leaderboard_config import LEADERBOARD_URL
from game.persistence import load_records, save_records

# --- 동기화 상태 (UI 표시용) ---
_status: str = "offline"  # offline | syncing | online | error
_status_message: str = ""
_global_cache: dict[str, Any] = {"stage": [], "damage": [], "fetched_at": 0}
_sync_task: asyncio.Task | None = None


def status() -> str:
  return _status


def status_message() -> str:
  return _status_message


def global_entries(sort: str = "stage") -> list[dict[str, Any]]:
  key = "stage" if sort == "stage" else "damage"
  entries = _global_cache.get(key, [])
  return entries if isinstance(entries, list) else []


def is_enabled() -> bool:
  return bool((LEADERBOARD_URL or "").strip())


def _base_url() -> str:
  return (LEADERBOARD_URL or "").rstrip("/")


def _ensure_device_id(data: dict[str, Any]) -> str:
  device_id = str(data.get("device_id") or "").strip()
  if not device_id:
    device_id = uuid.uuid4().hex
    data["device_id"] = device_id
    save_records(data)
  return device_id


def _new_run_id() -> str:
  return f"{int(time.time() * 1000)}-{uuid.uuid4().hex[:8]}"


def ensure_run_ids(data: dict[str, Any]) -> None:
  changed = False
  for run in data.get("runs", []):
    if not isinstance(run, dict):
      continue
    if not run.get("id"):
      run["id"] = _new_run_id()
      changed = True
    if "synced" not in run:
      run["synced"] = False
      changed = True
  if changed:
    save_records(data)


async def _http_request(method: str, url: str, body: dict | None = None, timeout: float = 4.0):
  if sys.platform == "emscripten":
    # Python dict 을 그대로 넘기면 JS 가 인식 못 하므로 JS Object 로 구성한다.
    from js import Object, fetch  # type: ignore[import-not-found]
    init = Object.new()
    init.method = method
    headers = Object.new()
    headers["Content-Type"] = "application/json"
    init.headers = headers
    if body is not None:
      init.body = json.dumps(body, ensure_ascii=False)
    resp = await fetch(url, init)
    text = await resp.text()
    return int(resp.status), text

  def _sync():
    import urllib.error
    import urllib.request
    headers = {"Content-Type": "application/json", "User-Agent": "hallasan-jakdu/1"}
    payload = None
    if body is not None:
      payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
    req = urllib.request.Request(url, data=payload, headers=headers, method=method)
    try:
      with urllib.request.urlopen(req, timeout=timeout) as resp:
        return resp.status, resp.read().decode("utf-8")
    except urllib.error.HTTPError as e:
      return e.code, e.read().decode("utf-8", errors="replace")
    except Exception as e:
      return 0, str(e)

  return await asyncio.to_thread(_sync)


async def check_online() -> bool:
  if not is_enabled():
    return False
  try:
    code, text = await _http_request("GET", f"{_base_url()}/api/health", timeout=2.5)
    if code == 200:
      data = json.loads(text)
      return bool(data.get("ok"))
  except Exception:
    pass
  return False


async def fetch_global(sort: str = "stage") -> bool:
  global _status, _status_message, _global_cache
  if not is_enabled():
    _status = "offline"
    _status_message = "서버 미설정"
    return False
  try:
    code, text = await _http_request(
      "GET",
      f"{_base_url()}/api/leaderboard?sort={sort}&limit=50",
      timeout=4.0,
    )
    if code != 200:
      _status = "error"
      _status_message = f"랭킹 조회 실패 ({code})"
      return False
    payload = json.loads(text)
    entries = payload.get("entries", [])
    if not isinstance(entries, list):
      entries = []
    _global_cache[sort] = entries
    _global_cache["fetched_at"] = int(time.time())
    _status = "online"
    _status_message = "온라인"
    return True
  except Exception as e:
    _status = "error"
    _status_message = f"랭킹 조회 오류"
    return False


async def sync_records() -> bool:
  """미동기화 런을 서버에 업로드. 성공 시 synced 표시."""
  global _status, _status_message
  if not is_enabled():
    _status = "offline"
    _status_message = "서버 미설정"
    return False

  if not await check_online():
    _status = "offline"
    _status_message = "오프라인"
    return False

  data = load_records()
  _ensure_device_id(data)
  ensure_run_ids(data)
  name = str(data.get("player_name") or "익명").strip() or "익명"
  unsynced = [
    r for r in data.get("runs", [])
    if isinstance(r, dict) and not r.get("synced")
  ]
  if not unsynced and not data.get("best_stage") and not data.get("best_damage"):
    _status = "online"
    _status_message = "동기화할 기록 없음"
    return True

  _status = "syncing"
  _status_message = "동기화 중..."

  runs_payload = []
  for run in unsynced:
    runs_payload.append({
      "run_id": str(run.get("id")),
      "stage": int(run.get("stage", 0) or 0),
      "damage": int(run.get("damage", 0) or 0),
      "wins": int(run.get("wins", 0) or 0),
    })

  # 런이 없어도 최고 기록만 서버에 반영할 수 있게 가상 런 1개 전송
  if not runs_payload and (data.get("best_stage") or data.get("best_damage")):
    marker = f"best-{data['device_id'][:8]}"
    runs_payload.append({
      "run_id": marker,
      "stage": int(data.get("best_stage", 0) or 0),
      "damage": int(data.get("best_damage", 0) or 0),
      "wins": 0,
    })

  if not runs_payload:
    _status = "online"
    _status_message = "동기화 완료"
    return True

  body = {
    "device_id": data["device_id"],
    "name": name[:16],
    "runs": runs_payload,
  }

  try:
    code, text = await _http_request("POST", f"{_base_url()}/api/scores", body=body)
    if code not in (200, 201):
      _status = "error"
      _status_message = f"업로드 실패 ({code})"
      return False
    for run in unsynced:
      run["synced"] = True
    save_records(data)
    _status = "online"
    _status_message = "동기화 완료"
    return True
  except Exception:
    _status = "error"
    _status_message = "업로드 오류"
    return False


def schedule_sync(*, fetch_after: bool = True) -> None:
  """백그라운드 동기화 예약 (중복 실행 방지)."""
  global _sync_task
  if not is_enabled():
    return
  try:
    loop = asyncio.get_running_loop()
  except RuntimeError:
    return
  if _sync_task and not _sync_task.done():
    return

  async def _job():
    await sync_records()
    if fetch_after:
      await fetch_global("stage")
      await fetch_global("damage")

  _sync_task = loop.create_task(_job())


def set_player_name(name: str) -> str:
  data = load_records()
  clean = (name or "").strip()
  if not clean:
    clean = "익명"
  clean = clean[:16]
  data["player_name"] = clean
  save_records(data)
  # 이름 변경 시 미동기화 표시 — 다시 보내기
  for run in data.get("runs", []):
    if isinstance(run, dict):
      run["synced"] = False
  save_records(data)
  return clean

def get_player_name() -> str:
  data = load_records()
  name = str(data.get("player_name") or "").strip()
  return name or "익명"
