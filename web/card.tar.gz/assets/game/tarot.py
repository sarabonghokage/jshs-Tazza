from __future__ import annotations

import random

from game.card import Card, TarotCard
from game.constants import SUITS
from game.tarot_data import get_tarot_def


def tarot_matching_ranks(number: int) -> list[int]:
  return list(get_tarot_def(number).matching_ranks)


def tarot_primary_rank(number: int) -> int:
  return tarot_matching_ranks(number)[0]


def create_tarot(number: int, uid: int) -> TarotCard:
  return TarotCard(number=number, uid=uid)


def random_tarot_numbers(count: int) -> list[int]:
  return random.sample(range(2, 21), min(count, 19))


def random_starter_choices(count: int = 3) -> list[int]:
  return random_tarot_numbers(count)


def play_tarot_as_card(tarot: TarotCard, suit: str) -> Card:
  defn = get_tarot_def(tarot.number)
  rank = tarot_primary_rank(tarot.number)
  bonus = defn.bonus_play + tarot.upgrade_level * 5
  return Card(
    rank=rank, suit=suit, tarot_number=tarot.number, bonus_value=bonus, from_tarot_play=True,
  )


def enhance_card_with_tarot(card: Card, tarot: TarotCard) -> Card:
  defn = get_tarot_def(tarot.number)
  enhanced = card.copy()
  enhanced.tarot_number = tarot.number
  enhanced.bonus_value += defn.bonus_enhance + tarot.upgrade_level * 5
  return enhanced
