"""아티팩트 — 런을 바꾸는 유물. 연금술(연성)과 별개로 플레이 스타일을 정의한다.

ARTIFACT_DEFINITIONS 딕셔너리만 수정하면 목록 전체를 교체할 수 있다.
(이름·효과 요약·희귀도·max_stacks — 실제 수치 로직은 artifact_effects.py / artifact_runtime.py)
"""

from __future__ import annotations

import random
from dataclasses import dataclass
from enum import Enum


class ArtifactRarity(str, Enum):
  COMMON = "common"
  RARE = "rare"
  EPIC = "epic"


RARITY_LABELS: dict[ArtifactRarity, str] = {
  ArtifactRarity.COMMON: "일반",
  ArtifactRarity.RARE: "희귀",
  ArtifactRarity.EPIC: "전설",
}

RARITY_COLORS: dict[ArtifactRarity, tuple[int, int, int]] = {
  ArtifactRarity.COMMON: (170, 185, 210),
  ArtifactRarity.RARE: (120, 170, 255),
  ArtifactRarity.EPIC: (230, 180, 80),
}

MAX_ARTIFACTS = 8
ARTIFACT_REWARD_CHOICES = 3
STARTING_ARTIFACT_OFFER = True


@dataclass(frozen=True)
class ArtifactDefinition:
  id: str
  name: str
  effect_summary: str
  rarity: ArtifactRarity
  max_stacks: int = 1


ARTIFACT_DEFINITIONS: dict[str, ArtifactDefinition] = {
  "pale_note": ArtifactDefinition(
    "pale_note", "페일노트",
    "짝수 랭크→홀수 변환 · 홀수 스트레이트 인정",
    ArtifactRarity.EPIC,
  ),
  "red_bowl": ArtifactDefinition(
    "red_bowl", "붉은 그릇",
    "타로는 붉은 문양만 · 문양 직접 선택",
    ArtifactRarity.RARE,
  ),
  "future_shackle": ArtifactDefinition(
    "future_shackle", "미래의 노예의 족쇄",
    "같은 타로 카드를 한 번 더 사용",
    ArtifactRarity.RARE,
  ),
  "silver_feather": ArtifactDefinition(
    "silver_feather", "진은의 깃털",
    "A/K/Q/J 칩 50/40/35/30 · 페어·트리플 계열 불가",
    ArtifactRarity.EPIC,
  ),
  "rusty_pelican": ArtifactDefinition(
    "rusty_pelican", "녹슨 철제 펠리컨",
    "턱 스테이지에서 제시 턱마다 1회 리롤",
    ArtifactRarity.RARE,
  ),
  "indulgence": ArtifactDefinition(
    "indulgence", "면죄부",
    "밴 대신 8장 중 5장을 묘지로",
    ArtifactRarity.RARE,
  ),
  "blood_horn": ArtifactDefinition(
    "blood_horn", "살점 뭍은 호른",
    "드로우마다 덱 1장 묘지 · 자국이면 드로우 효과",
    ArtifactRarity.EPIC,
  ),
  "resting_acolyte": ArtifactDefinition(
    "resting_acolyte", "안식의 시종",
    "묘지 6장 초과 시 1장 덱 복귀 · 칩만큼 배수+",
    ArtifactRarity.RARE,
  ),
  "ether": ArtifactDefinition(
    "ether", "에테르",
    "적 처치 시 연금 재료 각 +4",
    ArtifactRarity.RARE,
  ),
  "white_glove": ArtifactDefinition(
    "white_glove", "관백의 손",
    "손패 8장 · 드로우 후보 5장",
    ArtifactRarity.COMMON,
  ),
  "severed_fingertip": ArtifactDefinition(
    "severed_fingertip", "갈려나간 손 끝",
    "마지막 턴 배수 ×3",
    ArtifactRarity.EPIC,
  ),
  "locust_necklace": ArtifactDefinition(
    "locust_necklace", "메뚜기 목걸이",
    "합산에 적용된 효과마다 칩 +25",
    ArtifactRarity.RARE,
  ),
  "iceberg_tip": ArtifactDefinition(
    "iceberg_tip", "빙산의 일각",
    "페어→트리플 · 투페어→풀하우스 · 풀하우스→더블트리플 · 트리플→포카드",
    ArtifactRarity.EPIC,
  ),
  "traitor_tongue": ArtifactDefinition(
    "traitor_tongue", "배신자의 혀",
    "턱 자국 포기→타로 획득/새로고침 · 타로 슬롯 +1",
    ArtifactRarity.EPIC,
  ),
  "compressed_head": ArtifactDefinition(
    "compressed_head", "압축된 머리",
    "사망 시 모든 이빨 자국 제거 후 부활 (1회)",
    ArtifactRarity.EPIC,
  ),
  "infi_bible": ArtifactDefinition(
    "infi_bible", "인피 성경",
    "덱 최소 제한 없음 · 연금/추가유물 불가 · 턱 5회 · 성인·악마 유해↑",
    ArtifactRarity.EPIC,
  ),
  "whale_ribs": ArtifactDefinition(
    "whale_ribs", "고래의 갈비",
    "칩·배수 감소 효과 무효",
    ArtifactRarity.EPIC,
  ),
  "star_clock": ArtifactDefinition(
    "star_clock", "별시계",
    "턴 +50% · 하이카드/페어 합산 시 즉사",
    ArtifactRarity.EPIC,
  ),
  "kingslayer_sword": ArtifactDefinition(
    "kingslayer_sword", "왕을 죽이는 검",
    "타로처럼 발동 · 합산 후 검격 · 칩→최대HP% 피해 · 스테이지당 1회",
    ArtifactRarity.EPIC,
  ),
  "joy_blade": ArtifactDefinition(
    "joy_blade", "환희검",
    "보유 연금 재료 수만큼 칩·족보 배수 증가",
    ArtifactRarity.RARE,
  ),
  "silk_carpet": ArtifactDefinition(
    "silk_carpet", "실크 카펫",
    "타로를 카드로 낼 때 최종 칩 +50%",
    ArtifactRarity.RARE,
  ),
  "queen_spider": ArtifactDefinition(
    "queen_spider", "여왕 거미",
    "8 카드 칩 88 · JQK 칩 1 · 손패 증가 불가",
    ArtifactRarity.EPIC,
  ),
  "sword_breaker": ArtifactDefinition(
    "sword_breaker", "소드 브레이커",
    "스트레이트 계열 불가 · 유물 수에 비례 추가 피해",
    ArtifactRarity.EPIC,
  ),
  "rosary": ArtifactDefinition(
    "rosary", "묵주",
    "교황 보유 시만 획득 · 턴+1 타로+1 · 사망 시 재전투 1회",
    ArtifactRarity.EPIC,
  ),
  "fallen_flag": ArtifactDefinition(
    "fallen_flag", "망국의 국기",
    "4문양 모두 포함 시 배수 ×2",
    ArtifactRarity.RARE,
  ),
  "fair_trade": ArtifactDefinition(
    "fair_trade", "정당거래",
    "칩 ×0.5 · 족보 배수 ×2",
    ArtifactRarity.RARE,
  ),
  "kyungcheon": ArtifactDefinition(
    "kyungcheon", "경천",
    "드래곤·레인보우 합산 시 영구 칩·배수 증가",
    ArtifactRarity.EPIC,
  ),
  "super_coward_club": ArtifactDefinition(
    "super_coward_club", "슈퍼 겁쟁이 클럽",
    "스테이지당 1회 · 빈칸 2장일 때 패 무효화",
    ArtifactRarity.RARE,
  ),
  "jiri_blade": ArtifactDefinition(
    "jiri_blade", "지리산 작두",
    "스테이지당 1회 덱에서 원하는 카드 드로우 · 턴 -1",
    ArtifactRarity.EPIC,
  ),
  "jeolla_angler": ArtifactDefinition(
    "jeolla_angler", "전라도 아귀",
    "3스테이지마다 다음 스테이지 전투 스킵",
    ArtifactRarity.EPIC,
  ),
  "national_tournament": ArtifactDefinition(
    "national_tournament", "전국 타짜 평정장",
    "타로 +1 · 손패 +1 · 부활 1회",
    ArtifactRarity.EPIC,
  ),
  "gyeongsang_twin_ghost": ArtifactDefinition(
    "gyeongsang_twin_ghost", "경상도 짝귀",
    "다음 드로우 항상 공개 · 획득 시 이빨자국 전부 소실",
    ArtifactRarity.EPIC,
  ),
  "hallasan_kangjihu": ArtifactDefinition(
    "hallasan_kangjihu", "한라산 작두 강지후",
    "드로우마다 1/3 확률로 랜덤 이빨자국 효과 · 성인·악마 유해 등장 안 함",
    ArtifactRarity.EPIC,
  ),
}


def get_artifact(artifact_id: str) -> ArtifactDefinition:
  return ARTIFACT_DEFINITIONS.get(
    artifact_id,
    ArtifactDefinition(artifact_id, artifact_id, "(알 수 없는 유물)", ArtifactRarity.COMMON),
  )


def artifact_count(stacks: dict[str, int]) -> int:
  return sum(stacks.values())


def has_infi_bible(stacks: dict[str, int]) -> bool:
  return stacks.get("infi_bible", 0) > 0


# 함께 보유하면 서로를 망가뜨리는 유물 (양방향). 한쪽 보유 시 다른 쪽 제안 제외.
#  - silver_feather(페어·트리플 무효) + star_clock(하이카드/페어 즉사):
#    페어가 high_card로 강제 → 사실상 즉사 트랩이라 동시 제안 금지.
#  - silver_feather + iceberg_tip(페어→트리플 등 상향): silver가 먼저 high_card로
#    강등시켜 iceberg가 완전히 무효화 → 죽은 픽이 되므로 제외.
ARTIFACT_CONFLICTS: dict[str, set[str]] = {
  "silver_feather": {"star_clock", "iceberg_tip"},
  "star_clock": {"silver_feather"},
  "iceberg_tip": {"silver_feather"},
}


def _conflicts_with_owned(aid: str, stacks: dict[str, int]) -> bool:
  for owned, _n in stacks.items():
    if _n <= 0:
      continue
    if aid in ARTIFACT_CONFLICTS.get(owned, set()):
      return True
    if owned in ARTIFACT_CONFLICTS.get(aid, set()):
      return True
  return False


def eligible_artifact_ids(
  stacks: dict[str, int],
  *,
  tarot_numbers: set[int] | None = None,
) -> list[str]:
  if artifact_count(stacks) >= MAX_ARTIFACTS:
    return []
  if has_infi_bible(stacks):
    return []
  ids: list[str] = []
  for aid, defn in ARTIFACT_DEFINITIONS.items():
    if stacks.get(aid, 0) >= defn.max_stacks:
      continue
    if aid == "rosary" and (not tarot_numbers or 5 not in tarot_numbers):
      continue
    if _conflicts_with_owned(aid, stacks):
      continue
    ids.append(aid)
  return ids


def random_artifact_offers(
  stacks: dict[str, int],
  count: int = ARTIFACT_REWARD_CHOICES,
  *,
  tarot_numbers: set[int] | None = None,
) -> list[str]:
  pool = eligible_artifact_ids(stacks, tarot_numbers=tarot_numbers)
  if not pool:
    return []
  weights = {
    ArtifactRarity.COMMON: 5.0,
    ArtifactRarity.RARE: 2.5,
    ArtifactRarity.EPIC: 1.0,
  }
  offers: list[str] = []
  bag = pool[:]
  while len(offers) < min(count, len(pool)) and bag:
    w = [weights[ARTIFACT_DEFINITIONS[aid].rarity] for aid in bag]
    pick = random.choices(bag, weights=w, k=1)[0]
    offers.append(pick)
    bag.remove(pick)
  return offers
