"""게임 진행 저장/불러오기 — 데스크톱 파일 · 웹 localStorage."""

from __future__ import annotations

import json
import os
from dataclasses import asdict, fields
from pathlib import Path
from typing import Any

from game.card import Card, TarotCard
from game.deck import DeckManager
from game.jaw_effects import JawScoreContext
from game.modifiers import PlayModifiers
from game.score_steps import ScoreRevealStep
from game.state import Enemy, GameState, Phase, SubPhase

SAVE_KEY = "hallasan_jakdu_save_v1"
SAVE_VERSION = 1

RECORDS_KEY = "hallasan_jakdu_records_v1"
RECORDS_VERSION = 2
RECORDS_MAX_RUNS = 10


def _is_web() -> bool:
  import sys
  return sys.platform == "emscripten"


def _save_path() -> Path:
  base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or str(Path.home())
  return Path(base) / "hallasan_jakdu" / "save.json"


def _records_path() -> Path:
  base = os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or str(Path.home())
  return Path(base) / "hallasan_jakdu" / "records.json"


def _kv_read(key: str, path: Path) -> str | None:
  if _is_web():
    try:
      from js import window  # type: ignore[import-not-found]
      return window.localStorage.getItem(key)
    except Exception:
      try:
        import platform  # type: ignore[import-not-found]
        return platform.window.localStorage.getItem(key)
      except Exception:
        return None
  if path.is_file():
    return path.read_text(encoding="utf-8")
  return None


def _kv_write(key: str, path: Path, text: str) -> bool:
  try:
    if _is_web():
      try:
        from js import window  # type: ignore[import-not-found]
        window.localStorage.setItem(key, text)
        return True
      except Exception:
        import platform  # type: ignore[import-not-found]
        platform.window.localStorage.setItem(key, text)
        return True
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return True
  except Exception:
    return False


def _kv_delete(key: str, path: Path) -> None:
  try:
    if _is_web():
      try:
        from js import window  # type: ignore[import-not-found]
        window.localStorage.removeItem(key)
        return
      except Exception:
        import platform  # type: ignore[import-not-found]
        platform.window.localStorage.removeItem(key)
        return
    if path.is_file():
      path.unlink()
  except Exception:
    pass


def _storage_read() -> str | None:
  return _kv_read(SAVE_KEY, _save_path())


def _storage_write(text: str) -> bool:
  return _kv_write(SAVE_KEY, _save_path(), text)


def _storage_delete() -> None:
  _kv_delete(SAVE_KEY, _save_path())


def _card_to_dict(card: Card | None) -> dict | None:
  if card is None:
    return None
  return {
    "rank": card.rank,
    "suit": card.suit,
    "tarot_number": card.tarot_number,
    "bonus_value": card.bonus_value,
    "is_joker": card.is_joker,
    "jaw_id": card.jaw_id,
    "from_tarot_play": card.from_tarot_play,
  }


def _card_from_dict(data: dict | None) -> Card | None:
  if data is None:
    return None
  return Card(
    rank=data["rank"],
    suit=data["suit"],
    tarot_number=data.get("tarot_number"),
    bonus_value=data.get("bonus_value", 0),
    is_joker=data.get("is_joker", False),
    jaw_id=data.get("jaw_id"),
    from_tarot_play=data.get("from_tarot_play", False),
  )


def _cards_to_dict(cards: list[Card]) -> list[dict]:
  return [_card_to_dict(c) for c in cards]  # type: ignore[misc]


def _cards_from_dict(items: list[dict]) -> list[Card]:
  return [_card_from_dict(d) for d in items]  # type: ignore[misc]


def _tarot_to_dict(t: TarotCard) -> dict:
  return {"number": t.number, "uid": t.uid, "upgrade_level": t.upgrade_level}


def _tarot_from_dict(data: dict) -> TarotCard:
  return TarotCard(
    number=data["number"],
    uid=data.get("uid", 0),
    upgrade_level=data.get("upgrade_level", 0),
  )


def _step_to_dict(step: ScoreRevealStep) -> dict:
  return {
    "kind": step.kind,
    "text": step.text,
    "slot": step.slot,
    "chip_value": step.chip_value,
    "chips": step.chips,
    "mult": step.mult,
    "total": step.total,
    "highlight_slots": list(step.highlight_slots),
    "artifact_id": step.artifact_id,
  }


def _step_from_dict(data: dict) -> ScoreRevealStep:
  return ScoreRevealStep(
    kind=data["kind"],
    text=data["text"],
    slot=data.get("slot"),
    chip_value=data.get("chip_value", 0),
    chips=data.get("chips", 0),
    mult=data.get("mult", 1),
    total=data.get("total", 0),
    highlight_slots=tuple(data.get("highlight_slots", [])),
    artifact_id=data.get("artifact_id"),
  )


def _deck_to_dict(deck: DeckManager) -> dict:
  return {
    "trump_count": deck.trump_count,
    "include_joker": deck.include_joker,
    "run_deck": _cards_to_dict(deck.run_deck),
    "deck": _cards_to_dict(deck.deck),
    "discard": _cards_to_dict(deck.discard),
    "banned": _cards_to_dict(deck.banned),
  }


def _deck_from_dict(data: dict) -> DeckManager:
  dm = DeckManager()
  dm.trump_count = data.get("trump_count", dm.trump_count)
  dm.include_joker = data.get("include_joker", True)
  dm.run_deck = _cards_from_dict(data.get("run_deck", []))
  dm.deck = _cards_from_dict(data.get("deck", []))
  dm.discard = _cards_from_dict(data.get("discard", []))
  dm.banned = _cards_from_dict(data.get("banned", []))
  return dm


def _enemy_to_dict(enemy: Enemy) -> dict:
  return asdict(enemy)


def _enemy_from_dict(data: dict) -> Enemy:
  return Enemy(**data)


def _modifiers_to_dict(mods: PlayModifiers) -> dict:
  return asdict(mods)


def _modifiers_from_dict(data: dict) -> PlayModifiers:
  mods = PlayModifiers()
  for key, value in data.items():
    if hasattr(mods, key):
      setattr(mods, key, value)
  return mods


def _jaw_ctx_to_dict(ctx: JawScoreContext | None) -> dict | None:
  if ctx is None:
    return None
  return asdict(ctx)


def _jaw_ctx_from_dict(data: dict | None) -> JawScoreContext | None:
  if data is None:
    return None
  return JawScoreContext(**data)


def can_persist_state(state: GameState) -> bool:
  return state.phase not in (Phase.MAIN_MENU, Phase.RECORDS, Phase.GAME_OVER)


def serialize_state(state: GameState) -> dict[str, Any]:
  return {
    "version": SAVE_VERSION,
    "phase": state.phase.name,
    "sub_phase": state.sub_phase.name,
    "deck": _deck_to_dict(state.deck),
    "hand": [_card_to_dict(c) for c in state.hand],
    "max_hand_slots": state.max_hand_slots,
    "opening_five": _cards_to_dict(state.opening_five),
    "ban_selection": list(state.ban_selection),
    "draw_three": _cards_to_dict(state.draw_three),
    "pick_pool": _cards_to_dict(state.pick_pool),
    "tarots": [_tarot_to_dict(t) for t in state.tarots],
    "tarot_uses_left": state.tarot_uses_left,
    "used_tarot_uids": sorted(state.used_tarot_uids),
    "pending_tarot": _tarot_to_dict(state.pending_tarot) if state.pending_tarot else None,
    "tarot_mode": state.tarot_mode,
    "enemy": _enemy_to_dict(state.enemy),
    "last_score": state.last_score,
    "score_reveal_steps": [_step_to_dict(s) for s in state.score_reveal_steps],
    "score_damage_applied": state.score_damage_applied,
    "message": state.message,
    "tarot_uid_counter": state.tarot_uid_counter,
    "wins": state.wins,
    "starter_tarot_choices": [_tarot_to_dict(t) for t in state.starter_tarot_choices],
    "reward_tarot_choices": [_tarot_to_dict(t) for t in state.reward_tarot_choices],
    "hand_bonuses": dict(state.hand_bonuses),
    "modifiers": _modifiers_to_dict(state.modifiers),
    "hanged_man_cooldown": state.hanged_man_cooldown,
    "joker_pending": _card_to_dict(state.joker_pending),
    "joker_target_slot": state.joker_target_slot,
    "joker_draw_face": state.joker_draw_face,
    "fool_rerolls_left": state.fool_rerolls_left,
    "fool_pick_slots": list(state.fool_pick_slots),
    "jaw_offers": list(state.jaw_offers),
    "jaw_card_pool": _cards_to_dict(state.jaw_card_pool),
    "jaw_picked_card_index": state.jaw_picked_card_index,
    "jaw_picked_offer_index": state.jaw_picked_offer_index,
    "sealed_tarot_uids": sorted(state.sealed_tarot_uids),
    "jaw_fang_quota": state.jaw_fang_quota,
    "jaw_fang_picks": list(state.jaw_fang_picks),
    "jaw_fang_card": _card_to_dict(state.jaw_fang_card),
    "jaw_pending_card": _card_to_dict(state.jaw_pending_card),
    "jaw_score_ctx": _jaw_ctx_to_dict(state.jaw_score_ctx),
    "jaw_marks_remaining": state.jaw_marks_remaining,
    "live_hand_tier": state.live_hand_tier,
    "live_hand_label": state.live_hand_label,
    "live_best_indices": list(state.live_best_indices),
    "temperance_index": state.temperance_index,
    "temperance_rerolls": state.temperance_rerolls,
    "temperance_pending_card": _card_to_dict(state.temperance_pending_card),
    "temperance_suit": state.temperance_suit,
    "temperance_draws_remaining": state.temperance_draws_remaining,
    "priestess_passes_remaining": state.priestess_passes_remaining,
    "justice_anchor_index": state.justice_anchor_index,
    "strength_allow_suit": state.strength_allow_suit,
    "rank_change_source": state.rank_change_source,
    "rank_change_target": state.rank_change_target,
    "strength_rank": state.strength_rank,
    "strength_suit": state.strength_suit,
    "wheel_index": state.wheel_index,
    "wheel_rolls": state.wheel_rolls,
    "hermit_peek": _cards_to_dict(state.hermit_peek),
    "hermit_level": state.hermit_level,
    "next_draw_preview": _cards_to_dict(state.next_draw_preview),
    "moon_discard_picks": list(state.moon_discard_picks),
    "moon_hand_picks": list(state.moon_hand_picks),
    "death_picks": list(state.death_picks),
    "battle_turn": state.battle_turn,
    "discard_scroll": state.discard_scroll,
    "well_discard_remaining": state.well_discard_remaining,
    "well_gain_remaining": state.well_gain_remaining,
    "well_deck_scroll": state.well_deck_scroll,
    "essence_salt": state.essence_salt,
    "essence_sulfur": state.essence_sulfur,
    "essence_mercury": state.essence_mercury,
    "alchemy_slots": list(state.alchemy_slots),
    "item_stacks": dict(state.item_stacks),
    "last_essence_drop": state.last_essence_drop,
    "artifact_stacks": dict(state.artifact_stacks),
    "artifact_reward_choices": list(state.artifact_reward_choices),
    "starter_pick_pending": state.starter_pick_pending,
    "reward_pick_pending": state.reward_pick_pending,
    "artifact_pick_pending": state.artifact_pick_pending,
    "upgrade_tab": state.upgrade_tab,
    "upgrade_tarot_pending": state.upgrade_tarot_pending,
    "upgrade_hand_pending": state.upgrade_hand_pending,
    "shackle_tarot_uses": {str(k): v for k, v in state.shackle_tarot_uses.items()},
    "jaw_offer_rerolled": list(state.jaw_offer_rerolled),
    "resting_mult_bonus": state.resting_mult_bonus,
    "compressed_head_used": state.compressed_head_used,
    "hand_size_play_target": state.hand_size_play_target,
    "kingslayer_spent": state.kingslayer_spent,
    "kingslayer_armed": state.kingslayer_armed,
    "kingslayer_finale_steps": [_step_to_dict(s) for s in state.kingslayer_finale_steps],
    "kyungcheon_chip": state.kyungcheon_chip,
    "kyungcheon_mult": state.kyungcheon_mult,
    "coward_club_spent": state.coward_club_spent,
    "jiri_blade_spent": state.jiri_blade_spent,
    "rosary_revive": state.rosary_revive,
    "national_revive": state.national_revive,
  }


def deserialize_state(data: dict[str, Any]) -> GameState:
  if data.get("version") != SAVE_VERSION:
    raise ValueError("unsupported save version")

  state = GameState()
  state.phase = Phase[data["phase"]]
  state.sub_phase = SubPhase[data["sub_phase"]]
  state.deck = _deck_from_dict(data["deck"])
  state.hand = [_card_from_dict(c) for c in data.get("hand", [])]
  state.max_hand_slots = data.get("max_hand_slots", state.max_hand_slots)
  state.opening_five = _cards_from_dict(data.get("opening_five", []))
  state.ban_selection = list(data.get("ban_selection", []))
  state.draw_three = _cards_from_dict(data.get("draw_three", []))
  state.pick_pool = _cards_from_dict(data.get("pick_pool", []))
  state.tarots = [_tarot_from_dict(t) for t in data.get("tarots", [])]
  state.tarot_uses_left = data.get("tarot_uses_left", state.tarot_uses_left)
  state.used_tarot_uids = set(data.get("used_tarot_uids", []))
  pt = data.get("pending_tarot")
  state.pending_tarot = _tarot_from_dict(pt) if pt else None
  state.tarot_mode = data.get("tarot_mode")
  state.enemy = _enemy_from_dict(data["enemy"])
  state.last_score = data.get("last_score")
  state.score_reveal_steps = [_step_from_dict(s) for s in data.get("score_reveal_steps", [])]
  state.score_damage_applied = data.get("score_damage_applied", False)
  state.message = data.get("message", "")
  state.tarot_uid_counter = data.get("tarot_uid_counter", 0)
  state.wins = data.get("wins", 0)
  state.starter_tarot_choices = [_tarot_from_dict(t) for t in data.get("starter_tarot_choices", [])]
  state.reward_tarot_choices = [_tarot_from_dict(t) for t in data.get("reward_tarot_choices", [])]
  state.hand_bonuses = dict(data.get("hand_bonuses", {}))
  state.modifiers = _modifiers_from_dict(data.get("modifiers", {}))
  state.hanged_man_cooldown = data.get("hanged_man_cooldown", 0)
  state.joker_pending = _card_from_dict(data.get("joker_pending"))
  state.joker_target_slot = data.get("joker_target_slot")
  state.joker_draw_face = data.get("joker_draw_face")
  state.fool_rerolls_left = data.get("fool_rerolls_left", 0)
  state.fool_pick_slots = list(data.get("fool_pick_slots", []))
  state.jaw_offers = list(data.get("jaw_offers", []))
  state.jaw_card_pool = _cards_from_dict(data.get("jaw_card_pool", []))
  state.jaw_picked_card_index = data.get("jaw_picked_card_index")
  state.jaw_picked_offer_index = data.get("jaw_picked_offer_index")
  state.sealed_tarot_uids = set(data.get("sealed_tarot_uids", []))
  state.jaw_fang_quota = data.get("jaw_fang_quota", 0)
  state.jaw_fang_picks = list(data.get("jaw_fang_picks", []))
  state.jaw_fang_card = _card_from_dict(data.get("jaw_fang_card"))
  state.jaw_pending_card = _card_from_dict(data.get("jaw_pending_card"))
  state.jaw_score_ctx = _jaw_ctx_from_dict(data.get("jaw_score_ctx"))
  state.jaw_marks_remaining = data.get("jaw_marks_remaining", 0)
  state.live_hand_tier = data.get("live_hand_tier", 0)
  state.live_hand_label = data.get("live_hand_label", "")
  state.live_best_indices = tuple(data.get("live_best_indices", []))
  state.temperance_index = data.get("temperance_index")
  state.temperance_rerolls = data.get("temperance_rerolls", 0)
  state.temperance_pending_card = _card_from_dict(data.get("temperance_pending_card"))
  state.temperance_suit = data.get("temperance_suit")
  state.temperance_draws_remaining = data.get("temperance_draws_remaining", 0)
  state.priestess_passes_remaining = data.get("priestess_passes_remaining", 0)
  state.justice_anchor_index = data.get("justice_anchor_index")
  state.strength_allow_suit = data.get("strength_allow_suit", False)
  state.rank_change_source = data.get("rank_change_source")
  state.rank_change_target = data.get("rank_change_target")
  state.strength_rank = data.get("strength_rank", 2)
  state.strength_suit = data.get("strength_suit", "hearts")
  state.wheel_index = data.get("wheel_index")
  state.wheel_rolls = data.get("wheel_rolls", 0)
  state.hermit_peek = _cards_from_dict(data.get("hermit_peek", []))
  state.hermit_level = data.get("hermit_level", 0)
  state.next_draw_preview = _cards_from_dict(data.get("next_draw_preview", []))
  state.moon_discard_picks = list(data.get("moon_discard_picks", []))
  state.moon_hand_picks = list(data.get("moon_hand_picks", []))
  state.death_picks = list(data.get("death_picks", []))
  state.battle_turn = data.get("battle_turn", 0)
  state.discard_scroll = data.get("discard_scroll", 0)
  state.well_discard_remaining = data.get("well_discard_remaining", 0)
  state.well_gain_remaining = data.get("well_gain_remaining", 0)
  state.well_deck_scroll = data.get("well_deck_scroll", 0)
  state.essence_salt = data.get("essence_salt", 0)
  state.essence_sulfur = data.get("essence_sulfur", 0)
  state.essence_mercury = data.get("essence_mercury", 0)
  state.alchemy_slots = list(data.get("alchemy_slots", [None, None, None]))
  state.item_stacks = dict(data.get("item_stacks", {}))
  state.last_essence_drop = data.get("last_essence_drop")
  state.artifact_stacks = dict(data.get("artifact_stacks", {}))
  state.artifact_reward_choices = list(data.get("artifact_reward_choices", []))
  state.starter_pick_pending = data.get("starter_pick_pending")
  state.reward_pick_pending = data.get("reward_pick_pending")
  state.artifact_pick_pending = data.get("artifact_pick_pending")
  state.upgrade_tab = data.get("upgrade_tab", "tarot")
  state.upgrade_tarot_pending = data.get("upgrade_tarot_pending")
  state.upgrade_hand_pending = data.get("upgrade_hand_pending")
  state.shackle_tarot_uses = {int(k): v for k, v in data.get("shackle_tarot_uses", {}).items()}
  state.jaw_offer_rerolled = list(data.get("jaw_offer_rerolled", []))
  state.resting_mult_bonus = data.get("resting_mult_bonus", 0)
  state.compressed_head_used = data.get("compressed_head_used", False)
  state.hand_size_play_target = data.get("hand_size_play_target", 0)
  state.kingslayer_spent = data.get("kingslayer_spent", False)
  state.kingslayer_armed = data.get("kingslayer_armed", False)
  state.kingslayer_finale_steps = [
    _step_from_dict(s) for s in data.get("kingslayer_finale_steps", [])
  ]
  state.kyungcheon_chip = data.get("kyungcheon_chip", 0)
  state.kyungcheon_mult = data.get("kyungcheon_mult", 0)
  state.coward_club_spent = data.get("coward_club_spent", False)
  state.jiri_blade_spent = data.get("jiri_blade_spent", False)
  state.rosary_revive = data.get("rosary_revive", False)
  state.national_revive = data.get("national_revive", False)
  state._jaw_draw_msg = None
  state._reward_cleared_stage = 0
  state._artifact_reward_done = False
  state.sync_hand_slots()
  return state


def apply_save_to_state(state: GameState, data: dict[str, Any]) -> None:
  loaded = deserialize_state(data)
  skip = {"_jaw_draw_msg", "_reward_cleared_stage", "_artifact_reward_done"}
  for f in fields(GameState):
    if f.name in skip:
      continue
    setattr(state, f.name, getattr(loaded, f.name))


def has_saved_game() -> bool:
  raw = _storage_read()
  if not raw:
    return False
  try:
    data = json.loads(raw)
    return data.get("version") == SAVE_VERSION and data.get("phase") not in (
      Phase.MAIN_MENU.name,
      Phase.GAME_OVER.name,
    )
  except Exception:
    return False


def load_saved_game() -> GameState | None:
  raw = _storage_read()
  if not raw:
    return None
  try:
    data = json.loads(raw)
    state = deserialize_state(data)
    if not can_persist_state(state):
      return None
    return state
  except Exception:
    return None


def save_game_state(state: GameState) -> bool:
  if not can_persist_state(state):
    return False
  try:
    payload = json.dumps(serialize_state(state), ensure_ascii=False, separators=(",", ":"))
    return _storage_write(payload)
  except Exception:
    return False


def clear_saved_game() -> None:
  _storage_delete()


# --- 랭킹/기록 (저장 데이터와 독립적으로 영구 보존) ---

def _empty_records() -> dict[str, Any]:
  return {
    "version": RECORDS_VERSION,
    "player_name": "",
    "device_id": "",
    "best_stage": 0,
    "best_damage": 0,
    "runs": [],
  }


def load_records() -> dict[str, Any]:
  raw = _kv_read(RECORDS_KEY, _records_path())
  if not raw:
    return _empty_records()
  try:
    data = json.loads(raw)
    if not isinstance(data, dict):
      return _empty_records()
    base = _empty_records()
    base["player_name"] = str(data.get("player_name", "") or "")[:16]
    base["device_id"] = str(data.get("device_id", "") or "")
    base["best_stage"] = int(data.get("best_stage", 0) or 0)
    base["best_damage"] = int(data.get("best_damage", 0) or 0)
    runs = data.get("runs", [])
    clean: list[dict[str, Any]] = []
    if isinstance(runs, list):
      for r in runs:
        if not isinstance(r, dict):
          continue
        clean.append({
          "id": str(r.get("id", "") or ""),
          "stage": int(r.get("stage", 0) or 0),
          "damage": int(r.get("damage", 0) or 0),
          "wins": int(r.get("wins", 0) or 0),
          "synced": bool(r.get("synced", False)),
        })
    base["runs"] = clean
    return base
  except Exception:
    return _empty_records()


def save_records(data: dict[str, Any]) -> bool:
  try:
    payload = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    return _kv_write(RECORDS_KEY, _records_path(), payload)
  except Exception:
    return False


def record_best(stage: int | None = None, damage: int | None = None) -> None:
  """최고 스테이지/데미지를 갱신. 신기록일 때만 저장한다."""
  data = load_records()
  changed = False
  if stage is not None and stage > data["best_stage"]:
    data["best_stage"] = int(stage)
    changed = True
  if damage is not None and damage > data["best_damage"]:
    data["best_damage"] = int(damage)
    changed = True
  if changed:
    save_records(data)


def record_run(stage: int, damage: int, wins: int) -> None:
  """런 종료 시 결과를 랭킹 목록에 추가하고 상위 기록만 유지한다."""
  import time
  import uuid
  data = load_records()
  data["runs"].append({
    "id": f"{int(time.time() * 1000)}-{uuid.uuid4().hex[:8]}",
    "stage": int(stage),
    "damage": int(damage),
    "wins": int(wins),
    "synced": False,
  })
  data["runs"].sort(key=lambda r: (r["stage"], r["damage"], r["wins"]), reverse=True)
  data["runs"] = data["runs"][:RECORDS_MAX_RUNS]
  if stage > data["best_stage"]:
    data["best_stage"] = int(stage)
  if damage > data["best_damage"]:
    data["best_damage"] = int(damage)
  save_records(data)


def clear_records() -> None:
  _kv_delete(RECORDS_KEY, _records_path())
