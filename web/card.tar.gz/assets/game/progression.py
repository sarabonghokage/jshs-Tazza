"""스테이지 보상 — 타로 획득 주기와 강화 수치."""

from __future__ import annotations

from game.constants import DECK_MAX, DECK_MIN

# 홀수 스테이지 클리어 시 새 타로 3택1, 짝수 스테이지는 강화 선택
def is_tarot_reward_stage(stage: int) -> bool:
  return stage % 2 == 1


# 아티팩트 보상 스테이지 — 짝수마다이나 4·14·24… 스테이지는 제외 (아주 약간 감소)
def is_artifact_reward_stage(stage: int) -> bool:
  return stage > 0 and stage % 2 == 0 and stage % 10 != 4


def stage_kind(stage: int) -> str:
  """normal | jaw | well"""
  if stage > 0 and stage % 5 == 0:
    return "jaw"
  if stage > 0 and stage % 4 == 0:
    return "well"
  return "normal"


def enemy_archetype(stage: int) -> str:
  """normal | fortress(고체력) | blitz(1턴 압박)"""
  if stage < 4:
    return "normal"
  if stage % 5 == 3:
    return "fortress"
  if stage >= 7 and stage % 4 == 3:
    return "blitz"
  return "normal"


def stage_display_name(stage: int, kind: str | None = None, archetype: str = "normal") -> str:
  k = kind or stage_kind(stage)
  if k == "jaw":
    return f"턱 Lv.{stage}"
  if k == "well":
    return f"우물 Lv.{stage}"
  if archetype == "fortress":
    return f"요새 Lv.{stage}"
  if archetype == "blitz":
    return f"맹습 Lv.{stage}"
  return f"그림자 Lv.{stage}"


TAROT_REWARD_CHOICES = 3
HAND_UPGRADE_AMOUNT = 3
TAROT_UPGRADE_CHIP_PER_LEVEL = 5
JAW_MARKS_PER_STAGE = 2
WELL_DISCARD_COUNT = 2
WELL_GAIN_COUNT = 2
WELL_GAIN_OFFER_SIZE = 5

# 강화 선택 UI에 표시할 족보 (희귀도 순)
UPGRADEABLE_HANDS = (
  "pair", "two_pair", "three_kind", "straight", "flush", "full_house",
  "three_pair", "four_pair", "straight_plus", "flush_plus", "four_kind", "double_triple",
  "octa_triple", "quad_double",
  "straight_flush", "dragon", "leviathan", "rainbow", "spectrum", "royal_flush",
)
