from __future__ import annotations

import random
from dataclasses import dataclass, field
from enum import Enum, auto

from game.card import Card, TarotCard
from game.artifacts import (
  ARTIFACT_REWARD_CHOICES,
  STARTING_ARTIFACT_OFFER,
  get_artifact,
  random_artifact_offers,
)
from game.artifact_effects import apply_artifact_turn_start
from game.artifact_runtime import (
  alchemy_enabled,
  draw_pick_count,
  effective_max_tarot_held,
  has_artifact,
  indulgence_discard_count,
  jaw_marks_per_stage,
  on_artifact_acquired,
  opening_deal_count,
  strip_all_jaw_marks,
  total_essence_count,
)
from game.alchemy import (
  ESSENCE_LABELS,
  Essence,
  aggregate_item_stacks,
  get_item,
  random_essence_drop,
  resolve_recipe,
)
from game.constants import HAND_SIZE, MAX_TAROT_HELD, MAX_TAROT_USES, enemy_max_hp, enemy_turn_limit
from game.deck import DeckManager
from game.modifiers import PlayModifiers
from game.progression import (
  HAND_UPGRADE_AMOUNT,
  JAW_MARKS_PER_STAGE,
  TAROT_REWARD_CHOICES,
  WELL_DISCARD_COUNT,
  WELL_GAIN_COUNT,
  WELL_GAIN_OFFER_SIZE,
  is_artifact_reward_stage,
  is_tarot_reward_stage,
  stage_display_name,
  stage_kind,
)
from game.jaws import JAW_STAGE_CARD_POOL, random_jaw_offers
from game.jaw_effects import on_jaw_card_drawn, prepare_belial_hand
from game.joker import joker_needs_transform, roll_joker_on_draw, transform_joker
from game.tarot import (
  create_tarot,
  play_tarot_as_card,
  random_starter_choices,
)
from game.tarot_effects import (
  apply_hermit_suit,
  apply_temperance_suit,
  apply_tarot_enhance,
  finish_wheel,
  reroll_wheel_card,
)


class Phase(Enum):
  MAIN_MENU = auto()
  RECORDS = auto()
  TAROT_PICK = auto()
  BAN_SELECT = auto()
  DRAW_PICK = auto()
  FILL_HAND = auto()
  SCORE = auto()
  BATTLE_RESULT = auto()
  TAROT_REWARD = auto()
  ARTIFACT_REWARD = auto()
  UPGRADE_SELECT = auto()
  WELL_STAGE = auto()
  JAW_STAGE = auto()
  GAME_OVER = auto()


class SubPhase(Enum):
  NONE = auto()
  PICK_FIVE = auto()
  RANK_PICK_TARGET = auto()
  RANK_PICK_VALUE = auto()
  WHEEL_REROLL = auto()
  DEATH_PICK_THREE = auto()
  MOON_PICK_HAND = auto()
  MOON_PICK_DISCARD = auto()
  MOON_PICK_DRAW = auto()
  HERMIT_SUIT = auto()
  TEMPERANCE_SUIT = auto()
  TEMPERANCE_OFFER = auto()
  JUSTICE_PICK_SOURCE = auto()
  JOKER_TRANSFORM = auto()
  JOKER_FOOL_PICK = auto()
  PRIESTESS_PICK = auto()
  JAW_PICK_CARD = auto()
  JAW_PICK_JAW = auto()
  JAW_FANG_PICK = auto()
  JAW_MICHAEL_SEAL = auto()
  WELL_GAIN_PICK = auto()
  ACOLYTE_PICK = auto()
  JIRI_DECK_PICK = auto()


@dataclass
class Enemy:
  name: str
  max_hp: int
  hp: int
  stage: int
  kind: str = "normal"
  max_turns: int = 0
  archetype: str = "normal"


@dataclass
class GameState:
  phase: Phase = Phase.MAIN_MENU
  sub_phase: SubPhase = SubPhase.NONE
  deck: DeckManager = field(default_factory=DeckManager)
  hand: list[Card | None] = field(default_factory=lambda: [None] * HAND_SIZE)
  max_hand_slots: int = HAND_SIZE
  opening_five: list[Card] = field(default_factory=list)
  ban_selection: list[int] = field(default_factory=list)
  draw_three: list[Card] = field(default_factory=list)
  pick_pool: list[Card] = field(default_factory=list)
  tarots: list[TarotCard] = field(default_factory=list)
  tarot_uses_left: int = MAX_TAROT_USES
  used_tarot_uids: set[int] = field(default_factory=set)
  pending_tarot: TarotCard | None = None
  tarot_mode: str | None = None
  enemy: Enemy = field(default_factory=lambda: Enemy("적", 80, 80, 1))
  last_score: dict | None = None
  score_reveal_steps: list = field(default_factory=list)
  score_damage_applied: bool = False
  message: str = ""
  tarot_uid_counter: int = 0
  wins: int = 0
  starter_tarot_choices: list[TarotCard] = field(default_factory=list)
  reward_tarot_choices: list[TarotCard] = field(default_factory=list)
  hand_bonuses: dict[str, int] = field(default_factory=dict)
  modifiers: PlayModifiers = field(default_factory=PlayModifiers)
  hanged_man_cooldown: int = 0
  joker_pending: Card | None = None
  joker_target_slot: int | None = None
  joker_draw_face: int | None = None
  fool_rerolls_left: int = 0
  fool_pick_slots: list[int] = field(default_factory=list)
  jaw_offers: list[str] = field(default_factory=list)
  jaw_card_pool: list[Card] = field(default_factory=list)
  jaw_picked_card_index: int | None = None
  jaw_picked_offer_index: int | None = None
  sealed_tarot_uids: set[int] = field(default_factory=set)
  jaw_fang_quota: int = 0
  jaw_fang_picks: list[int] = field(default_factory=list)
  jaw_fang_card: Card | None = None
  jaw_pending_card: Card | None = None
  jaw_score_ctx: object | None = None
  jaw_marks_remaining: int = 0
  live_hand_tier: int = 0
  live_hand_label: str = ""
  live_best_indices: tuple[int, ...] = ()
  temperance_index: int | None = None
  temperance_rerolls: int = 0
  temperance_pending_card: Card | None = None
  temperance_suit: str | None = None
  temperance_draws_remaining: int = 0
  priestess_passes_remaining: int = 0
  justice_anchor_index: int | None = None
  strength_allow_suit: bool = False
  rank_change_source: int | None = None
  rank_change_target: int | None = None
  strength_rank: int = 2
  strength_suit: str = "hearts"
  wheel_index: int | None = None
  wheel_rolls: int = 0
  hermit_peek: list[Card] = field(default_factory=list)
  hermit_level: int = 0
  next_draw_preview: list[Card] = field(default_factory=list)
  _jaw_draw_msg: str | None = None
  moon_discard_picks: list[int] = field(default_factory=list)
  moon_hand_picks: list[int] = field(default_factory=list)
  death_picks: list[int] = field(default_factory=list)
  battle_turn: int = 0
  discard_scroll: int = 0
  well_discard_remaining: int = 0
  well_gain_remaining: int = 0
  well_deck_scroll: int = 0
  essence_salt: int = 0
  essence_sulfur: int = 0
  essence_mercury: int = 0
  alchemy_slots: list[str | None] = field(default_factory=lambda: [None, None, None])
  item_stacks: dict[str, int] = field(default_factory=dict)
  last_essence_drop: str | None = None
  artifact_stacks: dict[str, int] = field(default_factory=dict)
  artifact_reward_choices: list[str] = field(default_factory=list)
  starter_pick_pending: int | None = None
  reward_pick_pending: int | None = None
  artifact_pick_pending: int | None = None
  upgrade_tab: str = "tarot"
  upgrade_tarot_pending: int | None = None
  upgrade_hand_pending: str | None = None
  shackle_tarot_uses: dict[int, int] = field(default_factory=dict)
  jaw_offer_rerolled: list[int] = field(default_factory=list)
  resting_mult_bonus: int = 0
  compressed_head_used: bool = False
  hand_size_play_target: int = 0
  kingslayer_spent: bool = False
  kingslayer_armed: bool = False
  kingslayer_finale_steps: list = field(default_factory=list)
  _reward_cleared_stage: int = 0
  _artifact_reward_done: bool = False
  kyungcheon_chip: int = 0
  kyungcheon_mult: int = 0
  coward_club_spent: bool = False
  jiri_blade_spent: bool = False
  rosary_revive: bool = False
  national_revive: bool = False
  run_max_damage: int = 0
  records_tab: str = "local"
  records_global_sort: str = "stage"
  name_editing: bool = False
  name_edit_buffer: str = ""

  def sync_hand_slots(self) -> None:
    from game.hand_size import resolve_hand_slots
    self.max_hand_slots = resolve_hand_slots(
      self.artifact_stacks, play_target=self.hand_size_play_target,
    )
    self._resize_hand()

  def can_use_kingslayer(self) -> bool:
    return (
      has_artifact(self.artifact_stacks, "kingslayer_sword")
      and not self.kingslayer_spent
      and self.phase == Phase.FILL_HAND
    )

  def toggle_kingslayer(self) -> bool:
    if not has_artifact(self.artifact_stacks, "kingslayer_sword"):
      return False
    if self.kingslayer_armed:
      self.kingslayer_armed = False
      self.message = "왕을 죽이는 검 — 해제"
      return True
    if self.kingslayer_spent:
      self.message = "왕을 죽이는 검 — 이번 스테이지 사용 완료"
      return False
    if self.pending_tarot:
      self.cancel_tarot()
    self.kingslayer_armed = True
    self.message = "왕을 죽이는 검 — 일반 합산 후 검격 발동"
    return True

  def _game_over(self, message: str = "턴이 다했습니다!") -> None:
    if (
      has_artifact(self.artifact_stacks, "rosary")
      and self.rosary_revive
      and self._is_combat_enemy()
    ):
      self.rosary_revive = False
      self.artifact_stacks.pop("rosary", None)
      self.battle_turn = 0
      self.enemy.hp = self.enemy.max_hp
      self.start_new_play(decrement_cooldown=False)
      if self.phase != Phase.GAME_OVER:
        self.message = "묵주 — 이번 적과 재전투! (묵주 소멸)"
      return
    if (
      has_artifact(self.artifact_stacks, "national_tournament")
      and self.national_revive
      and self._is_combat_enemy()
    ):
      self.national_revive = False
      self.battle_turn = 0
      self.enemy.hp = self.enemy.max_hp
      self.start_new_play(decrement_cooldown=False)
      if self.phase != Phase.GAME_OVER:
        self.message = "전국 타짜 평정장 — 부활!"
      return
    if (
      has_artifact(self.artifact_stacks, "compressed_head")
      and not self.compressed_head_used
      and self._is_combat_enemy()
    ):
      self.compressed_head_used = True
      strip_all_jaw_marks(self)
      self.battle_turn = 0
      self.start_new_play(decrement_cooldown=False)
      if self.phase != Phase.GAME_OVER:
        self.message = "압축된 머리 — 모든 이빨 자국을 잃고 부활!"
      return
    self.phase = Phase.GAME_OVER
    self.sub_phase = SubPhase.NONE
    self.pending_tarot = None
    self.tarot_mode = None
    self.message = message
    try:
      from game.persistence import record_run
      record_run(self.enemy.stage, self.run_max_damage, self.wins)
    except Exception:
      pass
    from game.persistence import clear_saved_game
    clear_saved_game()

  def pull_card(self, *, allow_joker: bool = True) -> Card | None:
    if (
      has_artifact(self.artifact_stacks, "blood_horn")
      and self.phase == Phase.FILL_HAND
      and self.deck.deck
    ):
      self._blood_horn_side_discard()
    deferred_jokers: list[Card] = []
    while True:
      card = self.deck.draw()
      if card is None:
        for joker in deferred_jokers:
          self.deck.deck.append(joker)
        if deferred_jokers:
          self.deck.shuffle()
        return None
      if card.is_joker_card and not allow_joker:
        deferred_jokers.append(card)
        if not self.deck.deck and not self.deck.discard:
          self.deck.replenish_from_banned()
        if not self.deck.deck and not self.deck.discard:
          for joker in deferred_jokers:
            self.deck.deck.append(joker)
          self.deck.shuffle()
          return None
        continue
      for joker in deferred_jokers:
        self.deck.deck.append(joker)
      if deferred_jokers:
        self.deck.shuffle()
      return card

  def pull_many(self, count: int, *, allow_joker: bool = True) -> list[Card]:
    cards: list[Card] = []
    for _ in range(count):
      card = self.pull_card(allow_joker=allow_joker)
      if card is None:
        break
      cards.append(card)
    return cards

  def show_main_menu(self) -> None:
    self.phase = Phase.MAIN_MENU
    self.sub_phase = SubPhase.NONE
    self.pending_tarot = None
    self.tarot_mode = None
    self.message = ""

  def show_records(self) -> None:
    self.phase = Phase.RECORDS
    self.sub_phase = SubPhase.NONE
    self.pending_tarot = None
    self.tarot_mode = None
    self.message = ""
    self.records_tab = "local"
    self.name_editing = False
    from game.leaderboard import get_player_name
    self.name_edit_buffer = get_player_name()

  def save_progress(self) -> bool:
    from game.persistence import save_game_state
    return save_game_state(self)

  def continue_from_save(self) -> bool:
    from dataclasses import fields
    from game.persistence import load_saved_game
    loaded = load_saved_game()
    if loaded is None:
      self.message = "저장된 진행이 없습니다."
      return False
    skip = {"_jaw_draw_msg", "_reward_cleared_stage", "_artifact_reward_done"}
    for f in fields(GameState):
      if f.name in skip:
        continue
      setattr(self, f.name, getattr(loaded, f.name))
    self.message = "이어서 플레이합니다."
    return True

  def begin_run(self) -> None:
    from game.persistence import clear_saved_game
    clear_saved_game()
    self.hand_bonuses = {}
    self._reset_alchemy()
    self.artifact_stacks = {}
    self.artifact_reward_choices = []
    self.tarot_uid_counter = 0
    self.discard_scroll = 0
    self.sealed_tarot_uids = set()
    self.kyungcheon_chip = 0
    self.kyungcheon_mult = 0
    self.rosary_revive = False
    self.national_revive = False
    self.start_game()

  def restart_game(self) -> None:
    self.begin_run()

  def _reset_alchemy(self) -> None:
    self.essence_salt = 0
    self.essence_sulfur = 0
    self.essence_mercury = 0
    self.alchemy_slots = [None, None, None]
    self.item_stacks = {}
    self.last_essence_drop = None

  def alchemy_bonuses(self):
    return aggregate_item_stacks(self.item_stacks)

  def _essence_amount(self, essence: Essence) -> int:
    if essence == Essence.SALT:
      return self.essence_salt
    if essence == Essence.SULFUR:
      return self.essence_sulfur
    return self.essence_mercury

  def _add_essence(self, essence: Essence, delta: int) -> None:
    if essence == Essence.SALT:
      self.essence_salt = max(0, self.essence_salt + delta)
    elif essence == Essence.SULFUR:
      self.essence_sulfur = max(0, self.essence_sulfur + delta)
    else:
      self.essence_mercury = max(0, self.essence_mercury + delta)

  def _drop_essence_on_kill(self) -> str:
    drop = random_essence_drop()
    self._add_essence(drop, 1)
    if has_artifact(self.artifact_stacks, "ether"):
      for e in Essence:
        self._add_essence(e, 4)
    self.last_essence_drop = drop.value
    return f"원소 획득: {ESSENCE_LABELS[drop]}"

  def alchemy_add_essence(self, essence_str: str) -> bool:
    if not alchemy_enabled(self.artifact_stacks):
      self.message = "연금술을 사용할 수 없습니다."
      return False
    try:
      essence = Essence(essence_str)
    except ValueError:
      return False
    if self._essence_amount(essence) <= 0:
      return False
    if None not in self.alchemy_slots:
      self.message = "연성 슬롯이 가득 찼습니다."
      return False
    slot = self.alchemy_slots.index(None)
    self._add_essence(essence, -1)
    self.alchemy_slots[slot] = essence.value
    return True

  def alchemy_return_slot(self, index: int) -> bool:
    if index < 0 or index >= len(self.alchemy_slots):
      return False
    val = self.alchemy_slots[index]
    if not val:
      return False
    try:
      essence = Essence(val)
    except ValueError:
      self.alchemy_slots[index] = None
      return False
    self._add_essence(essence, 1)
    self.alchemy_slots[index] = None
    return True

  def alchemy_clear_slots(self) -> None:
    for i in range(len(self.alchemy_slots)):
      self.alchemy_return_slot(i)

  def alchemy_transmute(self) -> bool:
    if not alchemy_enabled(self.artifact_stacks):
      self.message = "연금술을 사용할 수 없습니다."
      return False
    if not all(s is not None for s in self.alchemy_slots):
      self.message = "슬롯 3개를 모두 채워 연성하세요."
      return False
    recipe_id = resolve_recipe(self.alchemy_slots)
    if not recipe_id:
      self.alchemy_clear_slots()
      self.message = "불안정한 혼합… 원소가 흩어졌습니다."
      return False
    item = get_item(recipe_id)
    self.alchemy_slots = [None, None, None]
    self.item_stacks[recipe_id] = self.item_stacks.get(recipe_id, 0) + 1
    self.message = f"연성 성공: {item.name} — {item.effect_summary}"
    return True

  def begin_tarot_pick(self) -> None:
    numbers = random_starter_choices(3)
    self.starter_tarot_choices = [create_tarot(n, self._next_tarot_uid()) for n in numbers]
    self.starter_pick_pending = None
    self.phase = Phase.TAROT_PICK
    self.message = "시작 타로 3장 중 1장을 선택하세요."

  def pick_starter_tarot(self, index: int) -> bool:
    if self.phase != Phase.TAROT_PICK or index >= len(self.starter_tarot_choices):
      return False
    chosen = self.starter_tarot_choices[index]
    self.tarots = [chosen]
    self.starter_tarot_choices = []
    self.starter_pick_pending = None
    self.start_new_play()
    if self.phase == Phase.GAME_OVER:
      return True
    if has_artifact(self.artifact_stacks, "indulgence"):
      n = opening_deal_count(self.artifact_stacks)
      d = indulgence_discard_count(self.artifact_stacks)
      self.message = f"{chosen.name} 선택! {n}장 중 {d}장을 묘지로 보내세요."
    else:
      self.message = f"{chosen.name} 선택! 5장 중 2장을 밴하세요."
    return True

  def select_starter_tarot(self, index: int) -> bool:
    if self.phase != Phase.TAROT_PICK or index >= len(self.starter_tarot_choices):
      return False
    self.starter_pick_pending = None if self.starter_pick_pending == index else index
    return True

  def confirm_starter_tarot(self) -> bool:
    if self.starter_pick_pending is None:
      return False
    return self.pick_starter_tarot(self.starter_pick_pending)

  def cancel_starter_pick(self) -> None:
    self.starter_pick_pending = None

  def begin_tarot_reward(self) -> None:
    if len(self.tarots) >= effective_max_tarot_held(self.artifact_stacks):
      self.begin_upgrade_select("타로 슬롯이 가득 차 강화만 선택할 수 있습니다.")
      return
    owned = {t.number for t in self.tarots}
    pool = [n for n in range(2, 21) if n not in owned]
    if not pool:
      self.begin_upgrade_select("모든 타로를 보유 중입니다. 강화를 선택하세요.")
      return
    count = min(TAROT_REWARD_CHOICES, len(pool))
    import random
    numbers = random.sample(pool, count)
    self.reward_tarot_choices = [create_tarot(n, self._next_tarot_uid()) for n in numbers]
    self.reward_pick_pending = None
    self.phase = Phase.TAROT_REWARD
    self.message = f"스테이지 {self.enemy.stage} 클리어! 새 타로 {count}장 중 1장을 선택하세요."

  def pick_reward_tarot(self, index: int) -> bool:
    if self.phase != Phase.TAROT_REWARD or index >= len(self.reward_tarot_choices):
      return False
    chosen = self.reward_tarot_choices[index]
    self.tarots.append(chosen)
    self.reward_tarot_choices = []
    self.reward_pick_pending = None
    self.message = f"{chosen.name} 획득!"
    self._finish_reward_and_advance()
    return True

  def select_reward_tarot(self, index: int) -> bool:
    if self.phase != Phase.TAROT_REWARD or index >= len(self.reward_tarot_choices):
      return False
    self.reward_pick_pending = None if self.reward_pick_pending == index else index
    return True

  def confirm_reward_tarot(self) -> bool:
    if self.reward_pick_pending is None:
      return False
    return self.pick_reward_tarot(self.reward_pick_pending)

  def cancel_reward_pick(self) -> None:
    self.reward_pick_pending = None

  def begin_upgrade_select(self, message: str | None = None) -> None:
    self.phase = Phase.UPGRADE_SELECT
    self.upgrade_tab = "tarot"
    self.upgrade_tarot_pending = None
    self.upgrade_hand_pending = None
    self.message = message or f"스테이지 {self.enemy.stage} 클리어! 타로 또는 족보를 강화하세요."

  def set_upgrade_tab(self, tab: str) -> None:
    if tab not in ("tarot", "hand"):
      return
    self.upgrade_tab = tab
    self.upgrade_tarot_pending = None
    self.upgrade_hand_pending = None

  def select_upgrade_tarot(self, uid: int) -> bool:
    if self.phase != Phase.UPGRADE_SELECT:
      return False
    from game.tarot_data import get_tarot_def
    for tarot in self.tarots:
      if tarot.uid == uid:
        if tarot.upgrade_level >= get_tarot_def(tarot.number).max_level:
          self.message = f"{tarot.name}은(는) 이미 최대 강화입니다."
          return False
        break
    self.upgrade_tarot_pending = None if self.upgrade_tarot_pending == uid else uid
    self.upgrade_hand_pending = None
    return True

  def select_upgrade_hand(self, hand_name: str) -> bool:
    if self.phase != Phase.UPGRADE_SELECT:
      return False
    self.upgrade_hand_pending = None if self.upgrade_hand_pending == hand_name else hand_name
    self.upgrade_tarot_pending = None
    return True

  def confirm_upgrade_pick(self) -> bool:
    if self.upgrade_tarot_pending is not None:
      return self.upgrade_tarot(self.upgrade_tarot_pending)
    if self.upgrade_hand_pending is not None:
      return self.upgrade_hand(self.upgrade_hand_pending)
    return False

  def cancel_upgrade_pick(self) -> None:
    self.upgrade_tarot_pending = None
    self.upgrade_hand_pending = None

  def upgrade_tarot(self, uid: int) -> bool:
    if self.phase != Phase.UPGRADE_SELECT:
      return False
    from game.tarot_data import get_tarot_def
    for tarot in self.tarots:
      if tarot.uid == uid:
        max_lv = get_tarot_def(tarot.number).max_level
        if tarot.upgrade_level >= max_lv:
          self.message = f"{tarot.name}은(는) 이미 최대 강화(Lv.{max_lv})입니다."
          return False
        tarot.upgrade_level += 1
        self.message = f"{tarot.name} Lv.{tarot.upgrade_level}/{max_lv} 강화!"
        self._finish_reward_and_advance()
        return True
    return False

  def upgrade_hand(self, hand_name: str) -> bool:
    if self.phase != Phase.UPGRADE_SELECT:
      return False
    from game.constants import HAND_LABELS_KO
    self.hand_bonuses[hand_name] = self.hand_bonuses.get(hand_name, 0) + HAND_UPGRADE_AMOUNT
    label = HAND_LABELS_KO.get(hand_name, hand_name)
    bonus = self.hand_bonuses[hand_name]
    self.message = f"{label} 배수 +{bonus} 강화!"
    self._finish_reward_and_advance()
    return True

  def _begin_stage_after_special(self) -> None:
    """보상·특수 스테이지 통과 후 다음 스테이지 진입."""
    if self.enemy.kind == "well":
      self._begin_well_stage()
      return
    if self.enemy.kind == "jaw":
      self._begin_jaw_stage()
      return
    self.start_new_play()
    if self.phase == Phase.GAME_OVER:
      return
    arch = self.enemy.archetype
    arch_txt = ""
    if arch == "fortress":
      arch_txt = " [요새·고체력]"
    elif arch == "blitz":
      arch_txt = " [맹습·1턴]"
    if has_artifact(self.artifact_stacks, "indulgence"):
      n = opening_deal_count(self.artifact_stacks)
      d = indulgence_discard_count(self.artifact_stacks)
      self.message = (
        f"스테이지 {self.enemy.stage}{arch_txt} (HP {self.enemy.max_hp:,}, "
        f"턴 {self.enemy.max_turns}회) — {n}장 중 {d}장을 묘지로"
      )
    else:
      self.message = (
        f"스테이지 {self.enemy.stage}{arch_txt} (HP {self.enemy.max_hp:,}, "
        f"턴 {self.enemy.max_turns}회) — 5장 중 2장을 밴하세요."
      )

  def _finish_reward_and_advance(self) -> None:
    cleared = self.enemy.stage
    next_stage = cleared + 1
    if has_artifact(self.artifact_stacks, "jeolla_angler") and cleared % 3 == 0:
      next_stage += 1
      self.message = f"전라도 아귀 — 스테이지 {next_stage - 1} 전투 스킵!"
    self._spawn_enemy(next_stage, preserve_deck=True)
    self._begin_stage_after_special()

  def _begin_reward_after_kill(self) -> None:
    self._reward_cleared_stage = self.enemy.stage
    self._artifact_reward_done = False
    self._continue_kill_reward_chain()

  def _continue_kill_reward_chain(self) -> None:
    stage = self._reward_cleared_stage
    if not self._artifact_reward_done and is_artifact_reward_stage(stage):
      self._artifact_reward_done = True
      if self._try_begin_artifact_reward():
        return
    if is_tarot_reward_stage(stage):
      self.begin_tarot_reward()
    else:
      self.begin_upgrade_select()

  def _tarot_number_set(self) -> set[int]:
    return {t.number for t in self.tarots}

  def _try_begin_artifact_reward(self) -> bool:
    """처치 보상용 유물 선택 — 제시할 유물이 있으면 True."""
    offers = random_artifact_offers(
      self.artifact_stacks, ARTIFACT_REWARD_CHOICES,
      tarot_numbers=self._tarot_number_set(),
    )
    if not offers:
      return False
    self.artifact_reward_choices = offers
    self.artifact_pick_pending = None
    self.phase = Phase.ARTIFACT_REWARD
    self.sub_phase = SubPhase.NONE
    self.message = "유물 보상 — 하나를 선택하세요"
    return True

  def begin_starting_artifact_reward(self) -> None:
    offers = random_artifact_offers(
      self.artifact_stacks, ARTIFACT_REWARD_CHOICES,
      tarot_numbers=self._tarot_number_set(),
    )
    if not offers:
      self.begin_tarot_pick()
      return
    self.artifact_reward_choices = offers
    self.artifact_pick_pending = None
    self.phase = Phase.ARTIFACT_REWARD
    self.message = "런 시작 — 유물 하나를 선택하세요 (이번 런에만 적용)"

  def begin_artifact_reward(self) -> None:
    """레거시 호환 — 현재는 런 시작 시에만 유물을 제공한다."""
    self.begin_starting_artifact_reward()

  def pick_artifact(self, index: int) -> bool:
    if self.phase != Phase.ARTIFACT_REWARD or index >= len(self.artifact_reward_choices):
      return False
    aid = self.artifact_reward_choices[index]
    defn = get_artifact(aid)
    self.artifact_stacks[aid] = self.artifact_stacks.get(aid, 0) + 1
    self.artifact_reward_choices = []
    self.artifact_pick_pending = None
    on_artifact_acquired(self, aid)
    self.message = f"유물 획득: {defn.name}"
    if not self.tarots:
      self.begin_tarot_pick()
    else:
      self._continue_kill_reward_chain()
    return True

  def select_artifact(self, index: int) -> bool:
    if self.phase != Phase.ARTIFACT_REWARD or index >= len(self.artifact_reward_choices):
      return False
    self.artifact_pick_pending = None if self.artifact_pick_pending == index else index
    return True

  def confirm_artifact_pick(self) -> bool:
    if self.artifact_pick_pending is None:
      return False
    return self.pick_artifact(self.artifact_pick_pending)

  def cancel_artifact_pick(self) -> None:
    self.artifact_pick_pending = None

  def _reset_play_fields(self) -> None:
    self.sub_phase = SubPhase.NONE
    self.modifiers.reset()
    self.temperance_index = None
    self.temperance_rerolls = 0
    self.temperance_pending_card = None
    self.temperance_suit = None
    self.temperance_draws_remaining = 0
    self.priestess_passes_remaining = 0
    self.justice_anchor_index = None
    self.strength_allow_suit = False
    self.resting_mult_bonus = 0
    self.shackle_tarot_uses = {}
    self.rank_change_source = None
    self.rank_change_target = None
    self.wheel_index = None
    self.wheel_rolls = 0
    self.hermit_peek = []
    self.next_draw_preview = []
    self.moon_discard_picks = []
    self.moon_hand_picks = []
    self.death_picks = []
    self.pick_pool = []
    self.joker_pending = None
    self.joker_target_slot = None
    self.joker_draw_face = None
    self.fool_rerolls_left = 0
    self.fool_pick_slots = []
    self.jaw_offers = []
    self.jaw_card_pool = []
    self.jaw_picked_card_index = None
    self.jaw_picked_offer_index = None
    self.jaw_fang_quota = 0
    self.jaw_fang_picks = []
    self.jaw_fang_card = None
    self.jaw_pending_card = None
    self.jaw_score_ctx = None
    self.jaw_marks_remaining = 0
    self.hand_size_play_target = 0
    self.live_hand_tier = 0
    self.live_hand_label = ""
    self.live_best_indices = ()
    self.sync_hand_slots()

  def _is_combat_enemy(self) -> bool:
    return self.enemy.kind == "normal" and self.enemy.max_turns > 0

  def _turns_remaining(self) -> int:
    if not self._is_combat_enemy():
      return 0
    return max(0, self.enemy.max_turns - self.battle_turn)

  def _check_turn_limit_exceeded(self) -> bool:
    if self._is_combat_enemy() and self.battle_turn >= self.enemy.max_turns:
      self._game_over(
        f"턴 제한 {self.enemy.max_turns}회를 모두 소모했습니다! "
        f"(스테이지 {self.enemy.stage})"
      )
      return True
    return False

  def start_new_play(self, decrement_cooldown: bool = True) -> None:
    if self._check_turn_limit_exceeded():
      return
    if decrement_cooldown and self.hanged_man_cooldown > 0:
      self.hanged_man_cooldown -= 1
    self.battle_turn += 1
    self._reset_play_fields()
    self.hand = [None] * self.max_hand_slots
    self.ban_selection = []
    self.draw_three = []
    self.tarot_uses_left = MAX_TAROT_USES + self.alchemy_bonuses().tarot_uses
    if has_artifact(self.artifact_stacks, "rosary"):
      self.tarot_uses_left += 1
    if has_artifact(self.artifact_stacks, "national_tournament"):
      self.tarot_uses_left += 1
    self.used_tarot_uids.clear()
    self.pending_tarot = None
    self.tarot_mode = None
    self.last_score = None
    self._begin_opening_deal()
    apply_artifact_turn_start(self)
    self._refresh_twin_ghost_preview()

  def _refresh_twin_ghost_preview(self) -> None:
    if not has_artifact(self.artifact_stacks, "gyeongsang_twin_ghost"):
      return
    if self.phase != Phase.FILL_HAND:
      return
    peeked = self.deck.peek_many(1)
    self.next_draw_preview = peeked

  def begin_jiri_pick(self) -> bool:
    if (
      not has_artifact(self.artifact_stacks, "jiri_blade")
      or self.jiri_blade_spent
      or self.phase != Phase.FILL_HAND
      or self.sub_phase != SubPhase.NONE
      or self.is_hand_full()
    ):
      return False
    if not self.deck.deck:
      self.message = "덱에 카드가 없습니다."
      return False
    self.pick_pool = self.deck.peek_many(min(5, len(self.deck.deck)))
    self.sub_phase = SubPhase.JIRI_DECK_PICK
    self.message = "지리산 작두 — 덱 위 카드 중 1장 선택"
    return True

  def jiri_pick_card(self, index: int) -> bool:
    if self.sub_phase != SubPhase.JIRI_DECK_PICK or index >= len(self.pick_pool):
      return False
    chosen = self.pick_pool[index]
    key = chosen.card_key()
    for i, c in enumerate(self.deck.deck):
      if c.card_key() == key:
        card = self.deck.deck.pop(i)
        self.pick_pool = []
        self.sub_phase = SubPhase.NONE
        self.jiri_blade_spent = True
        self.message = f"지리산 작두 — {card.label}{card.suit[0].upper()} 획득"
        return self._place_drawn_card(card)
    self.message = "덱에서 카드를 찾지 못했습니다."
    self.pick_pool = []
    self.sub_phase = SubPhase.NONE
    return False

  def coward_void_hand(self) -> bool:
    if (
      not has_artifact(self.artifact_stacks, "super_coward_club")
      or self.coward_club_spent
      or self.phase != Phase.FILL_HAND
      or self.sub_phase != SubPhase.NONE
      or self.slots_remaining() != 2
      or self.hand_count() == 0
    ):
      return False
    cards = [c for c in self.hand if c]
    self.deck.discard_cards(cards)
    self.hand = [None] * self.max_hand_slots
    self.coward_club_spent = True
    self.pending_tarot = None
    self.tarot_mode = None
    self.message = "슈퍼 겁쟁이 클럽 — 패 무효화 (카드 묘지)"
    return True

  def _maybe_hallasan_jaw(self, card: Card) -> None:
    if not has_artifact(self.artifact_stacks, "hallasan_kangjihu"):
      return
    import random
    from game.jaw_effects import on_jaw_card_drawn
    from game.jaws import random_jaw_offers
    if random.random() >= 1 / 3:
      return
    offers = random_jaw_offers(self, 1)
    if not offers:
      return
    card.jaw_id = offers[0]
    on_jaw_card_drawn(self, card)

  def _pop_jaw_card_pool(self, count: int) -> list[Card]:
    n = min(count, len(self.deck.deck))
    return [self.deck.deck.pop() for _ in range(n)]

  def _begin_jaw_stage(self) -> None:
    self._reset_play_fields()
    self.hand = [None] * self.max_hand_slots
    self.jaw_marks_remaining = jaw_marks_per_stage(self.artifact_stacks)
    self.jaw_offer_rerolled = []
    self.phase = Phase.JAW_STAGE
    if not self._begin_jaw_round():
      self.message = f"턱 Lv.{self.enemy.stage} — 덱에 카드가 없어 마킹을 건너뜁니다."
      self.jaw_finish()
      return

  def _begin_jaw_round(self) -> bool:
    self.jaw_offers = random_jaw_offers(self)
    self.jaw_picked_card_index = None
    self.jaw_picked_offer_index = None
    self.jaw_card_pool = self._pop_jaw_card_pool(JAW_STAGE_CARD_POOL)
    if not self.jaw_card_pool:
      return False
    self.sub_phase = SubPhase.JAW_PICK_JAW
    round_num = jaw_marks_per_stage(self.artifact_stacks) - self.jaw_marks_remaining + 1
    total = jaw_marks_per_stage(self.artifact_stacks)
    self.message = (
      f"턱 Lv.{self.enemy.stage} — 턱 선택 {round_num}/{total} "
      f"(제시된 턱 3개 중 하나 · 전투 없음)"
    )
    return True

  def pick_jaw_offer(self, jaw_index: int) -> bool:
    if self.phase != Phase.JAW_STAGE or self.sub_phase != SubPhase.JAW_PICK_JAW:
      return False
    if jaw_index >= len(self.jaw_offers):
      return False
    from game.jaws import get_jaw

    self.jaw_picked_offer_index = jaw_index
    self.sub_phase = SubPhase.JAW_PICK_CARD
    jaw = get_jaw(self.jaw_offers[jaw_index])
    round_num = jaw_marks_per_stage(self.artifact_stacks) - self.jaw_marks_remaining + 1
    total = jaw_marks_per_stage(self.artifact_stacks)
    self.message = (
      f"「{jaw.name}」({round_num}/{total}) — "
      f"자국을 남길 카드 1장을 선택하세요 ({len(self.jaw_card_pool)}장)"
    )
    return True

  def reroll_jaw_offer(self, jaw_index: int) -> bool:
    if not has_artifact(self.artifact_stacks, "rusty_pelican"):
      return False
    if self.phase != Phase.JAW_STAGE or self.sub_phase != SubPhase.JAW_PICK_JAW:
      return False
    if jaw_index in self.jaw_offer_rerolled or jaw_index >= len(self.jaw_offers):
      return False
    from game.jaws import random_jaw_offers
    new_offers = random_jaw_offers(self)
    if jaw_index < len(new_offers):
      self.jaw_offers[jaw_index] = new_offers[jaw_index]
    self.jaw_offer_rerolled.append(jaw_index)
    self.message = f"턱 {jaw_index + 1}번 리롤 완료"
    return True

  def traitor_jaw_take_tarot(self) -> bool:
    if not has_artifact(self.artifact_stacks, "traitor_tongue"):
      return False
    if self.phase != Phase.JAW_STAGE or self.sub_phase != SubPhase.JAW_PICK_JAW:
      return False
    from game.jaws import random_jaw_offers
    from game.tarot import create_tarot, random_tarot_numbers

    # 타로 슬롯이 가득 차면 자국을 소모하지 않고 제안만 새로고침
    if len(self.tarots) >= effective_max_tarot_held(self.artifact_stacks):
      self.jaw_offers = random_jaw_offers(self)
      self.jaw_offer_rerolled = []
      self.sub_phase = SubPhase.JAW_PICK_JAW
      self.message = "배신자의 혀 — 타로 슬롯 가득 · 턱 제안 새로고침"
      return True

    # 자국 1회를 포기하고 타로 1장 획득 — 이번 라운드의 카드 풀은 덱으로 반환
    n = random_tarot_numbers(1)[0]
    self.tarots.append(create_tarot(n, self._next_tarot_uid()))
    if self.jaw_card_pool:
      self.deck.deck.extend(self.jaw_card_pool)
      self.deck.shuffle()
    self.jaw_card_pool = []
    self.jaw_offers = []
    self.jaw_picked_card_index = None
    self.jaw_picked_offer_index = None
    self.sub_phase = SubPhase.NONE
    self.jaw_marks_remaining -= 1
    total = jaw_marks_per_stage(self.artifact_stacks)
    done = total - self.jaw_marks_remaining
    self.message = f"배신자의 혀 — 자국 포기, 타로 획득! ({done}/{total})"
    if self.jaw_marks_remaining > 0 and self._begin_jaw_round():
      return True
    return self.jaw_finish()

  def pick_acolyte_card(self, pool_index: int) -> bool:
    if self.sub_phase != SubPhase.ACOLYTE_PICK or pool_index >= len(self.pick_pool):
      return False
    card = self.pick_pool[pool_index]
    self.deck.remove_from_discard(card)
    self.deck.deck.append(card)
    self.deck.shuffle()
    self.resting_mult_bonus = card.score_value()
    self.pick_pool = []
    self.sub_phase = SubPhase.NONE
    self.message = f"안식의 시종 — {card.label} 덱 복귀 · 배수 +{self.resting_mult_bonus}"
    return True

  def pick_jaw_card(self, index: int) -> bool:
    if self.phase != Phase.JAW_STAGE or self.sub_phase != SubPhase.JAW_PICK_CARD:
      return False
    if self.jaw_picked_offer_index is None or index >= len(self.jaw_card_pool):
      return False
    from game.jaws import get_jaw

    jaw_id = self.jaw_offers[self.jaw_picked_offer_index]
    jaw = get_jaw(jaw_id)
    marked = self.jaw_card_pool[index]
    marked.jaw_id = jaw_id

    rest = [
      c for i, c in enumerate(self.jaw_card_pool)
      if i != index
    ]
    self.deck.deck.extend(rest)
    self.deck.deck.append(marked)
    self.deck.shuffle()

    self.jaw_card_pool = []
    self.jaw_offers = []
    self.jaw_picked_card_index = None
    self.jaw_picked_offer_index = None
    self.sub_phase = SubPhase.NONE
    round_num = jaw_marks_per_stage(self.artifact_stacks) - self.jaw_marks_remaining + 1
    total = jaw_marks_per_stage(self.artifact_stacks)
    self.message = (
      f"「{jaw.name}」의 이빨 자국 — {marked.label}{marked.suit[0].upper()} "
      f"({round_num}/{total} · 덱에 영구 반영)"
    )
    self.jaw_marks_remaining -= 1
    if self.jaw_marks_remaining > 0 and self._begin_jaw_round():
      return True
    return self.jaw_finish()

  def jaw_finish(self) -> bool:
    if self.phase != Phase.JAW_STAGE:
      return False
    if self.jaw_card_pool:
      self.deck.deck.extend(self.jaw_card_pool)
      self.deck.shuffle()
    self.jaw_card_pool = []
    self.jaw_offers = []
    self.jaw_picked_card_index = None
    self.jaw_picked_offer_index = None
    self.sub_phase = SubPhase.NONE
    self.deck.commit_run_deck()
    next_stage = self.enemy.stage + 1
    self._spawn_enemy(next_stage, preserve_deck=True)
    self._begin_stage_after_special()
    if self.phase == Phase.GAME_OVER:
      return False
    if self.enemy.kind not in ("well", "jaw"):
      self.message = (
        f"턱 통과 — 스테이지 {self.enemy.stage} 전투 시작 (HP {self.enemy.max_hp:,})"
      )
    return True

  def _begin_opening_deal(self) -> None:
    n = opening_deal_count(self.artifact_stacks)
    self.opening_five = self.pull_many(n, allow_joker=False)
    self.phase = Phase.BAN_SELECT
    left = self._turns_remaining()
    turn_txt = f" · 남은 턴 {left}/{self.enemy.max_turns}" if self._is_combat_enemy() else ""
    if has_artifact(self.artifact_stacks, "indulgence"):
      d = indulgence_discard_count(self.artifact_stacks)
      self.message = f"턴 {self.battle_turn} — {n}장 중 {d}장을 묘지로 (면죄부){turn_txt}"
    else:
      self.message = f"턴 {self.battle_turn} — {n}장 중 2장 밴{turn_txt}"

  def restart_play_keep_progress(self) -> None:
    saved_tarots = self.tarots[:]
    saved_uses_uids = set(self.used_tarot_uids)
    saved_uses_left = self.tarot_uses_left
    saved_enemy = self.enemy
    saved_wins = self.wins
    saved_cooldown = self.hanged_man_cooldown
    saved_turn = self.battle_turn
    saved_deck = self.deck.deck[:]
    saved_discard = self.deck.discard[:]
    saved_banned = self.deck.banned[:]
    self.start_new_play(decrement_cooldown=False)
    self.tarots = saved_tarots
    self.used_tarot_uids = saved_uses_uids
    self.tarot_uses_left = saved_uses_left
    self.enemy = saved_enemy
    self.wins = saved_wins
    self.hanged_man_cooldown = saved_cooldown
    self.battle_turn = saved_turn
    self.deck.deck = saved_deck
    self.deck.discard = saved_discard
    self.deck.banned = saved_banned

  def _spawn_enemy(self, stage: int, *, preserve_deck: bool = False) -> None:
    kind = stage_kind(stage)
    archetype = "normal"
    if kind in ("well", "jaw"):
      hp = 0
      turns = 0
    else:
      from game.progression import enemy_archetype
      archetype = enemy_archetype(stage)
      hp = enemy_max_hp(stage, archetype)
      turns = enemy_turn_limit(stage, archetype) + self.alchemy_bonuses().turn_limit
      if has_artifact(self.artifact_stacks, "rosary"):
        turns += 1
      if has_artifact(self.artifact_stacks, "jiri_blade"):
        turns = max(1, turns - 1)
      if has_artifact(self.artifact_stacks, "star_clock"):
        turns = int(turns * 1.5 + 0.5)
    from game.progression import stage_display_name
    self.enemy = Enemy(
      stage_display_name(stage, kind, archetype), hp, hp, stage, kind, turns, archetype,
    )
    self.battle_turn = 0
    if preserve_deck:
      if kind in ("well", "jaw"):
        self.deck.prepare_for_well_edit()
      else:
        self.deck.prepare_for_combat()
    else:
      self.deck.reset_for_enemy()
    self.discard_scroll = 0
    self.kingslayer_spent = False
    self.kingslayer_armed = False
    self.coward_club_spent = False
    self.jiri_blade_spent = False
    try:
      from game.persistence import record_best
      record_best(stage=stage)
    except Exception:
      pass

  def _begin_well_stage(self) -> None:
    self._reset_play_fields()
    self.hand = [None] * self.max_hand_slots
    self.phase = Phase.WELL_STAGE
    self.sub_phase = SubPhase.NONE
    self.pick_pool = []
    self.well_discard_remaining = WELL_DISCARD_COUNT
    self.well_gain_remaining = WELL_GAIN_COUNT
    self.well_deck_scroll = 0
    n = len(self.deck.deck)
    self.message = (
      f"우물 Lv.{self.enemy.stage} — 덱 {n}장 확인 · "
      f"카드 {WELL_DISCARD_COUNT}장 버리기 · 뽑기 {WELL_GAIN_COUNT}회"
    )

  def start_game(self) -> None:
    self.tarots = []
    self.wins = 0
    self.hanged_man_cooldown = 0
    self.run_max_damage = 0
    self._spawn_enemy(1)
    if STARTING_ARTIFACT_OFFER and not self.artifact_stacks:
      self.begin_starting_artifact_reward()
    else:
      self.begin_tarot_pick()

  def _next_tarot_uid(self) -> int:
    self.tarot_uid_counter += 1
    return self.tarot_uid_counter

  def _resize_hand(self) -> None:
    while len(self.hand) < self.max_hand_slots:
      self.hand.append(None)

  def _first_empty_slot(self) -> int | None:
    for i in range(self.max_hand_slots):
      if self.hand[i] is None:
        return i
    return None

  def hand_count(self) -> int:
    return sum(1 for c in self.hand[: self.max_hand_slots] if c is not None)

  def slots_remaining(self) -> int:
    return self.max_hand_slots - self.hand_count()

  def is_hand_full(self) -> bool:
    return self.hand_count() >= self.max_hand_slots

  def toggle_ban(self, index: int) -> None:
    if self.phase != Phase.BAN_SELECT:
      return
    limit = indulgence_discard_count(self.artifact_stacks) if has_artifact(
      self.artifact_stacks, "indulgence",
    ) else 2
    if index in self.ban_selection:
      self.ban_selection.remove(index)
    elif len(self.ban_selection) < limit:
      self.ban_selection.append(index)

  def well_discard_at(self, deck_index: int) -> bool:
    if self.phase != Phase.WELL_STAGE or self.sub_phase != SubPhase.NONE:
      return False
    if self.well_discard_remaining <= 0:
      self.message = "더 이상 버릴 카드가 없습니다."
      return False
    from game.artifact_runtime import deck_min_for_run
    if not self.deck.can_remove_cards(1, min_deck=deck_min_for_run(self.artifact_stacks)):
      self.message = "덱이 최소 매수입니다."
      return False
    removed = self.deck.permanently_remove_at(deck_index)
    if removed is None:
      return False
    self.well_discard_remaining -= 1
    left = self.well_discard_remaining
    self.message = (
      f"우물: {removed.label}{removed.suit[0].upper()} 영구 제거 "
      f"(덱 {len(self.deck.deck)}장 · 버리기 {left}회 남음)"
    )
    return True

  def well_begin_gain_pick(self) -> bool:
    if self.phase != Phase.WELL_STAGE or self.sub_phase != SubPhase.NONE:
      return False
    if self.well_gain_remaining <= 0:
      self.message = "뽑기 횟수를 모두 사용했습니다."
      return False
    if not self.deck.can_add_cards(1):
      self.message = "덱이 최대 매수입니다."
      return False
    offers = self.deck.random_trump_offers(WELL_GAIN_OFFER_SIZE)
    if not offers:
      self.message = "뽑을 수 있는 카드가 없습니다."
      return False
    self.pick_pool = offers
    self.sub_phase = SubPhase.WELL_GAIN_PICK
    self.message = f"우물: 5장 중 1장 선택 ({self.well_gain_remaining}회 남음)"
    return True

  def well_pick_gain(self, index: int) -> bool:
    if self.phase != Phase.WELL_STAGE or self.sub_phase != SubPhase.WELL_GAIN_PICK:
      return False
    if index < 0 or index >= len(self.pick_pool):
      return False
    if not self.deck.can_add_cards(1):
      self.message = "덱이 최대 매수입니다."
      self.sub_phase = SubPhase.NONE
      self.pick_pool = []
      return False
    chosen = self.pick_pool[index]
    self.deck.deck.append(chosen.copy())
    self.deck.shuffle()
    self.well_gain_remaining -= 1
    self.pick_pool = []
    self.sub_phase = SubPhase.NONE
    left = self.well_gain_remaining
    self.message = (
      f"우물: {chosen.label}{chosen.suit[0].upper()} 영구 추가 "
      f"(덱 {len(self.deck.deck)}장 · 뽑기 {left}회 남음)"
    )
    return True

  def well_finish(self) -> bool:
    if self.phase != Phase.WELL_STAGE:
      return False
    self.deck.commit_run_deck()
    next_stage = self.enemy.stage + 1
    self._spawn_enemy(next_stage, preserve_deck=True)
    self._begin_stage_after_special()
    if self.phase == Phase.GAME_OVER:
      return False
    if self.enemy.kind not in ("well", "jaw"):
      self.message = (
        f"우물 통과 — 스테이지 {self.enemy.stage} 전투 시작 (HP {self.enemy.max_hp:,})"
      )
    return True

  def _joker_transform_pool(self) -> list[Card]:
    return self.deck.joker_transform_pool()

  def _magician_joker_slots(self) -> list[int]:
    return [
      i for i, c in enumerate(self.hand[: self.max_hand_slots])
      if c and joker_needs_transform(c)
    ]

  def _begin_magician_score_transform(self) -> bool:
    slots = self._magician_joker_slots()
    if not slots:
      return False
    idx = slots[0]
    self.joker_pending = self.hand[idx]
    self.joker_target_slot = idx
    self.sub_phase = SubPhase.JOKER_TRANSFORM
    self.pick_pool = self._joker_transform_pool()
    self.message = "합산 전: 마법사 조커가 될 카드를 선택하세요 (52장)"
    return True

  def _try_enter_score_phase(self) -> None:
    if self._begin_magician_score_transform():
      return
    self._enter_score_phase()

  def _notify_hand_full(self) -> None:
    """손패 완성 — 자동 합산 없이 플레이어가 [점수 확정]을 누를 때까지 대기."""
    if self.sub_phase != SubPhase.NONE:
      return
    if self._begin_magician_score_transform():
      return
    self.message = "손패 완성! 타로 사용·확인 후 [점수 확정]을 누르세요."

  def _handle_joker_draw(self, card: Card, slot: int | None = None) -> bool:
    """FILL_HAND 드로우(및 바보 리롤)에서만 호출. 0/21 즉시 발동, 1(마법사)은 손패 보관."""
    if slot is None:
      slot = self._first_empty_slot()
    face = roll_joker_on_draw()
    self.joker_draw_face = face

    if face == 0:
      self.fool_rerolls_left = 3
      self.fool_pick_slots = []
      self.sub_phase = SubPhase.JOKER_FOOL_PICK
      self.message = "바보 조커! 리롤할 카드를 선택하세요 (3회)"
      self._update_live_hand()
      return True

    if face == 21:
      self.deck.swap_deck_and_discard()
      self.message = "세계 조커! 덱과 묘지를 뒤바꿨습니다."
      self._update_live_hand()
      if self.is_hand_full():
        self._notify_hand_full()
      return True

    if slot is None:
      return False
    self.hand[slot] = card
    self.temperance_index = None
    self.temperance_pending_card = None
    self.sub_phase = SubPhase.NONE
    self.message = f"마법사 조커 — 합산 때 변형합니다 ({self.slots_remaining()}칸 남음)"
    return self._after_card_placed()

  def pick_joker_transform(self, index: int) -> bool:
    if self.sub_phase != SubPhase.JOKER_TRANSFORM or index >= len(self.pick_pool):
      return False
    if self.joker_pending is None or self.joker_target_slot is None:
      return False
    template = self.pick_pool[index]
    transformed = transform_joker(self.joker_pending, template)
    self.hand[self.joker_target_slot] = transformed
    self.joker_pending = None
    self.joker_target_slot = None
    self.pick_pool = []
    self.sub_phase = SubPhase.NONE
    self._update_live_hand()
    if self._magician_joker_slots():
      return self._begin_magician_score_transform()
    if self.is_hand_full():
      self._notify_hand_full()
    else:
      self.message = f"남은 {self.slots_remaining()}칸 · 현재 {self.live_hand_label or '—'}"
    return True

  def toggle_fool_pick(self, hand_index: int) -> bool:
    if self.sub_phase != SubPhase.JOKER_FOOL_PICK:
      return False
    if not self.hand[hand_index]:
      return False
    if hand_index in self.fool_pick_slots:
      self.fool_pick_slots.remove(hand_index)
    else:
      self.fool_pick_slots.append(hand_index)
    self.message = f"바보: {len(self.fool_pick_slots)}장 선택 · {self.fool_rerolls_left}회 남음"
    return True

  def confirm_fool_reroll(self) -> bool:
    if self.sub_phase != SubPhase.JOKER_FOOL_PICK or self.fool_rerolls_left <= 0:
      return False
    if not self.fool_pick_slots:
      self.message = "리롤할 카드를 선택하세요."
      return False
    indices = sorted(self.fool_pick_slots, reverse=True)
    for idx in indices:
      card = self.hand[idx]
      if card:
        self.deck.discard_cards([card])
        self.hand[idx] = None
    for idx in sorted(self.fool_pick_slots):
      if self.phase == Phase.GAME_OVER:
        return False
      card = self.pull_card()
      if card is None:
        break
      if card.is_joker_card:
        self._handle_joker_draw(card, idx)
        self.fool_rerolls_left -= 1
        self.fool_pick_slots = []
        if self.sub_phase == SubPhase.JOKER_FOOL_PICK:
          return True
        if self.fool_rerolls_left <= 0:
          self.sub_phase = SubPhase.NONE
        return True
      self.hand[idx] = card
    self.fool_rerolls_left -= 1
    self.fool_pick_slots = []
    if self.fool_rerolls_left <= 0:
      self.sub_phase = SubPhase.NONE
      self.message = "바보 리롤 완료"
    else:
      self.message = f"바보: {self.fool_rerolls_left}회 남음"
    self._update_live_hand()
    return True

  def pick_priestess(self, index: int) -> bool:
    if self.sub_phase != SubPhase.PRIESTESS_PICK or index >= len(self.pick_pool):
      return False
    chosen = self.pick_pool[index]
    rest = [c for i, c in enumerate(self.pick_pool) if i != index]
    self.deck.discard_cards(rest)
    slot = self._first_empty_slot()
    if slot is not None:
      self.hand[slot] = chosen
    self.pick_pool = []
    self.priestess_passes_remaining = max(0, self.priestess_passes_remaining - 1)
    if self.priestess_passes_remaining > 0:
      from game.tarot_effects import _begin_priestess_pick
      self.message = _begin_priestess_pick(self)
      self._update_live_hand()
      return True
    self.sub_phase = SubPhase.NONE
    self.message = f"여사제: {chosen.label}{chosen.suit[0].upper()} 획득"
    self._update_live_hand()
    return True

  def _update_live_hand(self) -> None:
    preview = self.preview_score()
    if not preview:
      self.live_hand_tier = 0
      self.live_hand_label = ""
      self.live_best_indices = ()
      return
    from ui.themes import hand_tier
    self.live_hand_label = preview["hand_label"]
    self.live_hand_tier = hand_tier(preview["hand_name"])
    self.live_best_indices = preview.get("best_indices", ())

  def _after_card_placed(self) -> bool:
    self._update_live_hand()
    jaw_notice = self._jaw_draw_msg
    self._jaw_draw_msg = None
    if self.is_hand_full():
      self._notify_hand_full()
    else:
      self.message = f"남은 {self.slots_remaining()}칸 · 현재 {self.live_hand_label or '—'}"
    if jaw_notice:
      # 드로우 시 발동한 자국 효과 알림이 묻히지 않게 앞에 노출
      self.message = f"{jaw_notice}  ·  {self.message}"
    return True

  def confirm_ban(self) -> bool:
    if has_artifact(self.artifact_stacks, "indulgence"):
      need = indulgence_discard_count(self.artifact_stacks)
      if self.phase != Phase.BAN_SELECT or len(self.ban_selection) != need:
        return False
      discarded = [self.opening_five[i] for i in sorted(self.ban_selection, reverse=True)]
      self.deck.discard_cards(discarded)
      kept = [c for i, c in enumerate(self.opening_five) if i not in self.ban_selection]
      for i, card in enumerate(kept):
        self.hand[i] = card
      self.ban_selection = []
    else:
      if self.phase != Phase.BAN_SELECT or len(self.ban_selection) != 2:
        return False
      banned = [self.opening_five[i] for i in sorted(self.ban_selection, reverse=True)]
      self.deck.ban_cards(banned)
      kept = [c for i, c in enumerate(self.opening_five) if i not in self.ban_selection]
      for i, card in enumerate(kept):
        self.hand[i] = card
      self.ban_selection = []
    pick_n = draw_pick_count(self.artifact_stacks)
    self.draw_three = self.pull_many(pick_n, allow_joker=False)
    if self.phase == Phase.GAME_OVER:
      return True
    self.phase = Phase.DRAW_PICK
    self.message = f"{pick_n}장 중 1장을 선택하세요."
    return True

  def pick_from_three(self, index: int) -> bool:
    if self.phase != Phase.DRAW_PICK or index >= len(self.draw_three):
      return False
    chosen = self.draw_three[index]
    discarded = [c for i, c in enumerate(self.draw_three) if i != index]
    self.deck.discard_cards(discarded)
    slot = self._first_empty_slot()
    if slot is not None:
      self.hand[slot] = chosen
    self.draw_three = []
    self.phase = Phase.FILL_HAND
    self._update_live_hand()
    self.message = f"남은 {self.slots_remaining()}칸 — 트럼프 드로우 또는 타로 사용"
    return True

  def draw_trump(self) -> bool:
    if self.phase != Phase.FILL_HAND or self.sub_phase not in (SubPhase.NONE, SubPhase.TEMPERANCE_OFFER):
      return False
    if self.is_hand_full():
      return False
    return self._draw_one_card()

  def _consume_draw_preview(self, card: Card) -> None:
    """은둔자 등으로 예고된 다음 드로우 카드가 실제로 뽑히면 목록에서 제거."""
    for i, c in enumerate(self.next_draw_preview):
      if c.rank == card.rank and c.suit == card.suit:
        self.next_draw_preview.pop(i)
        return

  def _blood_horn_side_discard(self) -> None:
    if not has_artifact(self.artifact_stacks, "blood_horn") or not self.deck.deck:
      return
    side = self.deck.deck.pop()
    self.deck.discard_cards([side])
    if side.has_jaw_mark and self.phase == Phase.FILL_HAND:
      prev_msg = self.message
      result = on_jaw_card_drawn(self, side)
      if self.message != prev_msg:
        self._jaw_draw_msg = self.message
      if result == "consumed":
        pass

  def _draw_one_card(self) -> bool:
    card = self.pull_card()
    if card is None:
      self.message = "뽑을 카드가 없습니다. (덱·묘지·밴 모두 비었거나 보충 불가)"
      return False
    self._consume_draw_preview(card)
    self._maybe_hallasan_jaw(card)
    if self.temperance_draws_remaining > 0 and self.temperance_suit:
      if card.suit != self.temperance_suit:
        self.temperance_pending_card = card
        self.sub_phase = SubPhase.TEMPERANCE_OFFER
        left = self.temperance_draws_remaining
        self.message = (
          f"절제: {self.temperance_suit} 불일치 ({card.label}) — "
          f"다시 뽑기 가능 ({self.temperance_rerolls}회 · 남은 적용 {left}회)"
        )
        return True
    return self._place_drawn_card(card)

  def _place_drawn_card(self, card: Card) -> bool:
    if card.is_joker_card:
      if self.phase != Phase.FILL_HAND:
        self.deck.discard_cards([card])
        self.message = "조커는 트럼프 드로우에서만 뽑을 수 있습니다."
        return False
      return self._handle_joker_draw(card)
    if card.has_jaw_mark and self.phase == Phase.FILL_HAND:
      prev_msg = self.message
      result = on_jaw_card_drawn(self, card)
      if self.message != prev_msg:
        self._jaw_draw_msg = self.message
      if result == "consumed":
        return self._after_card_placed()
      if result == "pending":
        self._jaw_draw_msg = None
        return True
    slot = self._first_empty_slot()
    if slot is None:
      return False
    self.hand[slot] = card
    self._consume_temperance_draw_if_needed()
    self.temperance_pending_card = None
    if self.sub_phase not in (SubPhase.JAW_FANG_PICK, SubPhase.JAW_MICHAEL_SEAL):
      self.sub_phase = SubPhase.NONE
    self._refresh_twin_ghost_preview()
    return self._after_card_placed()

  def _consume_temperance_draw_if_needed(self) -> None:
    if self.temperance_draws_remaining <= 0 or not self.temperance_suit:
      return
    self.temperance_draws_remaining -= 1
    if self.temperance_draws_remaining > 0:
      self.temperance_rerolls = 2
    else:
      self.temperance_suit = None
      self.temperance_rerolls = 0

  def toggle_jaw_fang_pick(self, hand_index: int) -> bool:
    if self.sub_phase != SubPhase.JAW_FANG_PICK:
      return False
    if not self.hand[hand_index]:
      return False
    if hand_index in self.jaw_fang_picks:
      self.jaw_fang_picks.remove(hand_index)
    elif len(self.jaw_fang_picks) < self.jaw_fang_quota:
      self.jaw_fang_picks.append(hand_index)
    n = len(self.jaw_fang_picks)
    self.message = f"앞니 유해: {n}/{self.jaw_fang_quota}장 선택"
    return True

  def confirm_jaw_fang_reroll(self) -> bool:
    if self.sub_phase != SubPhase.JAW_FANG_PICK:
      return False
    if not self.jaw_fang_picks:
      self.message = "리롤할 카드를 선택하세요."
      return False
    for idx in sorted(self.jaw_fang_picks, reverse=True):
      old = self.hand[idx]
      if old:
        self.deck.discard_cards([old])
        self.hand[idx] = None
    for idx in sorted(self.jaw_fang_picks):
      if self.phase == Phase.GAME_OVER:
        return False
      new = self.pull_card(allow_joker=False)
      if new:
        self.hand[idx] = new
    if self.jaw_fang_card:
      self.deck.discard_cards([self.jaw_fang_card])
    self.jaw_fang_card = None
    self.jaw_fang_picks = []
    self.jaw_fang_quota = 0
    self.sub_phase = SubPhase.NONE
    self.message = "앞니가 밀린 유해 — 리롤 완료 (유해는 묘지)"
    self._update_live_hand()
    if self.is_hand_full():
      self._notify_hand_full()
    return True

  def seal_tarot_michael(self, tarot_uid: int) -> bool:
    if self.sub_phase != SubPhase.JAW_MICHAEL_SEAL:
      return False
    tarot = next((t for t in self.tarots if t.uid == tarot_uid), None)
    if not tarot or tarot.uid in self.sealed_tarot_uids:
      return False
    self.sealed_tarot_uids.add(tarot.uid)
    self.enemy.hp = 0
    card = self.jaw_pending_card
    self.jaw_pending_card = None
    self.sub_phase = SubPhase.NONE
    if card:
      slot = self._first_empty_slot()
      if slot is not None:
        self.hand[slot] = card
    self.message = f"미카엘 — {tarot.name} 영구 봉인 · 처형!"
    self._update_live_hand()
    if self.is_hand_full():
      self._notify_hand_full()
    return True

  def accept_temperance_draw(self) -> bool:
    if self.sub_phase != SubPhase.TEMPERANCE_OFFER or not self.temperance_pending_card:
      return False
    card = self.temperance_pending_card
    return self._place_drawn_card(card)

  def reroll_temperance(self) -> bool:
    if self.sub_phase != SubPhase.TEMPERANCE_OFFER or self.temperance_rerolls <= 0:
      return False
    if self.temperance_pending_card:
      self.deck.discard_cards([self.temperance_pending_card])
    self.temperance_rerolls -= 1
    card = self.pull_card()
    if card is None:
      return False
    if (
      self.temperance_draws_remaining > 0
      and self.temperance_suit
      and self.temperance_rerolls > 0
      and card.suit != self.temperance_suit
    ):
      self.temperance_pending_card = card
      self.message = f"절제: 문양 불일치 — 다시 뽑기 ({self.temperance_rerolls}회)"
      return True
    return self._place_drawn_card(card)

  def pick_temperance_suit(self, suit_index: int) -> bool:
    if self.sub_phase != SubPhase.TEMPERANCE_SUIT:
      return False
    suits = ("hearts", "diamonds", "clubs", "spades")
    self.message = apply_temperance_suit(self, suits[suit_index])
    return True

  def pick_from_five(self, index: int) -> bool:
    if self.sub_phase != SubPhase.PICK_FIVE or index >= len(self.pick_pool):
      return False
    chosen = self.pick_pool[index]
    rest = [c for i, c in enumerate(self.pick_pool) if i != index]
    self.deck.discard_cards(rest)
    self.pick_pool = []
    self.sub_phase = SubPhase.NONE
    return self._place_drawn_card(chosen)

  def select_tarot(self, tarot: TarotCard) -> bool:
    if self.phase != Phase.FILL_HAND or self.sub_phase != SubPhase.NONE:
      return False
    if self.pending_tarot and self.pending_tarot.uid == tarot.uid:
      return True
    if tarot.uid in self.sealed_tarot_uids:
      self.message = "봉인된 타로는 사용할 수 없습니다."
      return False
    if tarot.uid in self.used_tarot_uids:
      self.message = "이번 플레이에서 이미 사용한 타로입니다."
      return False
    if self.tarot_uses_left <= 0:
      self.message = "타로 사용 횟수를 모두 소진했습니다."
      return False
    if tarot.number == 12 and self.hanged_man_cooldown > 0:
      self.message = f"매달린 사람 쿨타임 {self.hanged_man_cooldown}턴"
      return False
    if self.kingslayer_armed:
      self.kingslayer_armed = False
    self.pending_tarot = tarot
    self.tarot_mode = "choose"
    self.message = f"{tarot.name} — 대응 카드 클릭 또는 무늬로 내기"
    return True

  def play_tarot_with_suit(self, suit_index: int) -> bool:
    if not self.pending_tarot or self.tarot_mode != "choose":
      return False
    if self.is_hand_full():
      return False
    suits = ("hearts", "diamonds", "clubs", "spades")
    if suit_index < 0 or suit_index >= 4:
      return False
    suit = suits[suit_index]
    if has_artifact(self.artifact_stacks, "red_bowl") and suit in ("clubs", "spades"):
      self.message = "붉은 그릇 — 붉은 문양만 선택할 수 있습니다."
      return False
    tarot = self.pending_tarot
    card = play_tarot_as_card(tarot, suit)
    slot = self._first_empty_slot()
    if slot is None:
      return False
    self.hand[slot] = card
    self._consume_tarot(tarot)
    self.pending_tarot = None
    self.tarot_mode = None
    suit_ko = {"hearts": "하트", "diamonds": "다이아", "clubs": "클럽", "spades": "스페이드"}[suit]
    self.message = f"{tarot.name} → {suit_ko} 카드로 펼침!"
    if self.is_hand_full():
      self._notify_hand_full()
    return True

  def play_tarot_with_color(self, color: str) -> bool:
    """타로를 카드로 펼칠 때 색(빨강/검정)만 고르고 정확한 문양은 무작위."""
    if not self.pending_tarot or self.tarot_mode != "choose":
      return False
    if self.is_hand_full():
      return False
    if has_artifact(self.artifact_stacks, "red_bowl") and color == "black":
      self.message = "붉은 그릇 — 붉은 문양(하트/다이아)만 낼 수 있습니다."
      return False
    if color == "red":
      suit = random.choice(["hearts", "diamonds"])
    elif color == "black":
      suit = random.choice(["clubs", "spades"])
    else:
      return False
    tarot = self.pending_tarot
    card = play_tarot_as_card(tarot, suit)
    slot = self._first_empty_slot()
    if slot is None:
      return False
    self.hand[slot] = card
    self._consume_tarot(tarot)
    self.pending_tarot = None
    self.tarot_mode = None
    suit_ko = {"hearts": "하트", "diamonds": "다이아", "clubs": "클럽", "spades": "스페이드"}[suit]
    color_ko = "빨강" if color == "red" else "검정"
    self.message = f"{tarot.name} → {color_ko} 선택, {suit_ko} 카드로 펼침!"
    if self.is_hand_full():
      self._notify_hand_full()
    return True

  def enhance_with_tarot(self, hand_index: int) -> bool:
    if not self.pending_tarot or self.tarot_mode != "choose":
      return False
    if hand_index >= len(self.hand) or not self.hand[hand_index]:
      return False
    tarot = self.pending_tarot
    if not tarot.can_enhance(self.hand[hand_index]):
      self.message = f"{tarot.name}은(는) 이 카드와 대응되지 않습니다."
      return False
    if tarot.number == 12 and self.hanged_man_cooldown > 0:
      self.message = f"매달린 사람 쿨타임 {self.hanged_man_cooldown}턴"
      return False

    self.message = apply_tarot_enhance(self, hand_index)
    self._consume_tarot(tarot)
    self.pending_tarot = None
    self.tarot_mode = None

    if self.modifiers.devil_zero_turn:
      self._try_enter_score_phase()
    return True

  def pick_rank_target(self, hand_index: int) -> bool:
    if self.sub_phase != SubPhase.RANK_PICK_TARGET or not self.hand[hand_index]:
      return False
    card = self.hand[hand_index]
    self.rank_change_target = hand_index
    self.strength_rank = max(2, card.rank)
    self.strength_suit = card.suit if card.suit in ("hearts", "diamonds", "clubs", "spades") else "hearts"
    self.sub_phase = SubPhase.RANK_PICK_VALUE
    if self.strength_allow_suit:
      self.message = "화살표로 랭크·문양을 바꾼 뒤 확정하세요"
    else:
      self.message = "화살표로 랭크만 바꾼 뒤 확정하세요 (문양 유지)"
    return True

  def strength_adjust_rank(self, delta: int) -> bool:
    if self.sub_phase != SubPhase.RANK_PICK_VALUE:
      return False
    r = self.strength_rank + delta
    if r > 14:
      r = 2
    elif r < 2:
      r = 14
    self.strength_rank = r
    return True

  def strength_adjust_suit(self, delta: int) -> bool:
    if self.sub_phase != SubPhase.RANK_PICK_VALUE or not self.strength_allow_suit:
      return False
    suits = ["hearts", "diamonds", "clubs", "spades"]
    idx = (suits.index(self.strength_suit) + delta) % 4
    self.strength_suit = suits[idx]
    return True

  def strength_confirm(self) -> bool:
    if self.sub_phase != SubPhase.RANK_PICK_VALUE or self.rank_change_target is None:
      return False
    card = self.hand[self.rank_change_target]
    if not card:
      return False
    card.rank = self.strength_rank
    if self.strength_allow_suit:
      card.suit = self.strength_suit
    self.sub_phase = SubPhase.NONE
    self.rank_change_target = None
    self.strength_allow_suit = False
    self._update_live_hand()
    suit_ko = {"hearts": "하트", "diamonds": "다이아", "clubs": "클럽", "spades": "스페이드"}[card.suit]
    self.message = f"힘: 카드를 {card.label} {suit_ko}로 변경"
    return True

  def pick_justice_source(self, hand_index: int) -> bool:
    if self.sub_phase != SubPhase.JUSTICE_PICK_SOURCE:
      return False
    if not self.hand[hand_index] or self.justice_anchor_index is None:
      return False
    anchor = self.justice_anchor_index
    mirror = 2 * anchor - hand_index
    if mirror < 0 or mirror >= self.max_hand_slots:
      self.message = "정의: 대칭 위치가 손패 밖입니다."
      return False
    source = self.hand[hand_index]
    if self.hand[mirror]:
      self.deck.discard_cards([self.hand[mirror]])
    self.hand[mirror] = source.copy()
    self.justice_anchor_index = None
    self.sub_phase = SubPhase.NONE
    self.message = f"정의: {source.label}{source.suit[0].upper()} → 대칭 위치에 복제"
    self._update_live_hand()
    return True

  def apply_rank_change(self, rank: int) -> bool:
    # 구버전 호환 (그리드 클릭). 신규 UI는 화살표 방식 사용.
    if self.sub_phase != SubPhase.RANK_PICK_VALUE or self.rank_change_target is None:
      return False
    self.strength_rank = rank
    return self.strength_confirm()

  def pick_hermit_suit(self, suit_index: int) -> bool:
    if self.sub_phase != SubPhase.HERMIT_SUIT:
      return False
    suits = ("hearts", "diamonds", "clubs", "spades")
    self.message = apply_hermit_suit(self, suits[suit_index])
    return True

  def wheel_reroll(self) -> bool:
    msg = reroll_wheel_card(self)
    if msg:
      self.message = msg
    return bool(msg)

  def wheel_done(self) -> None:
    finish_wheel(self)
    self.message = "수레바퀴 효과 종료"

  def pick_death_card(self, pool_index: int) -> bool:
    """레거시 호환 — toggle_death_pick + confirm_death_pick 사용 권장."""
    if not self.toggle_death_pick(pool_index):
      return False
    if len(self.death_picks) == 3:
      return self.confirm_death_pick()
    return True

  def toggle_death_pick(self, pool_index: int) -> bool:
    if self.sub_phase != SubPhase.DEATH_PICK_THREE:
      return False
    if pool_index >= len(self.pick_pool):
      return False
    if self.pick_pool[pool_index].is_joker_card:
      self.message = "조커는 묘지에서 뽑을 수 없습니다."
      return False
    if pool_index in self.death_picks:
      self.death_picks.remove(pool_index)
    elif len(self.death_picks) < 3:
      self.death_picks.append(pool_index)
    self.message = f"죽음: 묘지 {len(self.death_picks)}/3장 선택 — 확정"
    return True

  def confirm_death_pick(self) -> bool:
    if self.sub_phase != SubPhase.DEATH_PICK_THREE or len(self.death_picks) != 3:
      return False
    for pi in self.death_picks:
      card = self.pick_pool[pi]
      self.deck.remove_from_discard(card)
      slot = self._first_empty_slot()
      if slot is not None:
        self.hand[slot] = card
    self.sub_phase = SubPhase.NONE
    self.death_picks = []
    self.pick_pool = []
    self.message = "죽음: 3장 획득 완료"
    return True

  def toggle_moon_hand_pick(self, hand_index: int) -> bool:
    if self.sub_phase != SubPhase.MOON_PICK_HAND:
      return False
    if hand_index in self.moon_hand_picks:
      self.moon_hand_picks.remove(hand_index)
    elif len(self.moon_hand_picks) < 2 and self.hand[hand_index]:
      self.moon_hand_picks.append(hand_index)
    n = len(self.moon_hand_picks)
    if n < 2:
      self.message = f"달: 교환할 패 {n}/2장 선택"
      return True
    self.pick_pool = [c for c in self.deck.discard if not c.is_joker_card]
    self.sub_phase = SubPhase.MOON_PICK_DRAW
    self.death_picks = []
    self.message = "달: 묘지에서 교환할 2장을 선택하세요"
    return True

  def toggle_moon_discard(self, hand_index: int) -> bool:
    return self.toggle_moon_hand_pick(hand_index)

  def pick_moon_card(self, pool_index: int) -> bool:
    """레거시 호환."""
    if not self.toggle_moon_grave_pick(pool_index):
      return False
    if len(self.death_picks) == 2:
      return self.confirm_moon_pick()
    return True

  def toggle_moon_grave_pick(self, pool_index: int) -> bool:
    if self.sub_phase != SubPhase.MOON_PICK_DRAW:
      return False
    if pool_index >= len(self.pick_pool):
      return False
    if self.pick_pool[pool_index].is_joker_card:
      self.message = "조커는 묘지에서 뽑을 수 없습니다."
      return False
    if pool_index in self.death_picks:
      self.death_picks.remove(pool_index)
    elif len(self.death_picks) < 2:
      self.death_picks.append(pool_index)
    self.message = f"달: 묘지 {len(self.death_picks)}/2장 선택 — 확정"
    return True

  def confirm_moon_pick(self) -> bool:
    if self.sub_phase != SubPhase.MOON_PICK_DRAW or len(self.death_picks) != 2:
      return False
    for pi in self.death_picks:
      card = self.pick_pool[pi]
      self.deck.remove_from_discard(card)
    hand_indices = sorted(self.moon_hand_picks)
    hand_cards = [self.hand[i] for i in hand_indices if self.hand[i]]
    pool_cards = [self.pick_pool[pi] for pi in self.death_picks]
    for idx, incoming in zip(hand_indices, pool_cards):
      self.hand[idx] = incoming
    if hand_cards:
      self.deck.discard_cards(hand_cards)
    self.sub_phase = SubPhase.NONE
    self.death_picks = []
    self.moon_hand_picks = []
    self.pick_pool = []
    self.message = "달: 패↔묘지 2장 교환 완료"
    self._update_live_hand()
    return True

  def cancel_tarot(self) -> None:
    self.pending_tarot = None
    self.tarot_mode = None
    self.message = "타로 선택 취소"

  def _consume_tarot(self, tarot: TarotCard) -> None:
    self.tarot_uses_left -= 1
    if has_artifact(self.artifact_stacks, "future_shackle"):
      n = self.shackle_tarot_uses.get(tarot.uid, 0) + 1
      self.shackle_tarot_uses[tarot.uid] = n
      if n >= 2:
        self.used_tarot_uids.add(tarot.uid)
    else:
      self.used_tarot_uids.add(tarot.uid)

  def _scoring_hand(self, *, commit: bool) -> tuple[list[Card | None], object]:
    hand, ctx = prepare_belial_hand(self.hand, self, commit=commit)
    if commit:
      self.jaw_score_ctx = ctx
    return hand, ctx

  def _artifact_runtime(self):
    from game.artifact_effects import ArtifactRuntimeContext
    return ArtifactRuntimeContext(
      artifact_stacks=self.artifact_stacks,
      discard_count=len(self.deck.discard),
      enemy_max_hp=self.enemy.max_hp,
      turns_remaining=self._turns_remaining(),
      tarot_used_count=len(self.modifiers.applied_tarots),
      essence_total=total_essence_count(self),
      resting_mult_bonus=self.resting_mult_bonus,
      kyungcheon_chip=self.kyungcheon_chip,
      kyungcheon_mult=self.kyungcheon_mult,
    )

  def preview_score(self) -> dict | None:
    if self.hand_count() == 0:
      return None
    from game.score_steps import build_score_reveal_steps
    hand, ctx = self._scoring_hand(commit=False)
    result, _ = build_score_reveal_steps(
      hand, self.modifiers, self.hand_bonuses, ctx,
      self.alchemy_bonuses(), self._artifact_runtime(),
    )
    return result

  def _enter_score_phase(self) -> None:
    from game.artifact_effects import KINGSLAYER_CHIP_PCT
    from game.score_steps import build_kingslayer_finale_steps, build_score_reveal_steps

    self.phase = Phase.SCORE
    self.sub_phase = SubPhase.NONE
    self.pending_tarot = None
    self.tarot_mode = None
    self.score_damage_applied = False
    armed = self.kingslayer_armed
    score_hand, ctx = self._scoring_hand(commit=True)
    art = self._artifact_runtime()
    art.kingslayer_active = False
    self.last_score, self.score_reveal_steps = build_score_reveal_steps(
      score_hand, self.modifiers, self.hand_bonuses, ctx,
      self.alchemy_bonuses(), art,
    )
    if armed:
      chip = self.last_score["chip_sum"]
      self.kingslayer_finale_steps = build_kingslayer_finale_steps(
        chip, self.enemy.max_hp, KINGSLAYER_CHIP_PCT,
      )
    else:
      self.kingslayer_finale_steps = []
    if has_artifact(self.artifact_stacks, "star_clock"):
      hn = self.last_score.get("hand_name", "")
      if hn in ("high_card", "pair"):
        self._game_over("별시계 — 하이카드/페어 합산으로 즉사!")
        return
    self.message = "점수 합산 중..." if not armed else "점수 합산 중... (검격 대기)"

  def apply_score_damage(self) -> int:
    """연출 완료 후 실제 피해 적용."""
    if self.phase != Phase.SCORE or self.score_damage_applied or not self.last_score:
      return 0
    bonus = self.last_score.get("bonus_damage", 0)
    if self.kingslayer_armed:
      from game.artifact_effects import KINGSLAYER_CHIP_PCT
      chip = self.last_score["chip_sum"]
      damage = int(self.enemy.max_hp * chip * KINGSLAYER_CHIP_PCT) + bonus
      self.kingslayer_spent = True
      self.kingslayer_armed = False
      self.kingslayer_finale_steps = []
      self.last_score = {
        **self.last_score,
        "hand_label": "왕을 죽이는 검",
        "total": damage - bonus,
        "kingslayer": True,
      }
      bonus_txt = f" + 추가 {bonus}" if bonus else ""
      self.message = (
        f"왕을 죽이는 검 — 칩 {chip} → {damage} 피해!{bonus_txt}"
      )
    else:
      damage = self.last_score["total"] + bonus
      hn = self.last_score.get("hand_name")
      kyung_txt = ""
      if (
        hn in ("dragon", "rainbow", "leviathan", "spectrum")
        and has_artifact(self.artifact_stacks, "kyungcheon")
      ):
        self.kyungcheon_chip += 5
        self.kyungcheon_mult += 1
        kyung_txt = (
          f" · 경천 +5칩/+1배 (누적 칩+{self.kyungcheon_chip} 배+{self.kyungcheon_mult})"
        )
      extra = ""
      if self.last_score.get("devil_roll"):
        extra = f" (악마 주사위 {self.last_score['devil_roll']})"
      bonus_txt = f" + 검 피해 {bonus}" if bonus else ""
      self.message = (
        f"{self.last_score['hand_label']}{extra} — "
        f"{self.last_score['multiplier']}x × {self.last_score['chip_sum']} = {damage} 피해!{bonus_txt}{kyung_txt}"
      )
    self.enemy.hp = max(0, self.enemy.hp - damage)
    self.score_damage_applied = True
    if damage > self.run_max_damage:
      self.run_max_damage = damage
    try:
      from game.persistence import record_best
      record_best(damage=damage)
    except Exception:
      pass
    return damage

  def _finalize_play_cards(self) -> None:
    # 적에게 피해를 입힌(점수에 사용된) 카드는 묘지로 가지 않고 소모됨
    self.hand = [None] * self.max_hand_slots

  def confirm_score(self) -> None:
    if self.phase != Phase.SCORE or not self.score_damage_applied:
      return
    self._finalize_play_cards()
    if self.enemy.hp <= 0:
      self.wins += 1
      drop_msg = self._drop_essence_on_kill()
      self._begin_reward_after_kill()
      if drop_msg:
        self.message = f"{drop_msg} · {self.message}"
    else:
      self.phase = Phase.BATTLE_RESULT
      pct = int(100 * (1 - self.enemy.hp / self.enemy.max_hp))
      left = self._turns_remaining()
      turn_txt = f" · 남은 턴 {left}/{self.enemy.max_turns}" if self._is_combat_enemy() else ""
      self.message = (
        f"턴 {self.battle_turn} 종료 — 적 HP {self.enemy.hp}/{self.enemy.max_hp} "
        f"({pct}% 피해){turn_txt}"
      )

  def next_round(self) -> None:
    if self.phase != Phase.BATTLE_RESULT:
      return
    if self._check_turn_limit_exceeded():
      return
    self.start_new_play()
    if self.phase == Phase.GAME_OVER:
      return
    left = self._turns_remaining()
    turn_txt = f" · 남은 턴 {left}/{self.enemy.max_turns}" if self._is_combat_enemy() else ""
    self.message = f"턴 {self.battle_turn} — 묘지 {len(self.deck.discard)}장{turn_txt}"

  def scroll_discard(self, delta: int) -> None:
    self.discard_scroll = max(0, self.discard_scroll + delta)
