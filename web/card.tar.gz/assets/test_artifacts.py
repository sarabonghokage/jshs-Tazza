"""아티팩트 효과 발동 경우의 수 + 타로/아티팩트 충돌·시너지 검증.

순수 점수 함수(build_score_reveal_steps)와 GameState 런타임을 모두 사용해
각 아티팩트가 기대대로 동작하는지 자동 검증한다.
"""

from __future__ import annotations

import pygame

pygame.init()

from game.card import Card, TarotCard
from game.score_steps import build_score_reveal_steps
from game.artifact_effects import ArtifactRuntimeContext, KINGSLAYER_CHIP_PCT
from game.modifiers import PlayModifiers

_SUITS = {"s": "spades", "h": "hearts", "d": "diamonds", "c": "clubs"}

PASS = 0
FAIL = 0
FAILURES: list[str] = []


def C(rank: int, suit: str, bonus: int = 0) -> Card:
  return Card(rank, _SUITS[suit], bonus_value=bonus)


def check(name: str, cond: bool, detail: str = "") -> None:
  global PASS, FAIL
  if cond:
    PASS += 1
  else:
    FAIL += 1
    FAILURES.append(f"{name}: {detail}")
    print(f"  [FAIL] {name} :: {detail}")


def score(
  cards,
  stacks=None,
  *,
  enemy_max_hp=1000,
  turns_remaining=3,
  essence_total=0,
  resting_mult_bonus=0,
  kingslayer_active=False,
  modifiers=None,
  hand_bonuses=None,
):
  art = ArtifactRuntimeContext(
    artifact_stacks=stacks or {},
    discard_count=0,
    enemy_max_hp=enemy_max_hp,
    turns_remaining=turns_remaining,
    tarot_used_count=0,
    essence_total=essence_total,
    resting_mult_bonus=resting_mult_bonus,
    kingslayer_active=kingslayer_active,
  )
  hand = list(cards)
  res, steps = build_score_reveal_steps(
    hand, modifiers, hand_bonuses, None, None, art,
  )
  return res, steps


# ---------------------------------------------------------------------------
print("== 단일 아티팩트 점수 효과 ==")

# silver_feather: 페이스칩 50/40/35/30 + 페어·트리플 무효
res, _ = score([C(14, "s"), C(13, "s"), C(12, "s"), C(11, "s"), C(10, "s")],
               {"silver_feather": 1})
check("silver_feather 로열 칩합", res["chip_sum"] == 50 + 40 + 35 + 30 + 10,
      f"chip={res['chip_sum']} hand={res['hand_name']}")

res, _ = score([C(5, "s"), C(5, "h"), C(9, "d"), C(2, "c"), C(3, "s")],
               {"silver_feather": 1})
check("silver_feather 페어 무효", res["hand_name"] == "high_card", res["hand_name"])

# iceberg_tip: 페어→트리플
res, _ = score([C(5, "s"), C(5, "h"), C(9, "d"), C(2, "c"), C(3, "s")],
               {"iceberg_tip": 1})
check("iceberg_tip 페어→트리플", res["hand_name"] == "three_kind", res["hand_name"])

# joy_blade: 정수만큼 칩·배수
base, _ = score([C(9, "s"), C(7, "h"), C(5, "d"), C(3, "c"), C(2, "s")])
jb, _ = score([C(9, "s"), C(7, "h"), C(5, "d"), C(3, "c"), C(2, "s")],
              {"joy_blade": 1}, essence_total=4)
check("joy_blade 칩 +4", jb["chip_sum"] == base["chip_sum"] + 4,
      f"{base['chip_sum']} -> {jb['chip_sum']}")
check("joy_blade 배수 +4", jb["multiplier"] == base["multiplier"] + 4,
      f"{base['multiplier']} -> {jb['multiplier']}")

# severed_fingertip: 마지막 턴 배수 ×3
sf, _ = score([C(9, "s"), C(7, "h"), C(5, "d"), C(3, "c"), C(2, "s")],
              {"severed_fingertip": 1}, turns_remaining=0)
check("severed_fingertip 배수×3", sf["multiplier"] == base["multiplier"] * 3,
      f"{base['multiplier']} -> {sf['multiplier']}")
sf2, _ = score([C(9, "s"), C(7, "h"), C(5, "d"), C(3, "c"), C(2, "s")],
               {"severed_fingertip": 1}, turns_remaining=2)
check("severed_fingertip 비마지막턴 미발동", sf2["multiplier"] == base["multiplier"],
      f"{sf2['multiplier']}")

# resting_acolyte: 보유 시 배수 +bonus
ra, _ = score([C(9, "s"), C(7, "h"), C(5, "d"), C(3, "c"), C(2, "s")],
              {"resting_acolyte": 1}, resting_mult_bonus=5)
check("resting_acolyte 배수 +5", ra["multiplier"] == base["multiplier"] + 5,
      f"{ra['multiplier']}")
# 미보유 시 resting_mult_bonus 무시
ra0, _ = score([C(9, "s"), C(7, "h"), C(5, "d"), C(3, "c"), C(2, "s")],
               {}, resting_mult_bonus=5)
check("resting 미보유 무시", ra0["multiplier"] == base["multiplier"], f"{ra0['multiplier']}")

# locust_necklace: 효과마다 칩 +25
ln, _ = score([C(9, "s"), C(7, "h"), C(5, "d"), C(3, "c"), C(2, "s")],
              {"locust_necklace": 1, "joy_blade": 1}, essence_total=4)
check("locust_necklace 칩 증가", ln["chip_sum"] > base["chip_sum"] + 4,
      f"chip={ln['chip_sum']}")

# pale_note: 홀수 스트레이트
pn, _ = score([C(3, "s"), C(5, "h"), C(7, "d"), C(9, "c"), C(11, "s")],
              {"pale_note": 1})
check("pale_note 홀수 스트레이트", pn["hand_name"] in ("straight", "straight_flush"),
      pn["hand_name"])
# pale_note 없으면 스트레이트 아님
pn0, _ = score([C(3, "s"), C(5, "h"), C(7, "d"), C(9, "c"), C(11, "s")])
check("pale_note 미보유 스트레이트 아님", pn0["hand_name"] == "high_card", pn0["hand_name"])

# kingslayer: 칩×최대HP%
ks, _ = score([C(14, "s"), C(13, "s"), C(12, "s"), C(11, "s"), C(10, "s")],
              {"kingslayer_sword": 1}, enemy_max_hp=1000, kingslayer_active=True)
expected = int(1000 * ks["chip_sum"] * KINGSLAYER_CHIP_PCT)
check("kingslayer 피해식", ks["total"] == expected, f"total={ks['total']} exp={expected}")
check("kingslayer 배수무효", ks["multiplier"] == 1, f"mult={ks['multiplier']}")


# ---------------------------------------------------------------------------
print("== 충돌·시너지 ==")

# silver_feather + iceberg_tip: 페어는 silver가 먼저 high_card로 → iceberg 무효
combo, _ = score([C(5, "s"), C(5, "h"), C(9, "d"), C(2, "c"), C(3, "s")],
                 {"silver_feather": 1, "iceberg_tip": 1})
check("silver+iceberg 페어 결과", combo["hand_name"] == "high_card",
      f"hand={combo['hand_name']} (silver가 우선이면 high_card)")

# silver_feather + joy_blade: 플러시는 무효 대상 아님 → 정상 + 칩보너스
sj, _ = score([C(14, "s"), C(9, "s"), C(5, "s"), C(3, "s"), C(2, "s")],
              {"silver_feather": 1, "joy_blade": 1}, essence_total=3)
check("silver+joy 플러시 유지", sj["hand_name"] == "flush", sj["hand_name"])

# pale_note + iceberg: 페어가 pale로 랭크변환돼도 페어면 iceberg 트리플
pi, _ = score([C(4, "s"), C(4, "h"), C(9, "d"), C(2, "c"), C(7, "s")],
              {"pale_note": 1, "iceberg_tip": 1})
check("pale+iceberg 페어→트리플", pi["hand_name"] == "three_kind", pi["hand_name"])

print(f"\n점수계열: PASS={PASS} FAIL={FAIL}")


# ---------------------------------------------------------------------------
print("\n== 런타임 아티팩트 (GameState) ==")

from game.state import GameState, Phase, SubPhase
from game.hand_size import resolve_hand_slots, empress_hand_target


def fresh(stacks=None):
  s = GameState()
  s.artifact_stacks = dict(stacks or {})
  s.sync_hand_slots()
  return s


# white_glove 손패 8
check("white_glove 손패8", resolve_hand_slots({"white_glove": 1}) == 8,
      str(resolve_hand_slots({"white_glove": 1})))
# 여제(8) + white_glove(8) = 8
check("empress+glove=8", resolve_hand_slots({"white_glove": 1}, play_target=empress_hand_target(0)) == 8,
      str(resolve_hand_slots({"white_glove": 1}, play_target=empress_hand_target(0))))
# 여제 강화(9) + glove(8) = 9
check("empress강화+glove=9", resolve_hand_slots({"white_glove": 1}, play_target=empress_hand_target(1)) == 9,
      str(resolve_hand_slots({"white_glove": 1}, play_target=empress_hand_target(1))))

# blood_horn: 드로우 시 덱 1장 추가 묘지
s = fresh({"blood_horn": 1})
s.phase = Phase.FILL_HAND
deck_before = len(s.deck.deck)
disc_before = len(s.deck.discard)
card = s.pull_card()
# pull_card는 1장 뽑고 blood_horn이 옆 1장을 묘지로
check("blood_horn 덱 감소", len(s.deck.deck) <= deck_before - 1, f"{deck_before}->{len(s.deck.deck)}")

# ether: 처치 시 연금재료 각 +4 (추가로 랜덤 드롭 +1이 한 종류에 붙음)
s = fresh({"ether": 1})
msg = s._drop_essence_on_kill()
total = s.essence_salt + s.essence_sulfur + s.essence_mercury
check("ether 각 원소 >=4", min(s.essence_salt, s.essence_sulfur, s.essence_mercury) >= 4,
      f"salt={s.essence_salt} sulfur={s.essence_sulfur} mercury={s.essence_mercury}")
check("ether 총합 13 (4*3+랜덤1)", total == 13, f"total={total}")

# star_clock: 턴 +50%
from game.constants import enemy_turn_limit
base_turns = enemy_turn_limit(3)
s = fresh({"star_clock": 1})
s._spawn_enemy(3)
check("star_clock 턴+50%", s.enemy.max_turns == int(base_turns * 1.5 + 0.5),
      f"turns={s.enemy.max_turns} base={base_turns}")

# star_clock 즉사: 하이카드/페어 합산 시 게임오버
s = fresh({"star_clock": 1})
s._spawn_enemy(3)
s.phase = Phase.FILL_HAND
s.hand = [C(9, "s"), C(7, "h"), C(5, "d"), C(3, "c"), C(2, "s")] + [None] * (s.max_hand_slots - 5)
s._enter_score_phase()
check("star_clock 하이카드 즉사", s.phase == Phase.GAME_OVER, f"phase={s.phase}")

# star_clock + silver_feather 충돌은 동시 제안 차단으로 실전 미발생 (충돌 테스트로 검증)

# compressed_head: 사망 시 1회 부활
s = fresh({"compressed_head": 1})
s._spawn_enemy(3)
s.phase = Phase.FILL_HAND
s._game_over("테스트 사망")
check("compressed_head 부활", s.phase != Phase.GAME_OVER and s.compressed_head_used,
      f"phase={s.phase} used={s.compressed_head_used}")
# 2번째 사망은 진짜 게임오버
s._game_over("두번째 사망")
check("compressed_head 2회차 진짜사망", s.phase == Phase.GAME_OVER, f"phase={s.phase}")

# traitor_tongue: 타로 슬롯 +1
from game.artifact_runtime import effective_max_tarot_held
from game.constants import MAX_TAROT_HELD
check("traitor_tongue 타로슬롯+1",
      effective_max_tarot_held({"traitor_tongue": 1}) == MAX_TAROT_HELD + 1,
      str(effective_max_tarot_held({"traitor_tongue": 1})))

# indulgence: 드로우 후보/밴 수
from game.artifact_runtime import indulgence_discard_count, opening_deal_count, draw_pick_count
check("indulgence 밴5", indulgence_discard_count({"indulgence": 1}) == 5,
      str(indulgence_discard_count({"indulgence": 1})))
check("indulgence 오프닝8", opening_deal_count({"indulgence": 1}) == 8,
      str(opening_deal_count({"indulgence": 1})))
check("white_glove 드로우후보5", draw_pick_count({"white_glove": 1}) == 5,
      str(draw_pick_count({"white_glove": 1})))

# infi_bible: 덱최소0, 연금불가, 턱5
from game.artifact_runtime import deck_min_for_run, alchemy_enabled, jaw_marks_per_stage
check("infi_bible 덱최소0", deck_min_for_run({"infi_bible": 1}) == 0,
      str(deck_min_for_run({"infi_bible": 1})))
check("infi_bible 연금불가", alchemy_enabled({"infi_bible": 1}) is False,
      str(alchemy_enabled({"infi_bible": 1})))
check("infi_bible 턱5", jaw_marks_per_stage({"infi_bible": 1}) == 5,
      str(jaw_marks_per_stage({"infi_bible": 1})))
# infi_bible 보유 시 추가 유물 제안 없음
from game.artifacts import random_artifact_offers, eligible_artifact_ids
check("infi_bible 추가유물 불가", eligible_artifact_ids({"infi_bible": 1}) == [],
      str(eligible_artifact_ids({"infi_bible": 1})))

# future_shackle: 같은 타로 재사용 (used 처리 로직)
s = fresh({"future_shackle": 1})
s.phase = Phase.FILL_HAND
s.tarots = [TarotCard(6, uid=1)]
# 사용 처리 시뮬레이션은 mark_tarot_used 경로 확인
check("future_shackle 보유", "future_shackle" in s.artifact_stacks, "")


# ---------------------------------------------------------------------------
print("\n== 아티팩트 보상 스테이지 빈도 ==")
from game.progression import is_artifact_reward_stage
art_stages = [st for st in range(1, 13) if is_artifact_reward_stage(st)]
check("아티팩트 보상 스테이지 다수", len(art_stages) >= 5, f"stages={art_stages}")

from game.artifacts import MAX_ARTIFACTS
check("최대 아티팩트 >1", MAX_ARTIFACTS > 1, str(MAX_ARTIFACTS))

# 충돌 유물 제외: silver_feather 보유 시 star_clock/iceberg_tip 미제안
elig = eligible_artifact_ids({"silver_feather": 1})
check("silver 보유시 star_clock 제외", "star_clock" not in elig, str("star_clock" in elig))
check("silver 보유시 iceberg 제외", "iceberg_tip" not in elig, str("iceberg_tip" in elig))
# star_clock 보유 시 silver_feather 미제안
elig2 = eligible_artifact_ids({"star_clock": 1})
check("star_clock 보유시 silver 제외", "silver_feather" not in elig2, "")
# 무관한 유물은 계속 제안
check("비충돌 유물 정상 제안", "joy_blade" in elig, "")


# ---------------------------------------------------------------------------
print("\n== 보상 체인 통합 ==")

# 짝수(아티팩트) 스테이지 처치 → 유물 보상 → 선택 후 타로/강화 체인 진행
s = fresh()
s.tarots = [TarotCard(6, uid=1)]  # 런 시작 아님(타로 보유)
s._spawn_enemy(2)  # 짝수 normal 스테이지
check("stage2 normal", s.enemy.kind == "normal", s.enemy.kind)
s._begin_reward_after_kill()
check("짝수처치 유물보상 진입", s.phase == Phase.ARTIFACT_REWARD,
      f"phase={s.phase} offers={s.artifact_reward_choices}")
n_before = sum(s.artifact_stacks.values())
ok = s.pick_artifact(0)
check("유물 선택 성공", ok and sum(s.artifact_stacks.values()) == n_before + 1, "")
check("유물 선택 후 체인 진행", s.phase in (Phase.TAROT_REWARD, Phase.UPGRADE_SELECT),
      f"phase={s.phase}")

# 홀수(비아티팩트) 스테이지는 유물 보상 없이 타로 보상
s = fresh()
s.tarots = [TarotCard(6, uid=1)]
s._spawn_enemy(3)
s._begin_reward_after_kill()
check("홀수처치 타로보상", s.phase in (Phase.TAROT_REWARD, Phase.UPGRADE_SELECT),
      f"phase={s.phase}")

# 유물 가득 찼을 때 보상 체인이 멈추지 않고 타로/강화로 폴백
full = {aid: 1 for aid in list(__import__("game.artifacts", fromlist=["ARTIFACT_DEFINITIONS"]).ARTIFACT_DEFINITIONS)[:8]}
s = fresh(full)
s.tarots = [TarotCard(6, uid=1)]
s._spawn_enemy(2)
s._begin_reward_after_kill()
check("유물최대시 폴백", s.phase in (Phase.TAROT_REWARD, Phase.UPGRADE_SELECT),
      f"phase={s.phase}")


print(f"\n=== 총계: PASS={PASS} FAIL={FAIL} ===")
if FAILURES:
  print("\n실패 목록:")
  for f in FAILURES:
    print(f"  - {f}")

